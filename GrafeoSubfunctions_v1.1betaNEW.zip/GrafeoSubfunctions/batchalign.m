function batchalign(Csusu,subsubdir,searchstring,saveflag,dim)
 % batchalign is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

    tfm = ~cellfun('isempty',strfind(Csusu,searchstring));
    Csusu1 = Csusu(tfm); 
    nfile = numel(Csusu1);
for ni = 1:nfile
if dim == 3
ind = [1,2,5];
elseif dim == 2
ind = [1,2];
end
filetoload = strcat(subsubdir,flagslash,Csusu1{ni});
filetosave = strrep(filetoload,searchstring,saveflag);

load(filetoload,'dataout1','dataout2',...
'densitythr1','densitythr2','Vp1','Vp2',...
'namech1','namech2','Dp1','Dp2','photonTH1','photonTH2','locprec1','locprec2')
try

    [~,leftrightcount,updowncount,zcount,~,exitflag,output] = ...
        simulanielminim(dataout1(:,ind),dataout2(:,ind),dim); % aligment
    dataoutshift1 = dataout1;
    if ~isempty(leftrightcount)
        dataoutshift1(:,1)  = dataout1(:,1) - leftrightcount;
    end
    if ~isempty(updowncount)
        dataoutshift1(:,2)  = dataout1(:,2) - updowncount;
    end
if dim == 3
    if ~isempty(zcount)
        dataoutshift1(:,5)  = dataout1(:,5) - zcount;
    end
end
catch
    dataoutshift1 = [];
    leftrightcount = [];
    updowncount = [];
    exitflag = [];
    output = [];
    zcount = [];
end

save(filetosave,'dataout1','dataout2',...
'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
'leftrightcount','updowncount','exitflag', 'output','zcount',...
'dim','namech1','namech2','Dp1','Dp2','photonTH1','photonTH2',...
'locprec1','locprec2','exitflag','output')

end
end

