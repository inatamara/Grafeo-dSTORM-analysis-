function [ind1,ind2,B,varargout] = pointsINboundary(c1,c2,mask,minreg,pix)
% pointsINboundary is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

if  ~iscell(mask)
    mask = bwareaopen(mask,minreg);
    [B,~,~,A] = bwboundaries(mask);
    N = numel(B);
    tic
    if ~isempty(pix)
    for ii = 1:N
    B{ii} = B{ii}*pix;
    end
    end
    ind1 = [];
    ind2 = [];
    % Loop through object boundaries
    flag = 0;
    for k = 1:N
        % Boundary k is the parent of a hole if the k-th column
        % of the adjacency matrix A contains a non-zero element
        if (nnz(A(:,k)) > 0)
            for l = find(A(:,k))'
                flag = flag + 1;
                boundary = B{l};
                 if ~isempty(c1)
                    try
                        ind1{flag} = InPolygon(c1(:,1),c1(:,2), boundary(:,1),boundary(:,2));
                    catch
                        ind1{flag} = inpolygon(c1(:,1),c1(:,2), boundary(:,1),boundary(:,2));
                    end
                    c1 = c1(~ind1{flag},:);  
                 end

                if ~isempty(c2)
                   try
                        ind2{flag} = InPolygon(c2(:,1),c2(:,2), boundary(:,1),boundary(:,2));  
                    catch
                         ind2{flag} = inpolygon(c2(:,1),c2(:,2), boundary(:,1),boundary(:,2));  
                    end
                    c2 = c2(~ind2{flag},:);  
                end

                B{l} = [];
            end
        end
    end
else

    % Loop through object boundaries
    flag = 0;
    B = mask;
    N = numel(B);
    ind1 = cell(N,1);
    ind2 = cell(N,1);
    for k = 1:N

                flag = flag + 1;
                boundary = B{k};
                if ~isempty(c1)
                    try
                        ind1{flag} = InPolygon(c1(:,1),c1(:,2), boundary(:,1),boundary(:,2));
                    catch
                        ind1{flag} = inpolygon(c1(:,1),c1(:,2), boundary(:,1),boundary(:,2));
                    end
                c1 = c1(ind1{flag},:);   
                end
                if ~isempty(c2)
                    try
                        ind2{flag} = InPolygon(c2(:,1),c2(:,2), boundary(:,1),boundary(:,2));  
                    catch
                         ind2{flag} = inpolygon(c2(:,1),c2(:,2), boundary(:,1),boundary(:,2));  
                    end
                c2 = c2(ind2{flag},:);  
                end
                

    end   
end
if nargout  == 4 
    varargout{1} = c1;
elseif nargout == 5
    varargout{1} = c1;
    varargout{2} = c2;
end
end

