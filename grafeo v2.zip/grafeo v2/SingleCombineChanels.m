%  SingleCombineChanels is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018


[selecfiles1,subsubdir]  = uigetfile(pwd,'Get a a file for chanel 1');
[selecfiles2,~]  = uigetfile('*.mat','Get a a file for chanel 2');
loadChanel1 = load(strcat(subsubdir,flagslash,selecfiles1));
loadChanel2 = load(strcat(subsubdir,flagslash,selecfiles2));
 prompt = {'Get a flag for chanel: 1',...
'Get a flag for chanel 2:',...
'Enter 0 to only combine to chanels'};
dlg_title = 'Input';
num_lines = 1;
def = {'647','568','0'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
flagch1 = answer{1};
flagch2 = answer{2};
flagalign = answer{2};
dataout2 =  loadChanel2.datatesselerfilt ;
dataout1 =  loadChanel1.datatesselerfilt ;
Vp1 = loadChanel1.Vp ;
Vp2 = loadChanel2.Vp ;
Dp1 = loadChanel1.Dp  ;
Dp2  = loadChanel2.Dp ;
namech1 = selecfiles1;
namech2 = selecfiles2;
photonTH1 = eval(textbox_minP1.String);  
locprec1 = eval(textbox_minLP1.String);
photonTH2 = eval(textbox_minP2.String);  
locprec2 = eval(textbox_minLP2.String);  
if loadChanel1.dim == 3 & loadChanel2.dim == 3
    ind = [1,2,5];
    dim = 3;
else
    ind = [1,2];
    dim = 2;
end
    if flagalign
        try
        [~,leftrightcount,updowncount,zcount,~,exitflag,output] = ...
            simulanielminim(dataout1(:,ind),dataout2(:,ind),dim); % aligment
        dataoutshift1 = dataout1;
        dataoutshift1(:,1)  = dataout1(:,1) - leftrightcount;
        dataoutshift1(:,2)  = dataout1(:,2) - updowncount;
        if dim == 3
        dataoutshift1(:,5)  = dataout1(:,5) - zcount;
        end
        catch
            dataoutshift1 = [];
            leftrightcount = [];
            updowncount = [];
            exitflag = [];
            output = [];
            zcount = [];
        end
    else
            dataoutshift1 = [];
            leftrightcount = [];
            updowncount = [];
            exitflag = [];
            output = [];
            zcount = [];
    end
uisave('dataout1','dataout2',...
'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
'leftrightcount','updowncount','exitflag', 'output','zcount',...
'dim','namech1','namech2','Dp1','Dp2','photonTH1','photonTH2','locprec1',...
'locprec2',strcat(subsubdir,flagslash,'Aligned_',flagch1,'_',...
flagch2,'_','.mat'))