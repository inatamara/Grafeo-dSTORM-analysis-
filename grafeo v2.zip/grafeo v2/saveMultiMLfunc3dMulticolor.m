function saveMultiMLfunc3dMulticolor(selecfiles,subsubdir,MLindices,idpair,varargin)
% saveMultiMLfunc3d is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

% zeiss MLindices = {13,5,6,8,7,2,12,3,13};
if nargin >= 8 
    if ~isempty(varargin{4})& varargin{4}~=0
        nH = varargin{4};
    else
         nH = 1;
    end
else
     nH = 1;
end
if nargin >= 9  
     if ~isempty(varargin{5})& varargin{5}~=0
        spaceDelim = varargin{5};
     else
         spaceDelim = '\t';
     end
    if ~isempty(varargin{4})& varargin{4}~=0
        nH = varargin{4};
    else
         nH = 1;
    end
else
     spaceDelim = '\t';
     nH = 1;
end

if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

if iscell(selecfiles)
    tfmat = ~cellfun('isempty',strfind(selecfiles,'.txt'));
    selecfiles = selecfiles(tfmat);
    ns = numel(selecfiles);
else
    ns = 1;
    if ~strfind(selecfiles,'.txt')
        return;
    end
end

tic
id = idpair{1};
idfilt = idpair{2};
chanelNo = numel(idpair{3});
chanelSeq = idpair{3};

for ni = 1:ns   
if iscell(selecfiles)
    filetoload = strcat(subsubdir,flagslash,selecfiles{ni});
    filenameload = selecfiles{ni};
else
    filetoload = strcat(subsubdir,flagslash,selecfiles);
    filenameload = selecfiles;
end


nametesmat = strcat(filetoload(1:end-4),'_',chanelSeq{1},'_Xwc','_Ywc','_I','_F','_Sig','_Zc','.mat');
nametesmat2 = strcat(filetoload(1:end-4),'_',chanelSeq{2},'_Xwc','_Ywc','_I','_F','_Sig','_Zc','.mat');
nametesmat3 = strcat(filetoload(1:end-4),'_',chanelSeq{3},'_Xwc','_Ywc','_I','_F','_Sig','_Zc','.mat');

if exist(nametesmat,'file')  % & iscell(selecfiles)
if  ~contains(filenameload,'_Xwc') & ~contains(filenameload,'drift')...
    & ~contains(filenameload,'Aligned_')& ~contains(filenameload,'VoronThrOnly')...
    & ~contains(filenameload,'Filtalgn')& ~contains(filenameload,'ReThrAlgn')...
    & ~contains(filenameload,'ReThrCoralgn') & ~contains(filenameload,'Coralign')...
    & ~contains(filenameload,'mask')& ~contains(filenameload,'Graph') ...
    & ~contains(filenameload,'Skeleton')& ~contains(filenameload,'Filtalgn_high')...
    & ~contains(filenameload,'Corralign')& ~contains(filenameload,'algn')...
    & ~contains(filenameload,'drift') & ~contains(filenameload,'bin')...
    & ~contains(filenameload,'tif') & ~contains(filenameload,'nd2')...
    & ~contains(filenameload,'jpeg')  & ~contains(filenameload,'.xlsx')

%     isempty(strfind(filetoload,'_Xwc')) & isempty(strfind(filetoload,'drift'))...
%     & isempty(strfind(filetoload,'Aligned_'))& isempty(strfind(filetoload,'VoronThrOnly'))...
%     & isempty(strfind(filetoload,'Filtalgn'))& isempty(strfind(filetoload,'ReThrAlgn'))...
%     & isempty(strfind(filetoload,'ReThrCoralgn'))& isempty(strfind(filetoload,'Coralign'))...
%     & isempty(strfind(filetoload,'mask'))& isempty(strfind(filetoload,'Graph')) ...
%     & isempty(strfind(filetoload,'Skeleton'))& isempty(strfind(filetoload,'Filtalgn_high'))...
%     & isempty(strfind(filetoload,'Corralign'))& isempty(strfind(filetoload,'algn'))...
%     & isempty(strfind(filetoload,'drift')) & isempty(strfind(filetoload,'bin'))...
%     & isempty(strfind(filetoload,'tif')) & isempty(strfind(filetoload,'nd2'))...
%     & isempty(strfind(filetoload,'jpeg'))  & isempty(strfind(filetoload,'.xlsx'))


fileID = fopen(filetoload);
headers = fgets(fileID);disp(headers)
fmt = ['%s' repmat('%f',[1,MLindices{1} - 1])];
A = textscan(fileID,fmt,'HeaderLines',nH,'Delimiter',spaceDelim);
fclose(fileID);
clear dattes
rg = min([length(A{MLindices{2}}),length(A{MLindices{3}}),...
    length(A{MLindices{4}}),length(A{MLindices{6}}),...
    length(A{MLindices{5}}),length(A{MLindices{8}})]);
dattes(:,1) = A{MLindices{2}}(1:rg); % Xwc
dattes(:,2) = A{MLindices{3}}(1:rg); % Ywc
dattes(:,3) = A{MLindices{4}}(1:rg); % Photons
dattes(:,4) = A{MLindices{6}}(1:rg); % Frame
dattes(:,4) = dattes(:,4);
dattes(:,5) = A{MLindices{5}}(1:rg); % Localization precision
dattes(:,7) = A{MLindices{8}}(1:rg); % Length
% data for the tesseler program
dattes3d = dattes;
dattes3d(:,6) = A{MLindices{9}}(1:rg); % Z   
str = A{MLindices{7}}(1:rg);

if chanelNo == 2
    Index1 = find(contains(str,chanelSeq{1}));
    Index2 = find(contains(str,chanelSeq{2}));
    
    if idfilt
        out = dattes3d(Index1,:);
        filtflag = zeros(numel(out(:,1)),1);
        out = [out,filtflag];
        out(any(~isfinite(out), 2), :) = [];
        out1 = out;
        
        clear out
        
        out = dattes3d(Index2,:);
        filtflag = zeros(numel(out(:,1)),1);
        out = [out,filtflag];
        out(any(~isfinite(out), 2), :) = [];
        out2 = out;
        
        clear out
    else
        out = dattes3d(1:Index2(1)-1,:);
        str = A{MLindices{7}}(1:Index2(1)-1,:);
        filtflag = zeros(numel(out(:,1)),1);
        filtflag(strcmp(str,id)) = 0;
        filtflag(~strcmp(str,id)) = 1;
        out = [out,filtflag];  
        out(any(~isfinite(out), 2), :) = [];
        
        out1 = out;
        clear out
        
        out = dattes3d(Index2(1):end,:);
        str = A{MLindices{7}}(Index2(1):end,1);
        filtflag = zeros(numel(out(:,1)),1);
        filtflag(strcmp(str,id)) = 0;
        filtflag(~strcmp(str,id)) = 1;
        out = [out,filtflag];  
        out(any(~isfinite(out), 2), :) = [];
        
        out2 = out;
        clear out
    end
       
elseif chanelNo == 3
    Index1 = find(contains(str,chanelSeq{1}));
    Index2 = find(contains(str,chanelSeq{2}));
    Index3 = find(contains(str,chanelSeq{3}));
    if idfilt
    
        out = dattes3d(Index1,:);
        filtflag = zeros(numel(out(:,1)),1);
        out = [out,filtflag];
        out(any(~isfinite(out), 2), :) = [];
        out1 = out;
        
        clear out
        
        out = dattes3d(Index2,:);
        filtflag = zeros(numel(out(:,1)),1);
        out = [out,filtflag];
        out(any(~isfinite(out), 2), :) = [];
        out2 = out;
        
        clear out
        
        out = dattes3d(Index3,:);
        filtflag = zeros(numel(out(:,1)),1);
        out = [out,filtflag];
        out(any(~isfinite(out), 2), :) = [];
        out3 = out;
        clear out
      else
        out = dattes3d(1:Index2(1)-1,:);
        str = A{MLindices{7}}(1:Index2(1)-1,1);
        filtflag = zeros(numel(out(:,1)),1);
        filtflag(strcmp(str,id)) = 0;
        filtflag(~strcmp(str,id)) = 1;
        out = [out,filtflag];  
        out(any(~isfinite(out), 2), :) = [];
        
        out1 = out;
        clear out
        
        out = dattes3d(Index2(1):Index3(1)-1,:);
        str = A{MLindices{7}}(Index2(1):Index3(1)-1,1);
        filtflag = zeros(numel(out(:,1)),1);
        filtflag(strcmp(str,id)) = 0;
        filtflag(~strcmp(str,id)) = 1;
        out = [out,filtflag];  
        out(any(~isfinite(out), 2), :) = [];
        
        out2 = out;
        clear out
        
        out = dattes3d(Index3(1):end,:);
        str = A{MLindices{7}}(Index3(1):end,1);
        filtflag = zeros(numel(out(:,1)),1);
        filtflag(strcmp(str,id)) = 0;
        filtflag(~strcmp(str,id)) = 1;
        out = [out,filtflag];  
        out(any(~isfinite(out), 2), :) = [];
        
        out3 = out;
        clear out
    
    end  
end

np = numel(out1(:,6));
if np == sum(out1(:,6))
out1(:,6) = zeros(np,1);
end
clear dattes3d

if sum(out1(:,6))
    dim = 3;
else
    dim = 2;
end

if nargin == 6
    if ~isempty(varargin{1})& varargin{1}~=0
        out1 = out1(out1(:,3) >= varargin{1},:);
    end
    if ~isempty(varargin{2})& varargin{2}~=0
        out1 = out1(out1(:,5) <= varargin{2},:);
    end
elseif nargin >= 7
    if ~isempty(varargin{1})& varargin{1}~=0
        out1 = out1(out1(:,3) >= varargin{1},:);
    end
    if ~isempty(varargin{2})& varargin{2}~=0
        out1 = out1(out1(:,5) <= varargin{2},:);
    end
    if ~isempty(varargin{3})& varargin{3}~=0
        dim = varargin{3};
    end
end
if nargin >= 6
    photonTH = varargin{1};
    locprec = varargin{2};
elseif nargin < 6
    photonTH = [];
    locprec = [];
end
datatesseler3d = out1; 
numfr = max(dattes(:,4));

[Vp,VOLp,v,c,datatesselerfilt] = voronoicustom(datatesseler3d,dim);

save(nametesmat,'datatesselerfilt',...
    'Vp','VOLp','v','c','dim','numfr','photonTH','locprec')
disp(nametesmat)
% end chanel 1

%chanel 2 saveing

np = numel(out2(:,6));
if np == sum(out2(:,6))
out2(:,6) = zeros(np,1);
end
clear dattes3d

if sum(out2(:,6))
    dim = 3;
else
    dim = 2;
end

if nargin == 6
    if ~isempty(varargin{1})& varargin{1}~=0
        out2 = out2(out2(:,3) >= varargin{1},:);
    end
    if ~isempty(varargin{2})& varargin{2}~=0
        out2 = out2(out2(:,5) <= varargin{2},:);
    end
elseif nargin >= 7
    if ~isempty(varargin{1})& varargin{1}~=0
        out2 = out2(out2(:,3) >= varargin{1},:);
    end
    if ~isempty(varargin{2})& varargin{2}~=0
        out2 = out2(out2(:,5) <= varargin{2},:);
    end
    if ~isempty(varargin{3})& varargin{3}~=0
        dim = varargin{3};
    end
end
if nargin >= 6
    photonTH = varargin{1};
    locprec = varargin{2};
elseif nargin < 6
    photonTH = [];
    locprec = [];
end
datatesseler3d = out2; 
numfr = max(dattes(:,4));

[Vp,VOLp,v,c,datatesselerfilt] = voronoicustom(datatesseler3d,dim);

save(nametesmat2,'datatesselerfilt',...
    'Vp','VOLp','v','c','dim','numfr','photonTH','locprec')
disp(nametesmat2)
% end chganel 2 saveing

% chanel 3 saveing
if chanelNo == 3
    
    
np = numel(out3(:,6));
if np == sum(out3(:,6))
out3(:,6) = zeros(np,1);
end
clear dattes3d

if sum(out3(:,6))
    dim = 3;
else
    dim = 2;
end

if nargin == 6
    if ~isempty(varargin{1})& varargin{1}~=0
        out3 = out3(out3(:,3) >= varargin{1},:);
    end
    if ~isempty(varargin{2})& varargin{2}~=0
        out3 = out3(out3(:,5) <= varargin{2},:);
    end
elseif nargin >= 7
    if ~isempty(varargin{1})& varargin{1}~=0
        out3 = out3(out3(:,3) >= varargin{1},:);
    end
    if ~isempty(varargin{2})& varargin{2}~=0
        out3 = out3(out3(:,5) <= varargin{2},:);
    end
    if ~isempty(varargin{3})& varargin{3}~=0
        dim = varargin{3};
    end
end
if nargin >= 6
    photonTH = varargin{1};
    locprec = varargin{2};
elseif nargin < 6
    photonTH = [];
    locprec = [];
end
datatesseler3d = out3; 
numfr = max(dattes(:,4));

[Vp,VOLp,v,c,datatesselerfilt] = voronoicustom(datatesseler3d,dim);

save(nametesmat3,'datatesselerfilt',...
    'Vp','VOLp','v','c','dim','numfr','photonTH','locprec')
disp(nametesmat3)
end
end
else
    disp('Already exist')
end

end
toc 

% if ~contains(filetoload,'_Xwc') & ~contains(filetoload,'drift')...
%     & ~contains(filetoload,'Aligned_')& ~contains(filetoload,'VoronThrOnly')...
%     & ~contains(filetoload,'Filtalgn')& ~contains(filetoload,'ReThrAlgn')...
%     & ~contains(filetoload,'ReThrCoralgn')& ~contains(filetoload,'Coralign')...
%     & ~contains(filetoload,'mask')& ~contains(filetoload,'Graph') ...
%     & ~contains(filetoload,'Skeleton')& ~contains(filetoload,'Filtalgn_high')...
%     & ~contains(filetoload,'Corralign')& ~contains(filetoload,'algn')...
%     & ~contains(filetoload,'drift') & ~contains(filetoload,'bin')...
%     & ~contains(filetoload,'tif') & ~contains(filetoload,'nd2')
end