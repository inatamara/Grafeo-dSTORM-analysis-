function batchProcessVoronoi(Csusu,subsubdir,delim,flagch1,flagch2,flag,...
fac,photonTH1,photonTH2,locprec1,locprec2,algnflag,densitythr1,densitythr2,saveflag,varargin)
% batchProcessVoronoi is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
tic
if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

    tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
    Csusu = Csusu(tfmat);
    
    tfmat = cellfun('isempty',strfind(Csusu,'Single'));
    Csusu = Csusu(tfmat);
    
    tfmat = cellfun('isempty',strfind(Csusu,'Corralign'));
    Csusu = Csusu(tfmat);
    
    tfmat = cellfun('isempty',strfind(Csusu,'Aligned'));
    Csusu = Csusu(tfmat);

    tfmChanel2 = ~cellfun('isempty',strfind(Csusu,flagch2));
    CsusuChanel2 = Csusu(tfmChanel2); 

    tfmChanel1 = ~cellfun('isempty',strfind(Csusu,flagch1));
    CsusuChanel1 = Csusu(tfmChanel1); 

if nargin == 16
    dimn = varargin{1};
else
    dimn = 0;
end
%% 
nfile = max(numel(CsusuChanel2),numel(CsusuChanel1));
for ni = 1:nfile
    try
%     fil = CsusuChanel2{ni};
    matchstr = strcat(delim,num2str(CsusuChanel1{ni}(end-23)));
%     matchstr = strcat(delim,num2str(ni));
    matchChanel2 = regexp(CsusuChanel2,matchstr);
    matchChanel1 = regexp(CsusuChanel1,matchstr);
    tfChanel2 = cellfun(@(a)(numel(a) == 1),matchChanel2);
    tfChanel1 = cellfun(@(a)(numel(a) == 1),matchChanel1);

    if ~sum(tfChanel2) & ~sum(tfChanel1)
    tfChanel2 = cellfun(@(a)(numel(a) == 1),matchChanel2);
    tfChanel1 = cellfun(@(a)(numel(a) == 1),matchChanel1);
    end

    % 3d voronoi analysed data
    if sum(tfChanel2) & sum(tfChanel1)
        namech2 = CsusuChanel2(tfChanel2);
        namech1 = CsusuChanel1(tfChanel1);

        if  numel(namech1) == 1 & numel(namech2) == 1
            
            savename = strcat(subsubdir,flagslash,saveflag,flagch1,'_',flagch2,'_',...
            namech1{1}(end-23),'.mat');
        
            if ~exist(savename,'file')
            namech2 = namech2{1};
            namech1 = namech1{1};
            loadChanel1 = load(strcat(subsubdir,flagslash,namech1));
            loadChanel2 = load(strcat(subsubdir,flagslash,namech2));
            if densitythr1
                [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
                    photonTH1,locprec1,densitythr1,flag(1),fac(1),dimn); 
            else
                [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
                    photonTH1,locprec1,[],flag(1),fac(1),dimn); 
            end
            
            if densitythr2
                [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
                    photonTH2,locprec2,densitythr2,flag(2),fac(2),dimn); 
            else
                [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
                    photonTH2,locprec2,[],flag(2),fac(2),dimn); 
            end
            if dimn
                dim = dimn;
            end
            if algnflag
                try
                    if dim == 3
                        ind = [1,2,5];
                    elseif dim == 2
                        ind = [1,2];
                    end
                    [~,leftrightcount,updowncount,zcount,~,exitflag,output] = ...
                        simulanielminim(dataout1(:,ind),dataout2(:,ind),dim); % aligment
                    dataoutshift1 = dataout1;
                    dataoutshift1(:,1)  = dataout1(:,1) - leftrightcount;
                    dataoutshift1(:,2)  = dataout1(:,2) - updowncount;
                if dim == 3
                    dataoutshift1(:,5)  = dataout1(:,5) - zcount;
                end
                catch
                    dataoutshift1 = [];
                    leftrightcount = [];
                    updowncount = [];
                    exitflag = [];
                    output = [];
                    zcount = [];
                end
            else
                dataoutshift1 = [];
                leftrightcount = [];
                updowncount = [];
                exitflag = [];
                output = [];
                zcount = [];                
            end
            disp('Saveing ...')
             disp(savename)
             save(savename,'dataout1','dataout2',...
            'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
            'leftrightcount','updowncount','exitflag', 'output','zcount',...
            'dim','namech1','namech2','Dp1','Dp2','photonTH1','photonTH2',...
            'locprec1','locprec2')
            else
                disp('Already exist:')
                disp(savename)
            end

    end     
    end
    catch
        disp('Files not paired ...')
    end
end
disp('Finished ...')
toc

end