function [Dav,d] = knnsearchThr(x,y,numn,flag)
% knnsearchThr is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018


[~,d]=knnsearch(x,y,'k',numn,'distance','euclidean','IncludeTies',true);
if strcmp('mean',flag)
Dav = cellfun(@mean,d,'UniformOutput',false);
Dav = cell2mat(Dav);
elseif strcmp('median',flag)
Dav = cellfun(@median,d,'UniformOutput',false);
Dav = cell2mat(Dav);
end
end