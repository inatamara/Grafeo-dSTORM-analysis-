function BatchGraphColoc2C(Csusu,subsubdir,flagname,varargin)
% varargin: [minA1,minA2], [fac1,fac2],[noddeg1,noddeg2],dimdeluney ,distcoloc
% numn, pix, flag, minregmask

% BatchGraphColoc2C is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

minA1 = 3;
minA2 = 3;
fac1 = 30;
fac2 = 30;
noddeg1 = 1;
noddeg2 = 1;
dimdeluney = 2;
distcoloc = 100;
numnn = 1;
pix = 10;
flag = 'median';
minregmask = 1000;
if ~iscell(Csusu)
    Csusu1{1} = Csusu;
else
    Csusu1 = Csusu;
end
clear Csusu
if nargin >= 4
    if ~isempty(varargin{1})& varargin{1}(1)~= 0
        minA1 = varargin{1}(1);
    end
    if ~isempty(varargin{1})& varargin{1}(2)~= 0
        minA2 = varargin{1}(2);
    end
end
if nargin >= 5
    if ~isempty(varargin{2})& varargin{2}(1)~= 0
        fac1 = varargin{2}(1);
    end
    if ~isempty(varargin{2})& varargin{2}(2)~= 0
        fac2 = varargin{2}(2);
    end
end

if nargin >= 6
    if ~isempty(varargin{3})& varargin{3}(1)~= 0
        noddeg1 = varargin{3}(1);
    end
    if ~isempty(varargin{3})& varargin{3}(2)~= 0
        noddeg2 = varargin{3}(2);
    end
end

if nargin >= 7
    if ~isempty(varargin{4})& varargin{4}~= 0
        dimdeluney = varargin{4};
    end
end
if nargin >= 8
    if ~isempty(varargin{5})& varargin{5}~= 0
        distcoloc = varargin{5};
    end
end
if nargin >= 9
    if ~isempty(varargin{6})& varargin{6}~= 0
        numnn = varargin{6};
    end
end
if nargin >= 10
    if ~isempty(varargin{7})& varargin{7}~= 0
        pix = varargin{7};
    end
end
if nargin >= 11
    if ~isempty(varargin{8})& varargin{8}~= 0
        flag = varargin{8};
    end
end

if nargin == 12
    if ~isempty(varargin{9})& varargin{9}~= 0
        minregmask = varargin{9};
    end
end
%%
tfmat = ~cellfun('isempty',strfind(Csusu1,'.mat'));
Csusu1 = Csusu1(tfmat);
tfm = ~cellfun('isempty',strfind(Csusu1,flagname));
selecfiles = Csusu1(tfm)';
ns = numel(selecfiles);
%%
tic
for ni = 1:ns   
str = selecfiles{ni}(end-4);
try
tmp = load(strcat(subsubdir,flagslash,'mask_',num2str(str),'.mat'));
catch
    tmp = [];
end
clear dataoutshift1 dataout2 totalMask1 dim

    if ~isempty(tmp)
        try
            totalMask1 = tmp.totalMask1;
        catch
            totalMask1 = tmp.nodes;
            B = totalMask1;
        end
    else
        disp('No mask');
        totalMask1 = [];
    end
        
filetoload = strcat(subsubdir,flagslash,selecfiles{ni});

filetosave3d = strcat(subsubdir,flagslash,'GraphDelaunay3d_',num2str(str),'.mat');
filetosave2d = strcat(subsubdir,flagslash,'GraphDelaunay2d_',num2str(str),'.mat');
if dimdeluney == 3
    filetosave = filetosave3d;
elseif dimdeluney == 2
    filetosave = filetosave2d;
end
%     
if ~exist(filetosave,'file') 
tmp3d = load(filetoload,'dataoutshift1','dataout2','dim','Dp1','Dp2',...
'Vp1','Vp2','leftrightcount','updowncount','zcount');
dataoutshift1 = tmp3d.dataoutshift1;
dataout2 = tmp3d.dataout2;
dim = tmp3d.dim;
Dp1 = tmp3d.Dp1;
Dp2 = tmp3d.Dp2;
Vp1 = tmp3d.Vp1;
Vp2 = tmp3d.Vp2;
leftrightcount = tmp3d.leftrightcount;
updowncount = tmp3d.updowncount;
try
 zcount = tmp3d.zcount;
catch
    zcount = 0;
end

% if dim == 3
%      filetosave = filetosave3d;
% elseif dim == 2
%      filetosave = filetosave2d;
% end

if ~isempty(tmp)
  if ~iscell(totalMask1)
      
         x = dataoutshift1(:,[1,2]);
         y = dataout2(:,[1,2]);
        [ind1,ind2,B] = pointsINboundary(x,y,totalMask1,minregmask,pix);
        indB = ~cellfun(@isempty,B);
        B = B(indB);

        if ~isempty(ind1)
            for ii = 1:numel(ind1)
                dataoutshift1 = dataoutshift1(~ind1{ii},:);
                Dp1 = Dp1(~ind1{ii}); 
                Vp1 = Vp1(~ind1{ii});
            end    
        end
        if ~isempty(ind2)
            for ii = 1:numel(ind2)
                dataout2 = dataout2(~ind2{ii},:);
                Dp2 = Dp2(~ind2{ii}); 
                Vp2 = Vp2(~ind2{ii});
            end    
        end
  end
    clear ind1 ind2
    temp1 = [];
    temp2 = [];
    temp3 = [];
    temp4 = [];
    temp5 = [];
    temp6 = [];
    for kk = 1:numel(B)
        if ~iscell(totalMask1)
            try
                ind1 = InPolygon(dataoutshift1(:,1),dataoutshift1(:,2), B{kk}(:,2),B{kk}(:,1));
                ind2 = InPolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,2),B{kk}(:,1));
            catch
                ind1 = inpolygon(dataoutshift1(:,1),dataoutshift1(:,2), B{kk}(:,2),B{kk}(:,1));
                ind2 = inpolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,2),B{kk}(:,1));
            end
            
        else
            try
                ind1 = InPolygon(dataoutshift1(:,1),dataoutshift1(:,2), B{kk}(:,1),B{kk}(:,2));
                ind2 = InPolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,1),B{kk}(:,2));
            catch
                ind1 = inpolygon(dataoutshift1(:,1),dataoutshift1(:,2), B{kk}(:,1),B{kk}(:,2));
                ind2 = inpolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,1),B{kk}(:,2));
            end
        end
            temp1 = [temp1;dataoutshift1(ind1,:)];
            temp2 = [temp2;Dp1(ind1)]; 
            temp3 = [temp3;Vp1(ind1)];
            temp4 = [temp4;dataout2(ind2,:)];
            temp5 = [temp5;Dp2(ind2)]; 
            temp6 = [temp6;Vp2(ind2)];
    end
    dataoutshift1 = temp1;
    Dp1 = temp2;
    Vp1 = temp3;
    dataout2 = temp4;
    Dp2 = temp5;
    Vp2 = temp6;
end

clear ind1 ind2
[Gbin1,dataoutshift1,Vp1,Dp1,VorDpAll1,VorDpSum21,Vol1,Det1,WC1,...
Cen1,XYZnodes1,DpGsubMed1,AllShortPath1,DGsub1,Gsub1,G1,Pnum1,Len1] ...
= deluneyFiltClustNEW(dataoutshift1,Vp1,Dp1,dimdeluney,flag,fac1,noddeg1);
[Gbin2,dataout2,Vp2,Dp2,VorDpAll2,VorDpSum22,Vol2,Det2,WC2,Cen2,...
XYZnodes2,DpGsubMed2,AllShortPath2,DGsub2,Gsub2,G2,Pnum2,Len2] ...
= deluneyFiltClustNEW(dataout2,Vp2,Dp2,dimdeluney,flag,fac2,noddeg2);

ind1 = find(Det1 < minA1);
ind2 = find(Det2 < minA2);

Det1(ind1) = [];
VorDpSum21(ind1) = [];
VorDpAll1(ind1) = [];
DpGsubMed1(ind1) = [];
Gbin1(ind1) = [];
WC1(ind1,:) = [];
Vol1(ind1) = [];
XYZnodes1(ind1) = [];
Cen1(ind1,:) = [];
AllShortPath1(ind1) = [];
Gsub1(ind1) = [];
DGsub1(ind1,:) = [];
Pnum1(ind1,:) = [];
Len1(ind1,:) = [];

Det2(ind2) = [];
VorDpSum22(ind2) = [];
VorDpAll2(ind2) = [];
DpGsubMed2(ind2) = [];
Gbin2(ind2) = [];
WC2(ind2,:) = [];
Vol2(ind2) = [];
XYZnodes2(ind2) = [];
Cen2(ind2,:) = [];
AllShortPath2(ind2,:) = [];
DGsub2(ind2) = [];
Gsub2(ind2) = [];
Pnum2(ind2,:) = [];
Len2(ind2,:) = [];
[pcacoeff1,pcascore1,pcalatent1,pcaexplained1,ratio1] = cellfun(@pcaOnGraph,XYZnodes1,'UniformOutput',false);
[pcacoeff2,pcascore2,pcalatent2,pcaexplained2,ratio2] = cellfun(@pcaOnGraph,XYZnodes2,'UniformOutput',false);
ratio1 = cell2mat(ratio1);
ratio2 = cell2mat(ratio2);

% max2AllShortPath1 = cell2mat(cellfun(@max,AllShortPath1,'UniformOutput',false));
% max2AllShortPath2 = cell2mat(cellfun(@max,AllShortPath2,'UniformOutput',false));                

[Ani1,AniMed1,~,MedShortPath1,extension1,extensionIND1] = ...
    cellfun(@graphsizemeasures,XYZnodes1,num2cell(Cen1,2),DGsub1,'UniformOutput',false);
[Ani2,AniMed2,~,MedShortPath2,extension2,extensionIND2] = ...
    cellfun(@graphsizemeasures,XYZnodes2,num2cell(Cen2,2),DGsub2,'UniformOutput',false);
AniMed1 = cell2mat(AniMed1);
MedShortPath1 = cell2mat(MedShortPath1);
extension1 = cell2mat(extension1);
extensionIND1 = cell2mat(extensionIND1);
AniMed2 = cell2mat(AniMed2);
MedShortPath2 = cell2mat(MedShortPath2);
extension2 = cell2mat(extension2);
extensionIND2 = cell2mat(extensionIND2);

[var1,var2,varSort2,dist1nn,CW1toCW2sort,ind12C2C] = ...
 colocGraphClustNEW(WC1,WC2,VorDpSum21,VorDpSum22,Vol1,...
 Vol2,Det1,Det2,XYZnodes1,XYZnodes2,DpGsubMed1,DpGsubMed2,numnn,flag,...
 extension1,extension2,ratio1,ratio2,Pnum1,Pnum2,Len1,Len2);


%%
clear varColend1 varColend2
[minDE1,minDE2,minDE1ind,minDE2ind,DE1,DE2] = graphNNED(extensionIND1,XYZnodes1,XYZnodes2);
varColend1(:,1) = minDE1;
varColend1(:,2) = minDE1ind;
varColend1(:,3) = Det2(minDE1ind);
varColend1(:,4) = extension2(minDE1ind);
varColend1(:,5) = MedShortPath2(minDE1ind);
varColend1(:,6) = AniMed2(minDE1ind);
varColend1(:,7) = Pnum2(minDE1ind);
varColend1(:,8) = Len2(minDE1ind);

varColend2(:,1) = minDE2;
varColend2(:,2) = minDE2ind;
varColend2(:,3) = Det2(minDE2ind);
varColend2(:,4) = extension2(minDE2ind);
varColend2(:,5) = MedShortPath2(minDE2ind);
varColend2(:,6) = AniMed2(minDE2ind);
varColend2(:,7) = Pnum2(minDE2ind);
varColend2(:,8) = Len2(minDE2ind);
frame1 = max(unique(dataoutshift1(:,6)));
frame2 = max(unique(dataout2(:,6)));

clear ind1 CellArea
if ~isempty(tmp)
for kk = 1:numel(B)
if ~iscell(totalMask1)
    try
        ind1{kk} = InPolygon(WC1(:,1),WC1(:,2), B{kk}(:,2),B{kk}(:,1));
    catch
        ind1{kk} = inpolygon(WC1(:,1),WC1(:,2), B{kk}(:,2),B{kk}(:,1));
    end
else
    try
        ind1{kk} = InPolygon(WC1(:,1),WC1(:,2), B{kk}(:,1),B{kk}(:,2));
    catch
        ind1{kk} = inpolygon(WC1(:,1),WC1(:,2), B{kk}(:,1),B{kk}(:,2));
    end
end
% ind2{kk} = InPolygon(WC2(:,1),WC2(:,2), B{kk}(:,2),B{kk}(:,1));
if ~iscell(totalMask1)
    CellArea(kk,1) = numel(B{kk}(:,2))*pix*pix;
else
    CellArea(kk,1) = abs(polyarea(B{kk}(:,1),B{kk}(:,2)));
end
CellArea(kk,2)= numel(find(CW1toCW2sort(ind1{kk},1) <= distcoloc));
CellArea(kk,3)= numel(find(dist1nn(ind1{kk},1) <= distcoloc));
CellArea(kk,4) = numel(CW1toCW2sort(ind1{kk},1));
CellArea(kk,5) = CellArea(kk,2)/CellArea(kk,4);
CellArea(kk,6) = CellArea(kk,3)/CellArea(kk,4);
end
else
    CellArea = [];
    ind1 = [];
end
save(filetosave,'var1','var2','varSort2','dist1nn','CW1toCW2sort',...
'Gbin1','ind12C2C','VorDpAll1','XYZnodes1','Gbin2','VorDpAll2','XYZnodes2',...
'minA2','minA1','dataoutshift1','dataout2','fac1','fac2',...
'AllShortPath2','DGsub2','Gsub2','AllShortPath1','DGsub1','Gsub1','G1','G2',...
'ratio1','ratio2','pcacoeff1','pcascore1','pcalatent1','pcaexplained1',...
'pcacoeff2','pcascore2','pcalatent2','pcaexplained2',...
'Vp1','Dp1','VorDpSum21','Vol1','Det1','WC1','Cen1','DpGsubMed1',...
'Vp2','Dp2','VorDpSum22','Vol2','Det2','WC2','Cen2','DpGsubMed2',...
'dim','minregmask','flag','leftrightcount','updowncount','zcount',...
'dimdeluney','AniMed1','MedShortPath1','extension1','extensionIND1','minDE1ind','minDE2ind',...
'AniMed2','MedShortPath2','extension2','extensionIND2','frame1','frame2','Len1','Len2','Pnum1','Pnum2',...
'Ani1','Ani2','noddeg2','noddeg1',...
'varColend2','varColend1','DE1','DE2','CellArea','distcoloc','numnn','pix','-v7.3') 
   disp(strcat('Saved: ','  ',filetosave)); 
else
   disp(strcat('Already Analysed: ','  ',filetosave));
end
end
end
