function [xy3,xy4] = perCaps(xy1,xy2,N)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
x1 = xy1(1);
y1 = xy1(2);
x2 = xy2(1);
y2 = xy2(2);
dx = x1-x2;
dy = y1-y2;
dist = sqrt(dx*dx + dy*dy);
dx = dx/dist;
dy = dy/dist;
x3 = x1 + (N/2)*dy;
y3 = y1 - (N/2)*dx;
x4 = x1 - (N/2)*dy;
y4 = y1 + (N/2)*dx;
xy3 = [x3,y3];
xy4 = [x4,y4];
end

