function batchProcessVoronoi1color(Csusu,subsubdir,flagch,flag,...
fac,photonTH,locprec,densitythrIN,ch,saveflag,varargin)
% batchProcessVoronoi1color is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
tic
if ~ismac
    flagslash = '\'; 
else
    flagslash = '/';
end
if iscell(Csusu)
    tfmChanel = ~cellfun('isempty',strfind(Csusu,flagch));
    Csusu1 = Csusu(tfmChanel); 
else
    Csusu1{1} = Csusu;
end
tfmat = ~cellfun('isempty',strfind(Csusu1,'.mat'));
Csusu1 = Csusu1(tfmat);
tfmat = ~cellfun('isempty',strfind(Csusu1,'Xwc'));
Csusu1 = Csusu1(tfmat);
tfmat = cellfun('isempty',strfind(Csusu1,'Single'));
Csusu1 = Csusu1(tfmat);
tfmat = cellfun('isempty',strfind(Csusu1,'Aligned'));
Csusu1 = Csusu1(tfmat);
tfmat = cellfun('isempty',strfind(Csusu1,'Filtalgn'));
Csusu1 = Csusu1(tfmat);
tfmat = cellfun('isempty',strfind(Csusu1,'ReThr'));
Csusu1 = Csusu1(tfmat);

if nargin == 11
    dimn = varargin{1};
else
    dimn = [];
end

nf = numel(Csusu1);
for fi = 1:nf
    namech = Csusu1{fi};
    loadChanel = load(strcat(subsubdir,flagslash,namech));

    if densitythrIN
        [dataout,densitythr,dim,Vp,Dp] = voronoiData(loadChanel,...
            photonTH,locprec,densitythrIN,flag(1),fac(1),dimn); 
    else
        [dataout,densitythr,dim,Vp,Dp] = voronoiData(loadChanel,...
            photonTH,locprec,[],flag(1),fac(1),dimn); 
    end

    
    if ch == 1
        
        filetosave = strcat(subsubdir,flagslash,saveflag,flagch,'_',...
        namech(end-23),'.mat');
        dataout1 = dataout; densitythr1 = densitythr;Vp1 = Vp;Dp1 = Dp;
        namech1 = namech;photonTH1 = photonTH;locprec1 = locprec;
        save(filetosave,'dataout1',...
        'densitythr1','Vp1','dim','namech1','Dp1','ch',...
        'photonTH1','locprec1')
        
    elseif ch == 2
        filetosave = strcat(subsubdir,flagslash,saveflag,flagch,'_',...
        namech(end-23),'.mat');
        dataout2 = dataout; densitythr2 = densitythr;Vp2 = Vp;Dp2 = Dp;
        namech2 = namech;photonTH2 = photonTH;locprec2 = locprec;
        save(filetosave,'dataout2',...
        'densitythr2','Vp2','dim','namech2','Dp2','ch',...
        'photonTH2','locprec2');

    end
    disp(strcat('Saved: ','   ',filetosave))
    toc
    clear dataout densitythr Vp Dp  namech
end