function [Vp,VOLp,vfilt,cfilt,datatesseler] = voronoicustom(datatesseler,dim)
 % voronoicustom is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
if dim == 3
    x = [datatesseler(:,1),datatesseler(:,2),datatesseler(:,6)];
elseif dim == 2
    x = [datatesseler(:,1),datatesseler(:,2)]; 
end
[x,ia] = unique(x,'rows','stable');
try
[v,c] = voronoin(x);
vx{1} = v;
vx1 = repmat(vx,[numel(c),1]);
datatesseler = datatesseler(ia,:);
%%
indno1 = cellfun(@(xx)all(xx~=1),c);
%%
cfilt = c;
cfilt(~indno1) = [];
vfilt = vx1;
vfilt(~indno1) = [];
datatesseler = datatesseler(indno1,:);
%%
if dim == 3
    [Vp,VOLp] = cellfun(@voronoinVert3d,cfilt,vfilt,'UniformOutput',false);
elseif dim == 2
    [Vp,VOLp] = cellfun(@voronoinVert,cfilt,vfilt,'UniformOutput',false);
end
%%
VOLp = cell2mat(VOLp);
VOLp = VOLp(:);
%%
ind=cellfun(@isempty,Vp);
tmp = Vp(~ind);
Vp = tmp;
VOLp(ind) = [];
datatesseler(ind,:) = [];
vfilt = vfilt{1};
catch
VOLp = [];
vfilt = [];
cfilt = [];
Vp = [];
end
function [Vp,Ap] = voronoinVert(c,v)
   Vp = [v(c,1),v(c,2)];
   Ap = polyarea(v(c,1),v(c,2));
end
function [Vp,Vol] = voronoinVert3d(c,v)
   Vp = [v(c,1),v(c,2),v(c,3)];
   [~, Vol] = convhull(v(c,1),v(c,2),v(c,3));
end
end