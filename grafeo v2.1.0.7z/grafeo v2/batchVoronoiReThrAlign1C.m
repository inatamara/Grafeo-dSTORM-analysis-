function batchVoronoiReThrAlign1C(Csusu,subsubdir,flag,...
fac,photonTH,locprec,densitythrIN,searchstring,ch,saveflag,varargin)
 % batchVoronoiReThrAlign1C is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

if ~ismac
    flagslash = '\'; 
else
    flagslash = '/';
end
 
tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
Csusu1 = Csusu(tfmat);
tfm = ~cellfun('isempty',strfind(Csusu1,searchstring));
selecfiles = Csusu1(tfm);
ns = numel(selecfiles);

if nargin == 11
    dimn = varargin{1};
else
    dimn = [];
end
tic
for ni = 1:ns   
    filetoload = strcat(subsubdir,flagslash,selecfiles{ni});
    names = strrep(filetoload,searchstring,saveflag);
    if ~exist(names,'file')
        if ch == 1
            tmp = load(filetoload,'dim','namech1');
            namech1 = tmp.namech1;
            loadChanel1 = load(strcat(subsubdir,flagslash,namech1));
            if densitythrIN
                [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
                    photonTH,locprec,densitythrIN,flag(1),fac(1),dimn); 
            else
                [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
                    photonTH,locprec,[],flag(1),fac(1),dimn); 
            end
            photonTH1 = photonTH; locprec1 = locprec;
            save(names,'dataout1',...
            'densitythr1','Vp1',...
            'dim','namech1','Dp1','photonTH1','locprec1','ch')
        
        
        elseif ch == 2
            tmp = load(filetoload,'dim','namech2');
            namech2 = tmp.namech2;
            loadChanel2 = load(strcat(subsubdir,flagslash,namech2));
            if densitythr
                [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
                    photonTH,locprec,densitythr,flag(1),fac(1),dimn); 
            else
                [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
                    photonTH,locprec,[],flag(1),fac(1),dimn); 
            end
            photonTH2 = photonTH; locprec2 = locprec;
            save(names,'dataout2',...
            'densitythr2','Vp2',...
            'dim','namech2','Dp2','photonTH2','locprec2','ch')
        
        end
        
         disp(strcat('saved: ','   ', names))

    else
        disp('Already exist')
    end
end
toc

end
