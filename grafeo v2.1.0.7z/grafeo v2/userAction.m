function progress = userAction(string,varargin)
% userAction is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

if nargin == 1
    [selectedButton] = uigetpref(...
    'none',...                        % Group
    'none',...           % Preference
    'chose option... ...',...                    % Window title
    {string
     ''
     'Press YES if you agree'''},...
    {'always','never';'Yes','No'},...        % Values and button strings
     'DefaultButton','Cancel');        % Callback for Help button
switch selectedButton
    case 'always'  
        progress = 1;
    case 'never'                
        progress = 0;
    case 'cancel'               
       return
end
elseif nargin == 2
[selectedButton] = uigetpref(...
    'none',...                        % Group
    'none',...           % Preference
    'chose option... ...',...                    % Window title
    {string
     ''
     'Press YES if you agree'''},...
    {'always','never','ones';'Yes','No',varargin{1}},...        % Values and button strings
     'DefaultButton','Cancel');        % Callback for Help button
switch selectedButton
    case 'always'  
        progress = 1;
    case 'never'                
        progress = 0;
    case 'ones'
        progress = 2;
    case 'cancel'               
       return
end

elseif nargin == 3
[selectedButton] = uigetpref(...
    'none',...                        % Group
    'none',...           % Preference
    'chose option... ...',...                    % Window title
    {string
     ''
     'Press YES if you agree'''},...
    {'always','never','ones','twice';'Yes','No',varargin{1},varargin{2}},...        % Values and button strings
     'DefaultButton','Cancel');        % Callback for Help button
switch selectedButton
    case 'always'  
        progress = 1;
    case 'never'                
        progress = 0;
    case 'ones'
        progress = 2;
    case 'twice'
        progress = 3;
    case 'cancel'               
       return
end

elseif nargin == 4
[selectedButton] = uigetpref(...
    'none',...                        % Group
    'none',...           % Preference
    'chose option... ...',...                    % Window title
    {string
     ''
     'Press YES if you agree'''},...
    {'always','never','ones','twice','three';'Yes','No',varargin{1},varargin{2},varargin{3}},...        % Values and button strings
     'DefaultButton','Cancel');        % Callback for Help button
switch selectedButton
    case 'always'  
        progress = 1;
    case 'never'                
        progress = 0;
    case 'ones'
        progress = 2;
    case 'twice'
        progress = 3;
    case 'three'
        progress = 4;
    case 'cancel'               
       return
end
   
 end