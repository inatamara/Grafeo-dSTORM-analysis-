function im = scatt2im(dataout,pixel,N,varargin)

 % scatt2im is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

 ind1 = find(dataout(:,1) <=0);
  if ~isempty(ind1)
    dataout(ind1,:) = [];      
  end
   ind1 = find(dataout(:,1) > N(1));
  if ~isempty(ind1)
    dataout(ind1,:) = [];      
  end
  
  ind1 = find(dataout(:,2) <=0);
  if ~isempty(ind1)
    dataout(ind1,:) = [];      
  end
  
    ind1 = find(dataout(:,2) > N(2));
  if ~isempty(ind1)
    dataout(ind1,:) = [];      
  end
  
%     XYZ = [int64(dataout(:,[1,2])),int64(dataout(:,3))];
    binrangesx = int32([1:pixel:N(1)]');%,[1:pix:Nmax]'];
    binrangesy = int32([1:pixel:N(2)]');%,[1:pix:Nmax]'];
    xbins = binrangesx;
    ybins = binrangesy;
    Xs = dataout(:,1);
    Ys = dataout(:,2);
    if nargin == 3
        Zs = ones(numel(dataout(:,1)),1);
    elseif nargin == 4 & varargin{1} ~= 0
        Zs = dataout(:,3);  
    elseif nargin == 4 & varargin{1} == 0
        Zs = ones(numel(dataout(:,1)),1);
    end
% work out which bin each X and Y is in (idxx, idxy)
[~, idxx] = histc(Xs, xbins);
[~, idxy] = histc(Ys, ybins);

  ind1 = find(idxx == 0 | idxy == 0) ;
  if ~isempty(ind1)
    idxx(ind1) = [];      
    idxy(ind1) = [];  
    Zs(ind1) = [];
  end
% calculate mean in each direction
im = accumarray([idxy idxx],Zs,round([N(2)/pixel,N(1)/pixel]));     
end