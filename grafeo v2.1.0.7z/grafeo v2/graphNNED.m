function [minDE1,minDE2,minDE1ind,minDE2ind,DE1,DE2] = graphNNED( mSHpI1,XYZcell12d,XYZcell2d )
% graphNNED is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
DE1 = zeros(numel(XYZcell12d),numel(XYZcell2d));
DE2 = zeros(numel(XYZcell12d),numel(XYZcell2d));
E1 = zeros(numel(XYZcell12d),2);
E2 = zeros(numel(XYZcell12d),2);
for ii = 1:numel(XYZcell12d)
    E1(ii,:) = XYZcell12d{ii}(mSHpI1(ii,2),1:2);
    E2(ii,:) = XYZcell12d{ii}(mSHpI1(ii,1),1:2);
    
    for jj = 1:numel(XYZcell2d)
        d1 = pdist2(E1(ii,:),XYZcell2d{jj}(:,1:2))';
        d2 = pdist2(E2(ii,:),XYZcell2d{jj}(:,1:2))';
        DE1(ii,jj) = min(d1);
        DE2(ii,jj) = min(d2);
    end
end

[minDE1,minDE1ind] = min(DE1,[],2);
[minDE2,minDE2ind] = min(DE2,[],2);
end
