function [var1,var2,varSort2,dist1nn,CW1toCW2sort,in12] = ...
    colocGraphClustNEW(WC1,WC2,VorD1,VorD2,Vol1,Vol2,Det1,Det2,XYZcell1,...
    XYZcell2,DpGmed1,DpGmed2,numnn,flag,max2maxDGsub1,max2maxDGsub2,ratio1,ratio2,Pnum1,Pnum2,Len1,Len2)
% colocGraphClustNEW is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018


nc1 = size(WC1,1);
nc2 = size(WC2,1);
Dwc12 = pdist2(WC1,WC2);
[CW1toCW2sort,in12] = sort(Dwc12,2);
VorD1_12 = repmat(VorD1,[1,nc2]);
VorD2_12= repmat(VorD2',[nc1,1]);

Vol1_12 = repmat(Vol1,[1,nc2]);
Vol2_12= repmat(Vol2',[nc1,1]);

Det1_12 = repmat(Det1,[1,nc2]);
Det2_12= repmat(Det2',[nc1,1]);

DpGmed1_12 = repmat(DpGmed1,[1,nc2]);
DpGmed2_12= repmat(DpGmed2',[nc1,1]);

maxD1 =  repmat(max2maxDGsub1,[1,nc2]);
maxD2 =  repmat(max2maxDGsub2',[nc1,1]);

rat1 =  repmat(ratio1,[1,nc2]);
rat2 =  repmat(ratio2',[nc1,1]);

Pn1 =  repmat(Pnum1,[1,nc2]);
Pn2 =  repmat(Pnum2',[nc1,1]);

Ln1 =  repmat(Len1,[1,nc2]);
Ln2 =  repmat(Len2',[nc1,1]);

VorD2_12sort = VorD2_12(in12);
Det2_12sort = Det2_12(in12);
Vol2_12sort = Vol2_12(in12);
DpGmed2_12sort = DpGmed2_12(in12);
maxD2_12sort = maxD2(in12);
DpGmed2_12sort = DpGmed2_12(in12);

rat2sort = rat2(in12);
Pn2sort = Pn2(in12);
Ln2sort = Ln2(in12);

dist1nn = zeros(nc1,12);
for ni =1:nc1
  Vol2_12sort(ni,:) =  Vol2(in12(ni,:)) ;
  VorD2_12sort(ni,:) =  VorD2(in12(ni,:)) ;
  Det2_12sort(ni,:) =  Det2(in12(ni,:)) ;
  DpGmed2_12sort(ni,:) =  DpGmed2(in12(ni,:)) ;
  maxD2_12sort(ni,:) =  max2maxDGsub2(in12(ni,:)) ;
  rat2sort(ni,:) =  ratio2(in12(ni,:)) ;
  Pn2sort(ni,:) =  Pnum2(in12(ni,:)) ;
  Ln2sort(ni,:) =  Len2(in12(ni,:)) ;
  
  x = XYZcell1{ni}(:,1:2);
  y = XYZcell2{in12(ni,1)}(:,1:2);
  dist1nn(ni,1) = median(knnsearchThr(y,x,numnn,flag));
  dist1nn(ni,2) = median(knnsearchThr(x,y,numnn,flag));
  dist1nn(ni,3) = mean(knnsearchThr(y,x,numnn,flag));
  dist1nn(ni,4) = mean(knnsearchThr(x,y,numnn,flag));
  dist1nn(ni,5) = std(knnsearchThr(y,x,numnn,flag));
  dist1nn(ni,6) = std(knnsearchThr(x,y,numnn,flag));
  dist1nn(ni,7) = dist1nn(ni,5)./sqrt(numel(knnsearchThr(y,x,numnn,flag)));
  dist1nn(ni,8) = dist1nn(ni,6)./sqrt(numel(knnsearchThr(x,y,numnn,flag)));
  dist1nn(ni,9) = min(knnsearchThr(y,x,numnn,flag));
  dist1nn(ni,10) = min(knnsearchThr(x,y,numnn,flag));
  dist1nn(ni,11) = max(knnsearchThr(y,x,numnn,flag));
  dist1nn(ni,12) = max(knnsearchThr(x,y,numnn,flag));
  
end

var1(:,:,1) = VorD1_12;
var1(:,:,2) = Vol1_12;
var1(:,:,3) = Det1_12;
var1(:,:,4) = DpGmed1_12;
var1(:,:,5) = maxD1;
var1(:,:,6) = rat1;
var1(:,:,7) = Pn1;
var1(:,:,8) = Ln1;

var2(:,:,1) = VorD2_12;
var2(:,:,2) = Vol2_12;
var2(:,:,3) = Det2_12;
var2(:,:,4) = DpGmed2_12;
var2(:,:,5) = maxD2;
var2(:,:,6) = rat2;
var2(:,:,7) = Pn2;
var2(:,:,8) = Ln2;

varSort2(:,:,1) = VorD2_12sort;
varSort2(:,:,2) = Vol2_12sort;
varSort2(:,:,3) = Det2_12sort;
varSort2(:,:,4) = DpGmed2_12sort;
varSort2(:,:,5) = maxD2_12sort;
varSort2(:,:,6) = rat2sort;
varSort2(:,:,7) = Pn2sort;
varSort2(:,:,8) = Ln2sort;

var2 = squeeze(var2(1,:,:));
var1 = squeeze(var1(:,1,:));
end

