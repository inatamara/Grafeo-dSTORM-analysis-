 function [Ksim12,Ksim21,K12,K21,Lsim12,Lsim21,L12,L21,Ksim1,Ksim2,Lsim1,Lsim2,Khat1,Khat2,Lhat1,...
     Lhat2,KdMs,LdMs,KdM,LdM,C1r,C2r,inPoint1,inPoint2,lam11,lam22,lam12,lam21,vol,inPoint1r,inPoint2r] = ...
     randomizationRiplays2col3D(c1,c2,Nsimul,D,mask,pix,dim,boundarycorrection,varargin)
 % randomizationRiplays2col3D is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
p = 0;
tic
minregmask = 1000;
zb = -400;
ze = 400;
mult = 5;
unitfactor = 10^-3;

if nargin >=9
    if ~isempty(varargin{1}) | varargin{1} > 0
        minregmask = varargin{1};
    end
end
% only for 3D ripley, zb:ze - z range
if nargin >= 10
    if ~isempty(varargin{2}) | varargin{1}(1) > 0
        zb = varargin{2};
    end
    if ~isempty(varargin{2}) | varargin{2}(2) > 0
        ze = varargin{2};
    end
end

if nargin >=11
    if ~isempty(varargin{3}) | varargin{3} > 0
        mult = varargin{3};
    end
end

if nargin >=12
    if ~isempty(varargin{4}) | varargin{4} > 0
        p = varargin{4};
    end
end

if nargin >=13
    if ~isempty(varargin{5}) | varargin{5} > 0
        unitfactor = varargin{5};
    end
end
%%
if numel(c1(:,1)) ==  numel(c2(:,1))
    colflag = sum(c1 - c2); % valid for 2 color
else
    colflag = 1;
end

if  ~iscell(mask)
    mask = bwareaopen(mask,minregmask);
    CC = bwconncomp(mask);
    LM = labelmatrix(CC);
    [B,~,~,A] = bwboundaries(mask);
    if ~isempty(pix)
        for ii = 1:numel(B)
            B{ii} = B{ii}*pix;
        end
    end
else
    B = mask;
end
N = numel(B);

if boundarycorrection
    bcor = 1;
else
    bcor = [];
end
% Loop through object boundaries
if ~iscell(mask) % only for image masks
    flag = 0;
    for k = 1:N
        
        % Boundary k is the parent of a hole if the k-th column
        % of the adjacency matrix A contains a non-zero element
            if (nnz(A(:,k)) > 0)
                for l = find(A(:,k))'
                    l
                    flag = flag + 1;
                    boundary = B{l};
                    try
                        ind1 = InPolygon(c1(:,1),c1(:,2), boundary(:,2),boundary(:,1));
                        if colflag
                            ind2 = InPolygon(c2(:,1),c2(:,2), boundary(:,2),boundary(:,1));  
                        end
                    catch
                        ind1 = inpolygon(c1(:,1),c1(:,2), boundary(:,2),boundary(:,1));
                        if colflag
                            ind2 = inpolygon(c2(:,1),c2(:,2), boundary(:,2),boundary(:,1));  
                        end
                    end
                    c1 = c1(~ind1,:); 
                    if colflag
                        c2 = c2(~ind2,:);
                    end
                    B{l} = [];
                end
            end
    end

if flag
    indB = ~cellfun(@isempty,B);
    B = B(indB);
end
end
numo = numel(B);
nD = length(D);
C1r = cell(numo,1);
C2r = cell(numo,1);
Ksim1 = zeros(nD,Nsimul,numo);
Ksim12 = zeros(nD,Nsimul,numo);
Lsim1 = zeros(nD,Nsimul,numo);
Lsim12 = zeros(nD,Nsimul,numo);
Ksim21 = zeros(nD,Nsimul,numo);
Lsim21 = zeros(nD,Nsimul,numo);
inPoint1r = zeros(Nsimul,numo);
inPoint2r = zeros(Nsimul,numo);
KdMs = zeros(nD,Nsimul,numo);
LdMs = ones(nD,Nsimul,numo);
Ksim2 = zeros(nD,Nsimul,numo);
Lsim2 = zeros(nD,Nsimul,numo);
Khat2 = zeros(nD,numo);
Lhat2 = zeros(nD,numo);
Khat1 = zeros(nD,numo);
Lhat1 = zeros(nD,numo);
K12 = zeros(nD,numo);
L12 = zeros(nD,numo);
K21 = zeros(nD,numo);
L21 = zeros(nD,numo);
KdM = zeros(nD,numo);
LdM = zeros(nD,numo);
lam11 = zeros(numo,1);
lam21 = zeros(numo,1);
lam12 = zeros(numo,1);
lam22 = zeros(numo,1);
vol = zeros(numo,1);
inPoint2 = zeros(numo,1);
inPoint1 = zeros(numo,1);
%%
for kk = 1:numo
    
if ~iscell(mask)
    try
        ind1 = InPolygon(c1(:,1),c1(:,2), B{kk}(:,2),B{kk}(:,1));
        if colflag
            ind2 = InPolygon(c2(:,1),c2(:,2), B{kk}(:,2),B{kk}(:,1));
        end
    catch
         ind1 = inpolygon(c1(:,1),c1(:,2), B{kk}(:,2),B{kk}(:,1));
         if colflag
            ind2 = inpolygon(c2(:,1),c2(:,2), B{kk}(:,2),B{kk}(:,1));
         end
    end
else
    try
        ind1 = InPolygon(c1(:,1),c1(:,2), B{kk}(:,1),B{kk}(:,2));
        if colflag
            ind2 = InPolygon(c2(:,1),c2(:,2), B{kk}(:,1),B{kk}(:,2));
        end
    catch
        ind1 = inpolygon(c1(:,1),c1(:,2), B{kk}(:,1),B{kk}(:,2));
        if colflag
            ind2 = inpolygon(c2(:,1),c2(:,2), B{kk}(:,1),B{kk}(:,2));
        end
    end
end

sprintf('Finished InPolygon %d of %d',kk,numo)    
C1 = c1(ind1,:);  
n1 = size(C1,1);
inPoint1(kk) = n1;
if colflag
    C2 = c2(ind2,:);  
    n2 = size(C2,1);
    inPoint2(kk) = n2;
end

if ~iscell(mask)
    [rm,cm] = find(LM==kk);
    BW = LM==kk;
    if ~isempty(pix)
        R1 = [cm,rm]*pix; 
    else
        R1 = [cm,rm];
    end

else
    R1 = B{kk};
    BW = B;
end
xb = min(R1(:,1));
xe = max(R1(:,1));
yb = min(R1(:,2));
ye = max(R1(:,2));

%% spatial statistics
if colflag
    sprintf('Ripley0 2-2, boundary %d out of %d',kk, numo)
    [Khat2(:,kk),Lhat2(:,kk)] = ripleysK3DsM(C2,BW,D,p,dim,pix,bcor,unitfactor);
end
% observed function
sprintf('Ripley 1-1, boundary %d out of %d',kk, numo)
[Khat1(:,kk),Lhat1(:,kk)] = ripleysK3DsM(C1,BW,D,p,dim,pix,bcor,unitfactor);
% observed dual K12, K21 and L12,L21, KdM and LdM
if colflag
    sprintf('Ripley 1-2,2-1, boundary %d out of %d',kk, numo)
    [K12(:,kk),L12(:,kk),lam11(kk),lam21(kk),vol(kk)] = ripleysKd3DsM(C1,C2,BW,D,p,dim,pix,bcor,unitfactor);
    [K21(:,kk),L21(:,kk),lam12(kk),lam22(kk)] = ripleysKd3DsM(C2,C1,BW,D,p,dim,pix,bcor,unitfactor);

    KdM(:,kk) = (K12(:,kk)*inPoint2(kk) + K21(:,kk)*inPoint1(kk))/(inPoint1(kk) + inPoint2(kk));

    if dim == 3
        LdM(:,kk) = nthroot(3*KdM(:,kk)/pi/4,3) - D(:)*unitfactor;
    elseif dim == 2
        LdM(:,kk) = sqrt(KdM(:,kk)/pi) - D(:)*unitfactor;
    end
end
%% variable initiation for randomization
rng('shuffle')

for i = 1:Nsimul
    sprintf('Simulation %d',i)
    clear RP1x RP1y RP1z
    RP1x = (xe-xb).*rand(mult*n1,1) + xb;
    RP1y = (ye-yb).*rand(mult*n1,1) + yb;
    if dim == 3
    RP1z = (ze-zb).*rand(mult*n1,1) + zb;
    end
    if ~iscell(mask)
        try
            ind = InPolygon(RP1x,RP1y, B{kk}(:,2),B{kk}(:,1));
        catch
            ind = inpolygon(RP1x,RP1y, B{kk}(:,2),B{kk}(:,1));
        end
    else
        try
             ind = InPolygon(RP1x,RP1y, B{kk}(:,1),B{kk}(:,2));
        catch
             ind = inpolygon(RP1x,RP1y, B{kk}(:,1),B{kk}(:,2));
        end
    end
        
    RP1x = RP1x(ind)';
    RP1y = RP1y(ind)';
    if dim == 3
    RP1z = RP1z(ind)';   
    end
    if numel(RP1x) > n1
        RP1x = RP1x(1:n1);
        RP1y = RP1y(1:n1);
        if dim == 3
        RP1z = RP1z(1:n1);
        end
    end
    C1r{kk}(:,2,i) = RP1y;
    C1r{kk}(:,1,i) = RP1x;
    if dim == 3
    C1r{kk}(:,3,i) = RP1z;
    end
    inPoint1r(i,kk) = size(C1r{kk}(:,2,i),1);
    sprintf('Simul %d, Ripley 1-1, boundary %d out of %d',i, kk, numo)
    [Ksim1(:,i,kk),Lsim1(:,i,kk)] = ripleysK3DsM(C1r{kk}(:,:,i),BW,D,p,dim,pix,bcor,unitfactor);
    
    if colflag
        sprintf('Simul %d, Ripley 1-2,2-1, boundary %d out of %d',i, kk, numo)
        [Ksim12(:,i,kk),Lsim12(:,i,kk)] = ripleysKd3DsM(C1r{kk}(:,:,i),C2,BW,D,p,dim,pix,bcor,unitfactor);
        [Ksim21(:,i,kk),Lsim21(:,i,kk)] = ripleysKd3DsM(C2,C1r{kk}(:,:,i),BW,D,p,dim,pix,bcor,unitfactor);
        KdMs(:,i,kk) = (Ksim12(:,i,kk)*inPoint2(kk) + Ksim21(:,i,kk)*inPoint1r(i,kk))/(inPoint1r(i,kk) + inPoint2(kk));

        if dim == 2
            LdMs(:,i,kk) = sqrt(KdMs(:,i,kk)/pi) - D(:)*unitfactor;
        elseif dim == 3
            LdMs(:,i,kk) = nthroot(3*KdMs(:,i,kk)/pi/4,3) - D(:)*unitfactor;
        end
        clear RP1x RP1y RP1z RP2x RP2y RP2z

        RP2x = (xe-xb).*rand(mult*n2,1) + xb;
        RP2y = (ye-yb).*rand(mult*n2,1) + yb;
        if dim == 3
        RP2z = (ze-zb).*rand(mult*n2,1) + zb;
        end
        if ~iscell(mask)
            try
                 ind = InPolygon(RP2x,RP2y, B{kk}(:,2),B{kk}(:,1));
            catch
                 ind = inpolygon(RP2x,RP2y, B{kk}(:,2),B{kk}(:,1));
            end
        else
            try
                ind = InPolygon(RP2x,RP2y, B{kk}(:,1),B{kk}(:,2));
            catch
                 ind = inpolygon(RP2x,RP2y, B{kk}(:,1),B{kk}(:,2));
            end
        end

        RP2x = RP2x(ind)';
        RP2y = RP2y(ind)';
        if dim == 3
        RP2z = RP2z(ind)';  
        end
        if numel(RP2x) > n2
            RP2x = RP2x(1:n2);
            RP2y = RP2y(1:n2);
            if dim == 3
            RP2z = RP2z(1:n2);
            end
        end
        C2r{kk}(:,2,i) = RP2y;
        C2r{kk}(:,1,i) = RP2x;
        if dim == 3
        C2r{kk}(:,3,i) = RP2z;
        end

        inPoint2r(i,kk) = size(C2r{kk}(:,2,i),1);
        sprintf('Simul %d, Ripley 1-1, boundary %d out of %d',i, kk, numo)
        [Ksim2(:,i,kk),Lsim2(:,i,kk),] = ripleysK3DsM(C2r{kk}(:,:,i),BW,D,p,dim,pix,bcor,unitfactor);
    end

end
end
toc
end
