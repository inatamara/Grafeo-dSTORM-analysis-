% function [xy3,xy4] = midlineroi(nodes,N)
for kk = 1:numel(nodes)
close all
clc
seg = nodes{kk};
np = numel(seg(:,1));
figure;
plot(seg(:,1),seg(:,2),'.-b')
hold on;
N = 1000;

for i = 1:np
    if i < np
    xy1 = [seg(i,1),seg(i,2)];
    xy2 = [seg(i+1,1),seg(i+1,2)];
    [xy3(i,:),xy4(i,:)] = perCaps(xy1,xy2,N);
    else
       xy1 = [seg(i,1),seg(i,2)];
       xy2 = [seg(i-1,1),seg(i-1,2)];  
       [xy4(i,:),xy3(i,:)] = perCaps(xy1,xy2,N);
    end
plot(xy3(i,1),xy3(i,2),'.-r')
plot(xy4(i,1),xy4(i,2),'.-r')
end
plot(xy3(:,1),xy3(:,2),'.-g')
plot(xy4(:,1),xy4(:,2),'.-m')

uproi = [seg;flipud(xy3);seg(1,:)];
downroi = [seg;flipud(xy4);seg(1,:)];
figure;
plot(uproi(:,1),uproi(:,2),'.-g')
hold on;
plot(downroi(:,1),downroi(:,2),'.--m')
end

