function deleteBadFiles(Csusu,subsubdir)
% deleteBadFiles is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
if ~ismac
    flagslash = '\';
else
    flagslash = '/';
end
% tfmat = ~cellfun('isempty',strfind(Csusu,'.tif'));
% if isempty(tfmat)
%     return
% end
% Csusu1 = Csusu(tfmat)';

% tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
% Csusu1 = Csusu(tfmat)';
% tfm = ~cellfun('isempty',strfind(Csusu1,'Xwc')); %reanalyse3D_1
% selecfiles = Csusu1(tfm);
% ns = numel(selecfiles);
% for ni = 1:ns
%     filename = strcat(subsubdir,flagslash,selecfiles{ni});
%     delete(filename)
%     disp(filename)
% end
% GraphColoc3DSingle_1
% tfm = ~cellfun('isempty',strfind(Csusu1,'Xwc')) ...
%     & cellfun('isempty',strfind(Csusu1,'Zc'));
% 
% selecfiles = Csusu1(tfm);
% 
% 
% ns = numel(selecfiles);
% for ni = 1:ns
%     filename = strcat(subsubdir,flagslash,selecfiles{ni});
%     delete(filename)
%     disp(filename)
% end

% tfm = (~cellfun('isempty',strfind(Csusu1,'Xwc')) ...
%     & ~cellfun('isempty',strfind(Csusu1,'Skeleton'))) ...
%     | (~cellfun('isempty',strfind(Csusu1,'Xwc')) ...
%     & ~cellfun('isempty',strfind(Csusu1,'Filtalgn')))...
%     | (~cellfun('isempty',strfind(Csusu1,'Xwc')) ...
%     & ~cellfun('isempty',strfind(Csusu1,'mask')));
% selecfiles = Csusu1(tfm);
% 
% ns = numel(selecfiles);
% for ni = 1:ns
%     filename = strcat(subsubdir,flagslash,selecfiles{ni});
%     delete(filename)
%     disp(filename)
% end

% tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
% Csusu1 = Csusu(tfmat)';
% 
% tfm = ~cellfun('isempty',strfind(Csusu1,'VoronThrOnly')) ...
%     | ~cellfun('isempty',strfind(Csusu1,'ReThrCoralgn')) ...
%     | ~cellfun('isempty',strfind(Csusu1,'NOTaligned')) ...
%     | ~cellfun('isempty',strfind(Csusu1,'Corralign'));
% selecfiles = Csusu1(tfm);
% % 
% ns = numel(selecfiles);
% for ni = 1:ns
%     filename = strcat(subsubdir,flagslash,selecfiles{ni});
%     delete(filename)
%     disp(filename)
% end

% 
% tfmat = ~cellfun('isempty',strfind(Csusu,'CluViSu.txt')) ...
%     | ~cellfun('isempty',strfind(Csusu,'Sig_Zc.txt')) ...
%     | ~cellfun('isempty',strfind(Csusu,'Sig.txt'));
% selecfiles = Csusu(tfmat)';
% % 
% tfm = ~cellfun('isempty',strfind(Csusu1,'Aligned2D_'));
% Csusu2 = Csusu1(tfm)';
% 
% tfm2 = ~cellfun('isempty',strfind(Csusu2,'_Xwc'));
% selecfiles = Csusu2(tfm2)';
% ns = numel(selecfiles);
% for ni = 1:ns
%     filename = strcat(subsubdir,flagslash,selecfiles{ni});
%     delete(filename)
%     disp(filename)
% end

% tfm = ~cellfun('isempty',strfind(Csusu1,'NOTaligned'));
% Csusu2 = Csusu1(tfm)';
% 
% tfm2 = ~cellfun('isempty',strfind(Csusu2,'_Xwc'));
% selecfiles = Csusu2(tfm2)';
% ns = numel(selecfiles);
% for ni = 1:ns
%     filename = strcat(subsubdir,flagslash,selecfiles{ni});
%     delete(filename)
%     disp(filename)
% end
% 
% tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
% Csusu1 = Csusu(tfmat)';
% 
% tfm = ~cellfun('isempty',strfind(Csusu1,'Aligned'));%
% %     ~cellfun('isempty',strfind(Csusu1,'Aligned2D'));
% Csusu2 = Csusu1(tfm);
% % % 
% % tfm2 = ~cellfun('isempty',strfind(Csusu2,'NOTaligned'));
% selecfiles = Csusu2;
% ns = numel(selecfiles);
% for ni = 1:ns
%     filename = strcat(subsubdir,flagslash,selecfiles{ni});
%     delete(filename)
%     disp(filename)
% end
% 
% 
% tfm = ~cellfun('isempty',strfind(Csusu1,'VoronThrOnly'));
% Csusu2 = Csusu1(tfm)';
% 
tfm2 = ~cellfun('isempty',strfind(Csusu,'Aligned_'));
selecfiles = Csusu(tfm2)';
ns = numel(selecfiles);

for ni = 1:ns
    filename = strcat(subsubdir,flagslash,selecfiles{ni});
    delete(filename)
     disp(filename)
end

