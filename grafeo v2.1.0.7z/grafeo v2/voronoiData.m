function [dataout,densitythr,dim,Vpout,Dp,avDp,medDp,minDp,maxDp] = voronoiData(tmp,photonTH,localizationprec,densitythr,flag,fac,dimn)
 % voronoiData is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

Dp = 1./tmp.VOLp;
avDp = mean(Dp);
medDp = median(Dp);
minDp = min(Dp);
maxDp = max(Dp);

if isempty(densitythr) | densitythr == 0
    if flag
        meanD = mean(Dp);
    else
        meanD = median(Dp);
    end
    densitythr = meanD;
    if ~isempty(fac) | fac ~= 0
        densitythr = meanD*fac;
    end
end
datatesselerfilt = tmp.datatesselerfilt;
inddat = [1,2,3,5,6,4,7,8];

if ~isempty(dimn) & dimn ~= 0
    dim = dimn;
else
    if ~sum(datatesselerfilt(:,6))
        dim = 2;
    else
        dim = 3;
    end
end

dataout = datatesselerfilt(:,inddat);
ind = find(Dp >= densitythr);
if sum(ind)
    dataout = dataout(ind,:);
    Vpout = {tmp.Vp{ind}}';
    Dp = Dp(ind);
else    
    Vpout = {tmp.Vp}';
end
if ~isempty(photonTH) & photonTH ~= 0
ind1 = find(dataout(:,3) >= photonTH);
if sum(ind1)
    dataout = dataout(ind1,:);
    Vpout = {Vpout{ind1}}';
    Dp = Dp(ind1);
end
end

if ~isempty(localizationprec) & localizationprec ~= 0
ind2 = find(dataout(:,4) <= localizationprec);
if sum(ind2)
    dataout = dataout(ind2,:);
    Vpout = {Vpout{ind2}}';
    Dp = Dp(ind2);
end
end
end
