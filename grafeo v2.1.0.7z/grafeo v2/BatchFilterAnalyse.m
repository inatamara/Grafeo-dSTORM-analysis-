function BatchFilterAnalyse(Csusu,subsubdir,searchstring,...
    numn11,filtval1,numn22,filtval2,numn12,filtval12,numn21,filtval21,dimn,saveflag)

% BatchFilterAnalyse is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

if ~ismac
    flagslash = '\';
else
    flagslash = '/';
end

tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
Csusu1 = Csusu(tfmat);
tfm = ~cellfun('isempty',strfind(Csusu1,searchstring));
selecfiles = Csusu1(tfm);
ns = numel(selecfiles);

%%
for ni = 1:ns   
str = selecfiles{ni}(end-4);

tmp = load(strcat(subsubdir,flagslash,selecfiles{ni}));
leftrightcount = tmp.leftrightcount;
updowncount = tmp.updowncount;
zcount = tmp.zcount; 

filetosave3d = strrep(strcat(subsubdir,flagslash,selecfiles{ni}),searchstring,saveflag);
% filetosave3d = strcat(subsubdir,flagslash,selecfiles{ni});

if ~exist(filetosave3d,'file')

dataout1 = tmp.dataout1;
dataout2 = tmp.dataout2;
dim = tmp.dim;
densitythr1 = tmp.densitythr1;
densitythr2 = tmp.densitythr2; 
namech2 = tmp.namech2;
namech1 = tmp.namech1; 
Vp2 = tmp.Vp2;
Vp1 = tmp.Vp1;
Dp2 = tmp.Dp2;
Dp1 = tmp.Dp1;
photonTH1 = tmp.photonTH1;
photonTH2 = tmp.photonTH2;
locprec1 = tmp.locprec1;
locprec2 = tmp.locprec2;
dataoutshift1 = dataout1; 
if ~isempty(leftrightcount)
dataoutshift1(:,1) = dataoutshift1(:,1) - leftrightcount;
end
if ~isempty(updowncount)
dataoutshift1(:,2) = dataoutshift1(:,2) - updowncount;
end
if isempty(zcount)
    zcount = 0;
end
dataoutshift1(:,5) = dataoutshift1(:,5) - zcount;
if dimn == 3
    ind = [1,2,5];
elseif dimn == 2
    ind = [1,2];
end
x = dataoutshift1(:,ind);
y = dataout2(:,ind);

dataout1NF = dataout1;
Dp1NF = Dp1;
Vp1NF = Vp1;
dataoutshift1NF = dataoutshift1;
Dp2NF = Dp2;
Vp2NF = Vp2;
dataout2NF = dataout2;

Dav21 = knnsearchThr(x,y,numn21,'median');
Dav12 = knnsearchThr(y,x,numn12,'median');
Dav22 = knnsearchThr(y,y,numn22,'median');
Dav11 = knnsearchThr(x,x,numn11,'median');
dataoutshift1 = dataoutshift1((Dav12 <= filtval12) | (Dav11 <= filtval1),:);
dataout1 = dataout1((Dav12 <= filtval12) | (Dav11 <= filtval1),:);
dataout2 = dataout2((Dav21 <= filtval21) | (Dav22 <= filtval2),:);
Dp1 = Dp1((Dav12 <= filtval12) | (Dav11 <= filtval1));
Dp2 = Dp2((Dav21 <= filtval21) | (Dav22 <= filtval2));
Vp1 = Vp1((Dav12 <= filtval12) | (Dav11 <= filtval1));
Vp2 = Vp2((Dav21 <= filtval21) | (Dav22 <= filtval2));

 disp(strcat('Saveing ...',filetosave3d))
save(filetosave3d,'dataoutshift1','dataout2','dataout1','leftrightcount','updowncount','zcount',...
        'densitythr1','densitythr2','namech2','namech1','Dp2','Dp1',...
        'Vp1','Vp2','filtval21','filtval12','numn12','numn21','numn11','numn22',...
        'dimn','filtval2','filtval1','Dav12','Dav21','Dav11','Dav22',...
        'dataoutshift1NF','dataout2NF','dataout1NF','dim',...
        'Dp1NF','Dp2NF','Vp1NF','Vp2NF','photonTH1','photonTH2','locprec1','locprec2') 
else
      disp('Already exists')
end
disp('Finished ...')
end