function BatchGraph1C(Csusu,subsubdir,flagname,chaneltag,varargin)
% varargin: [minA1,minA2], [fac1,fac2],[noddeg1,noddeg2],dimdeluney 
% chanel tag, pix, flag, minregmask

% BatchGraph1C is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end
minA1 = 3;
minA2 = 3;
fac1 = 30;
fac2 = 30;
noddeg1 = 1;
noddeg2 = 1;
dimdeluney = 2;
chtag = '647';
pix = 10;
flag = 'median';
minregmask = 1000;
if ~iscell(Csusu)
    Csusu1{1} = Csusu;
else
    Csusu1 = Csusu;
end
clear Csusu
if nargin >= 5
    if ~isempty(varargin{1})| varargin{1}(1)~= 0
        minA1 = varargin{1}(1);
    end
    if ~isempty(varargin{1})| varargin{1}(2)~= 0
        minA2 = varargin{1}(2);
    end
end
if nargin >= 6
    if ~isempty(varargin{2})| varargin{2}(1)~= 0
        fac1 = varargin{2}(1);
    end
    if ~isempty(varargin{2})| varargin{2}(2)~= 0
        fac2 = varargin{2}(2);
    end
end

if nargin >= 7
    if ~isempty(varargin{3})| varargin{3}(1)~= 0
        noddeg1 = varargin{3}(1);
    end
    if ~isempty(varargin{3})| varargin{3}(2)~= 0
        noddeg2 = varargin{3}(2);
    end
end

if nargin >= 8
    if ~isempty(varargin{4})| varargin{4}~= 0
        dimdeluney = varargin{4};
    end
end

if nargin >= 9
    if ~isempty(varargin{5})| varargin{5}~= 0
        chtag = varargin{5};
    end
end
if nargin >= 10
    if ~isempty(varargin{6})| varargin{6}~= 0
        pix = varargin{6};
    end
end
if nargin >= 11
    if ~isempty(varargin{7})| varargin{7}~= 0
        flag = varargin{7};
    end
end

if nargin == 12
    if ~isempty(varargin{8})| varargin{8}~= 0
        minregmask = varargin{8};
    end
end
%%
tfmat = ~cellfun('isempty',strfind(Csusu1,'.mat'));
Csusu1 = Csusu1(tfmat);
tfm = ~cellfun('isempty',strfind(Csusu1,flagname));
selecfiles = Csusu1(tfm)';
ns = numel(selecfiles);
%%
tic
for ni = 1:ns   
str = selecfiles{ni}(end-4);
try
tmp = load(strcat(subsubdir,flagslash,'mask_',num2str(str),'.mat'));
catch
    tmp = [];
end
clear dataoutshift1 dataout2 totalMask1 dim

    if ~isempty(tmp)
        try
            totalMask1 = tmp.totalMask1;
        catch
            totalMask1 = tmp.nodes;
            B = totalMask1;
        end
    else
        disp('No mask');
        totalMask1 = [];
    end
        
filetoload = strcat(subsubdir,flagslash,selecfiles{ni});
filetosave3d = strcat(subsubdir,flagslash,'SingleGraph3d_',chtag,'_',num2str(str),'.mat');
filetosave2d = strcat(subsubdir,flagslash,'SingleGraph2d_',chtag,'_',num2str(str),'.mat');

if dimdeluney == 3
    filetosave = filetosave3d;
elseif dimdeluney == 2
    filetosave = filetosave2d;
end
%     
if ~exist(filetosave,'file') 
    
if chaneltag == 1
    tmp3d = load(filetoload,'dataout1','dim','Dp1','Vp1');
    dataout1 = tmp3d.dataout1;
    dim = tmp3d.dim;
    Dp1 = tmp3d.Dp1;
    Vp1 = tmp3d.Vp1;
elseif chaneltag == 2
    tmp3d = load(filetoload,'dataout2','dim','Dp2','Vp2');
    dataout2 = tmp3d.dataout2;
    dim = tmp3d.dim;
    Dp2 = tmp3d.Dp2;
    Vp2 = tmp3d.Vp2;
end

    temp1 = [];
    temp2 = [];
    temp3 = [];
if ~isempty(tmp)
    
if ~iscell(totalMask1)
    if chaneltag == 1
        
        x = dataout1(:,[1,2]);

        [ind1,~,B] = pointsINboundary(x,[],totalMask1,minregmask,pix);
        indB = ~cellfun(@isempty,B);
        B = B(indB);

        if ~isempty(ind1)
            for ii = 1:numel(ind1)
                dataout1 = dataout1(~ind1{ii},:);
                Dp1 = Dp1(~ind1{ii}); 
                Vp1 = Vp1(~ind1{ii});
            end    
        end
        clear ind1
        for kk = 1:numel(B)
            try
                ind1 = InPolygon(dataout1(:,1),dataout1(:,2), B{kk}(:,2),B{kk}(:,1));
            catch
                ind1 = inpolygon(dataout1(:,1),dataout1(:,2), B{kk}(:,2),B{kk}(:,1));
            end
                temp1 = [temp1;dataout1(ind1,:)];
                temp2 = [temp2;Dp1(ind1)]; 
                temp3 = [temp3;Vp1(ind1)];
        end
        dataout1 = temp1;
        Dp1 = temp2;
        Vp1 = temp3;
    elseif chaneltag == 2

             x = dataout2(:,[1,2]);
        [ind2,~,B] = pointsINboundary(x,[],totalMask1,minregmask,pix);
        indB = ~cellfun(@isempty,B);
        B = B(indB);

        if ~isempty(ind2)
            for ii = 1:numel(ind2)
                dataout2 = dataout2(~ind2{ii},:);
                Dp2 = Dp2(~ind2{ii}); 
                Vp2 = Vp2(~ind2{ii});
            end    
        end
        clear ind2

        for kk = 1:numel(B)
            try
                ind2 = InPolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,2),B{kk}(:,1));
            catch
                ind2 = inpolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,2),B{kk}(:,1));
            end
            temp1 = [temp1;dataout2(ind2,:)];
            temp2 = [temp2;Dp2(ind2)]; 
            temp3 = [temp3;Vp2(ind2)];
        end
        dataout2 = temp1;
        Dp2 = temp2;
        Vp2 = temp3;
   end
   
else
    if chaneltag == 1
        for kk = 1:numel(B)
            try
                ind1 = InPolygon(dataout1(:,1),dataout1(:,2), B{kk}(:,1),B{kk}(:,2));
            catch
                ind1 = inpolygon(dataout1(:,1),dataout1(:,2), B{kk}(:,1),B{kk}(:,2));
            end
            temp1 = [temp1;dataout1(ind1,:)];
            temp2 = [temp2;Dp1(ind1)]; 
            temp3 = [temp3;Vp1(ind1)];
        end
        dataout1 = temp1;
        Dp1 = temp2;
        Vp1 = temp3;
    elseif chaneltag == 2
        for kk = 1:numel(B)
            try
                ind2 = InPolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,1),B{kk}(:,2));
            catch
                ind2 = inpolygon(dataout2(:,1),dataout2(:,2), B{kk}(:,1),B{kk}(:,2));
            end
                temp1 = [temp1;dataout2(ind2,:)];
                temp2 = [temp2;Dp2(ind2)]; 
                temp3 = [temp3;Vp2(ind2)];
        end
        dataout2 = temp1;
        Dp2 = temp2;
        Vp2 = temp3;
   end      
end
clear ind1 ind2
if chaneltag == 1
    [Gbin1,dataout1,Vp1,Dp1,VorDpAll1,VorDpSum21,Vol1,Det1,WC1,...
    Cen1,XYZnodes1,DpGsubMed1,AllShortPath1,DGsub1,Gsub1,G1,Pnum1,Len1] ...
    = deluneyFiltClustNEW(dataout1,Vp1,Dp1,dimdeluney,flag,fac1,noddeg1);

    ind1 = find(Det1 < minA1);

    Det1(ind1) = [];
    VorDpSum21(ind1) = [];
    VorDpAll1(ind1) = [];
    DpGsubMed1(ind1) = [];
    Gbin1(ind1) = [];
    WC1(ind1,:) = [];
    Vol1(ind1) = [];
    XYZnodes1(ind1) = [];
    Cen1(ind1,:) = [];
    AllShortPath1(ind1) = [];
    Gsub1(ind1) = [];
    DGsub1(ind1,:) = [];
    Pnum1(ind1,:) = [];
    Len1(ind1,:) = [];
    
    [pcacoeff1,pcascore1,pcalatent1,pcaexplained1,ratio1] = cellfun(@pcaOnGraph,XYZnodes1,'UniformOutput',false);
    ratio1 = cell2mat(ratio1);

    [Ani1,AniMed1,~,MedShortPath1,extension1,extensionIND1] = ...
    cellfun(@graphsizemeasures,XYZnodes1,num2cell(Cen1,2),DGsub1,'UniformOutput',false);

    AniMed1 = cell2mat(AniMed1);

    MedShortPath1 = cell2mat(MedShortPath1);
    extension1 = cell2mat(extension1);
    extensionIND1 = cell2mat(extensionIND1);

elseif chaneltag == 2
    [Gbin2,dataout2,Vp2,Dp2,VorDpAll2,VorDpSum22,Vol2,Det2,WC2,Cen2,...
    XYZnodes2,DpGsubMed2,AllShortPath2,DGsub2,Gsub2,G2,Pnum2,Len2] ...
    = deluneyFiltClustNEW(dataout2,Vp2,Dp2,dimdeluney,flag,fac2,noddeg2);
    ind2 = find(Det2 < minA2);

    Det2(ind2) = [];
    VorDpSum22(ind2) = [];
    VorDpAll2(ind2) = [];
    DpGsubMed2(ind2) = [];
    Gbin2(ind2) = [];
    WC2(ind2,:) = [];
    Vol2(ind2) = [];
    XYZnodes2(ind2) = [];
    Cen2(ind2,:) = [];
    AllShortPath2(ind2,:) = [];
    DGsub2(ind2) = [];
    Gsub2(ind2) = [];
    Pnum2(ind2,:) = [];
    Len2(ind2,:) = [];

    [pcacoeff2,pcascore2,pcalatent2,pcaexplained2,ratio2] = cellfun(@pcaOnGraph,XYZnodes2,'UniformOutput',false);
    ratio2 = cell2mat(ratio2);

    [Ani2,AniMed2,~,MedShortPath2,extension2,extensionIND2] = ...
        cellfun(@graphsizemeasures,XYZnodes2,num2cell(Cen2,2),DGsub2,'UniformOutput',false);

    AniMed2 = cell2mat(AniMed2);
    MedShortPath2 = cell2mat(MedShortPath2);
    extension2 = cell2mat(extension2);
    extensionIND2 = cell2mat(extensionIND2);

end
%%
if chaneltag == 1
    save(filetosave,...
    'Gbin1','VorDpAll1','XYZnodes1',...
    'minA1','dataout1','fac1',...
    'AllShortPath1','DGsub1','Gsub1','G1',...
    'ratio1','pcacoeff1','pcascore1','pcalatent1','pcaexplained1',...
    'Vp1','Dp1','VorDpSum21','Vol1','Det1','WC1','Cen1','DpGsubMed1',...
    'dim','minregmask','flag',...
    'dimdeluney','AniMed1','MedShortPath1','extension1','extensionIND1',...
    'Len1','Pnum1','Ani1','noddeg1','pix','-v7.3') 
       disp(strcat('Saved: ',' ',filetosave)); 
    
elseif chaneltag == 2
    save(filetosave,...
    'Gbin2','VorDpAll2','XYZnodes2',...
    'minA2','dataout2','fac2',...
    'AllShortPath2','DGsub2','Gsub2','G2',...
    'ratio2','pcacoeff2','pcascore2','pcalatent2','pcaexplained2',...
    'Vp2','Dp2','VorDpSum22','Vol2','Det2','WC2','Cen2','DpGsubMed2',...
    'dim','minregmask','flag',...
    'dimdeluney','AniMed2','MedShortPath2','extension2','extensionIND2',...
    'Len2','Pnum2','Ani2','noddeg2','pix','-v7.3') 
    disp(strcat('Saved: ',' ',filetosave)); 
end
else
   disp('Already Analysed');
end
end
end
