function [Gbin,dataout,Vp,Dp,VorDcell,VorD,Vol,Det,WC,Cen,XYZcell,...
    DpGmed,maxDGsub,DGsub,Gsub,G,Pnum,Len] = ...
    deluneyFiltClustNEW(dataout,Vp,Dp,dim,flag,fac,noddeg)
% deluneyFiltClustNEW is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
%%

[~,ia,~] = unique(dataout(:,1:2),'rows');
dataout = dataout(ia,:);
Vp = Vp(ia);
Dp = Dp(ia);

x  =dataout(:,1);
y = dataout(:,2);

% Delaunay triangulation
if dim == 3
    z = dataout(:,5);
    DT      = delaunayTriangulation(x,y,z);
elseif dim == 2
    DT      = delaunayTriangulation(x,y);
end
points = DT.Points;
edges = DT.edges;
% global edge length

if dim == 2
    Ledge =   sqrt((points(edges(:,1),1) - points(edges(:,2),1)).^2 + ...
               (points(edges(:,1),2) - points(edges(:,2),2)).^2);
          
elseif dim == 3
%     Ledge =   sqrt((points(edges(:,1),1) - points(edges(:,2),1)).^2 + ...
%                    (points(edges(:,1),2) - points(edges(:,2),2)).^2 + ...
%                    0.5*(points(edges(:,1),3) - points(edges(:,2),3)).^2);
 Ledge =   sqrt((points(edges(:,1),1) - points(edges(:,2),1)).^2 + ...
                   (points(edges(:,1),2) - points(edges(:,2),2)).^2 + ...
                   (points(edges(:,1),3) - points(edges(:,2),3)).^2);
end

%%
% Group = findgroups(edges(:,1));
% Lloc = splitapply(@mean,Ledge,Group);
Cutoff = Ledge <= fac;
% Fp = mean(Ledge)*(1 + std(Ledge)./Lloc);
%%
edge_out = edges;
edge_out(Cutoff ==0,:) = [];
Gweight = Ledge;
Gweight(Cutoff ==0,:) = [];
Ledge(Cutoff ==0,:) = [];
%%
s = edge_out(:,1);
t = edge_out(:,2);
G = graph(s,t,Gweight);
Deg = degree(G);
G = rmnode(G,find(Deg<=noddeg));
dataout= dataout(Deg>noddeg,:);
Vp = Vp(Deg>noddeg);
Dp = Dp(Deg>noddeg);

clear edge_out s t eges Gweight DT 
% edge = table2array(G.Edges);

% Fp = Fp(Deg>noddeg);
% Lloc = Lloc(Deg>noddeg);

Gbin = conncomp(G,'OutputForm','cell')';
tmp41 = repmat({G},[numel(Gbin),1]);
Gsub = cellfun(@subgraph,tmp41,Gbin,'UniformOutput',false);
[maxDGsub,DGsub] = cellfun(@shortestpathSubG,Gsub,'UniformOutput',false);
clear tmp41

%%
if dim == 2
    ind = [1,2];
elseif dim == 3
    ind = [1,2,5];
end
% voronoi density of each cluster

Phot1 = repmat({dataout(:,3)},[numel(Gbin),1]);
Len1 = repmat({dataout(:,7)},[numel(Gbin),1]);
Dpc1 = repmat({Dp},[numel(Gbin),1]);

flag1 = repmat({flag},[numel(Gbin),1]);
[VorDcell,VorD,Vol,DpGmed,Pnum,Len] = cellfun(@clustDenVorNEW,Gbin,Dpc1,Phot1,Len1,flag1,'UniformOutput',false);

Len = cell2mat(Len);
Pnum = cell2mat(Pnum);
VorD = cell2mat(VorD);
Vol = cell2mat(Vol);
DpGmed = cell2mat(DpGmed);

XYZ = repmat({dataout(:,ind)},[numel(Gbin),1]);
[WC,Cen,XYZcell] = cellfun(@clustCentroid,Gbin,XYZ,Dpc1,'UniformOutput',false);
Cen = cell2mat(Cen);
WC = cell2mat(WC);

% [nr,nc] = size(Cen);
% Cen1 = mat2cell(Cen,ones(nr,1),nc);
% P2C = cellfun(@points2cetroid,Cen1,XYZcell,'UniformOutput',false);
%%
Det = cellfun(@numel, Gbin);
% binrangeDet = 0:5:max(Det);

end

