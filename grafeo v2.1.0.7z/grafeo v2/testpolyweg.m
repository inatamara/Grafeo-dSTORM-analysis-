
close all
xy1 = [seg(1,1),seg(1,2)];
xy2 = [seg(2,1),seg(2,2)];
N = 1;
[xy3,xy4] = perCaps(xy1,xy2,N);

figure;
plot(seg(:,1),seg(:,2),'.-b')
hold on;
plot(xy3(:,1),xy3(:,2),'.-r')
plot(xy4(:,1),xy4(:,2),'.-r')