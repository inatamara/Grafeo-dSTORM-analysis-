function [inroicount1,inroicount2,inroicount3,...
    inroicountNORM1,inroicountNORM2,inroicountNORM3] = getpolyroicound(folder,folder1,coralignfile,bwfile,photthr)

if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

load(strcat(folder,flagslash,coralignfile),'dataoutshift1','dataout2','dataoutshift3')
load(strcat(folder1,flagslash,bwfile),'nodes')
try
   dat1 = dataoutshift1(dataoutshift1(:,3) > photthr(1),:);
catch
     load(strcat(folder,flagslash,filename),'dataout1')
     dat1 = dataout1(dataout1(:,3) > photthr(1),:);
end
try
dat3 = dataoutshift3(dataoutshift3(:,3) > photthr(3),:);
catch
    load(strcat(folder,flagslash,filename),'dataout3')
    dat3 = dataout3(dataout3(:,3) > photthr(3),:);

end

 dat2 = dataout2(dataout2(:,3) > photthr(2),:);
 in1= inpolygon(dat1(:,1),dat1(:,2),nodes{1}(:,1),nodes{1}(:,2));
 in2= inpolygon(dat2(:,1),dat2(:,2),nodes{1}(:,1),nodes{1}(:,2));
 in3= inpolygon(dat3(:,1),dat3(:,2),nodes{1}(:,1),nodes{1}(:,2));
 inroicount1 = sum(in1);
 inroicount2 = sum(in2);
 inroicount3 = sum(in3);
 areanodes = polyarea(nodes{1}(:,1)/1000,nodes{1}(:,2)/1000);
 inroicountNORM1 = sum(in1)/areanodes;
 inroicountNORM2 = sum(in2)/areanodes;
 inroicountNORM3 = sum(in3)/areanodes;

