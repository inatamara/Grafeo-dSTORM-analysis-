% this is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
    choice = menu('chose variable to plot','Ksim12','Ksim21','Lsim12','Lsim21','Ksim1',...
    'Ksim2','Lsim1','Lsim2','KdMs','LdMs');

 prompt = {...
    'Enterx label:',...
    'Enter y ticks',...
    'Enter x ticks)'};
    dlg_title = 'Input';
    num_lines = 1;
    def = {'Distance (nm)','[0,5,10]','[0,500,1000]'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    xlab = str2num(answer{1});
    ytick = str2num(answer{2});
    xtick = str2num(answer{3}); 
    switch choice
        case 1
             ylab = 'K_{1-2}';
             var = Ksim12;
             obs = K12;
        case 2
             ylab = 'K_{2-1}';
             var = Ksim21;
             obs = K21;
        case 3
             ylab = 'L_{1-2}';
             var = Lsim12;
             obs = L12;
        case 4
             ylab = 'L_{2-1}';
             var = Lsim21;
             obs = L21;
        case 5
             ylab = 'K_{1}';
             var = Ksim1;
             obs = Khat1;
        case 6
             ylab = 'K_{2}';
             var = Ksim2;
             obs = Khat2;
        case 7
             ylab = 'L_{1}';
             var = Lsim1;
             obs = Lhat1;
        case 8
             ylab = 'L_{2}';
             var = Lsim2;
             obs = Lhat2;
        case 9
             ylab = 'K_{1-2,2-1}';
             var = KdMs;
             obs = KdM;
        case 10
             ylab = 'L_{1-2,2-1}';
             var = LdMs;
             obs  = LdM;
    end
width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 1;    % AxesLineWidth
fsz = 10;      % Fontsize
lw = 1.5;      % LineWidth
msz = 8;       % MarkerSize
fszl = 8; % Fontsize legend 
fontname = 'Helvetica';
colfill = [66,103,176]/255;
mc = [106,37,58]/255;
 violet = [160,121,167]/255;
for i = 1:numel(ytick)
yticklab{i} = num2str(ytick(i));
end
for i = 1:numel(xtick)
xticklab{i} = num2str(xtick(i));
end
legendlab = {'Observed', 'rnd: 95% CI','rnd: mean'};
% legendlab = {'Observed', 'Randomized: 95 % CF','Randomized: avereage'};
%%
avvar = squeeze(mean(var,2));
UCIvar =  squeeze(prctile(var,95,2));% max(K');
LCIvar =  squeeze(prctile(var,5,2));%min(K');
for numcell = 1:size(obs,2)
f1 = figure;
hold on;
plt = plot(D*unitfactor,obs(:,numcell),'-k','Color',violet);
fillplot(D*unitfactor,avvar(:,numcell),UCIvar(:,numcell),LCIvar(:,numcell),0.5,0.5,colfill, colfill,colfill)


plt.LineWidth = lw;
xl = xlabel(gca, xlab);
set(xl,'Fontname',fontname, 'Fontsize', fsz)    
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');
set(gca,'XTick',xtick) 
set(gca,'YTick',ytick)  
yl = ylabel(gca, ylab);
set(yl,'Fontname',fontname, 'Fontsize', fsz)  
set(gca,'XTickLabel',xticklab)
set(gca,'YTickLabel',yticklab)
xlim(gca,[min(xtick),max(xtick)])
ylim(gca,[min(ytick),max(ytick)]);
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
l = legend(legendlab,'Location','northeast'); % southeast northwest
legend on 
set(l, 'Interpreter', 'none','FontSize', fszl,'color','w');
set(l,'Fontname',fontname) 
tl = title(sprintf('Cell number %d: ',numcell));
set(tl,'Fontname',fontname, 'Fontsize', fsz)  
set(gca,'box','off');
pos = get(f1, 'Position');
set(f1, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(f1,'color','w')
set(f1,'InvertHardcopy','on');
set(f1,'PaperUnits', 'inches');
end