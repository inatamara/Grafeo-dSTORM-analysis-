function [r1out,vecx,vecy,vecz,fval,exitflag,output,dim] = simulanielminim(r1,r2,dim)
 % simulanielminim is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018


global tol_value
global TolX
global MaxFunEvals
global MaxIter
% global StepTol
global optix0
options = optimset('TolFun',tol_value,'TolX',TolX,...
          'MaxFunEvals',MaxFunEvals,'MaxIter',MaxIter,'Display',...
          'iter-detailed',...
          'PlotFcns',@optimplotfirstorderopt); %,'StepTolerance',StepTol
%       ,...
%           'SpecifyObjectiveGradient',true,'CheckGradients',true
if dim == 3
    coeff0 = [randi([-optix0(1),optix0(1)],1),randi([-optix0(2),optix0(2)],1),randi([-optix0(3),optix0(3)],1)];
%     coeff0 = [0 0 0];
    [coeff,fval,exitflag,output] = ...
         fminunc(@(x)mindist(x,r1,r2,dim),coeff0,options);
    vecx = coeff(1);
    vecy = coeff(2);
    vecz = coeff(3);
    r1out(:,1)  = r1(:,1) + vecx;
    r1out(:,2)  = r1(:,2) + vecy;
    r1out(:,3)  = r1(:,3) + vecz;
elseif dim == 2
   coeff0 = [randi([-optix0(1),optix0(1)],1),randi([-optix0(2),optix0(2)],1)];
    [coeff,fval,exitflag,output] = ...
         fminunc(@(x)mindist(x,r1,r2,dim),coeff0,options);
    vecx = coeff(1);
    vecy = coeff(2);
    r1out(:,1)  = r1(:,1) + vecx;
    r1out(:,2)  = r1(:,2) + vecy;
    vecz = [];
end
  function res = mindist(x,r1,r2,dim)
    if dim == 3
        D1 = pdist2([r1(:,1) - x(1),r1(:,2) - x(2),r1(:,3) - x(3)],r2,'euclidean'); % euclidean distance
%         G1 = [r1(:,1) - x(1) - r2(:,1);r1(:,2) - x(2) - r2(:,2);r1(:,3) - x(3) - r2(:,3)]
    elseif dim == 2
        D1 = pdist2([r1(:,1) - x(1),r1(:,2) - x(2)],r2,'euclidean'); % euclidean distance
    end
    if size(r1,2) <= size(r2,2)
        [v2,~] = min(D1,[],2);
        res = norm(v2);
    elseif size(r1,2) > size(r2,2)
        [v1,~] = min(D1,[],1);
        res = norm(v1);
    end
  end
end
