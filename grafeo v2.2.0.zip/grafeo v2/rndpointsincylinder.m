function pts = rndpointsincylinder(p1,p2,R,N)
% p1=[0.5, 0.3, 1];
% p2=[0.4, 0.5, 0.7];
% R=0.5;
% N = 100000; % # of points to generate
% First, generate a random point along the cylinder axis. The vector that defines the axis is given by:
axialvec = p2 - p1;
axialvec = axialvec/norm(axialvec);
axialpoints = p1 + (p2 - p1).*rand(N,1);
% Next, we work in a cylindrical coordinate system around the centerline. Generate points at random inside a circle of radius R, in TWO dimensions.
circr = sqrt(rand(N,1))*R;
circtheta = rand(N,1)*2*pi;
circpoints = [cos(circtheta).*circr,sin(circtheta).*circr];
% Rotate the points into the plane perpendicular to the axis.
axnull = null(axialvec);
points = axialpoints + circpoints*axnull.';
% And plot.
figure
plot3(points(:,1),points(:,2),points(:,3),'.')
grid on
box on