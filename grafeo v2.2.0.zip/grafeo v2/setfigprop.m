% box off;exportsetupdlg(gcf)
view([-6,12]);
%%
box off
h = findobj(gca,'Type','line'); %// objects of legend of type line
set(h, 'MarkerSize',3);
set(gcf, 'Renderer', 'painters');
box off
%%
set(gca,'visible','off')
%%
zlim([-500,500])
%%
set(gcf, 'Renderer', 'painters');
% xlim([0,20])
%%
fig = figure;
ms = 3;

ax = axes;
set(ax,'NextPlot','add');
chigh = [44, 128, 111]/255;
clow = [125, 201, 186]/255;
cmap = colormapCust( clow,chigh,256);

plot3dZmap(dat1,cmap,ax,'.',ms(1))
%         plot3(dat2(:,1),dat2(:,2),dat2(:,3),'.','MarkerSize',ms(2),'Color',green)
%         plot3(dat3(:,1),dat3(:,2),dat3(:,3),'.','MarkerSize',ms(3),'Color',yellow)

alw = 1;    % AxesLineWidth
% set(ax,'xlim',[pos(1),pos(1)+pos(3)])
% set(ax,'ylim',[pos(2),pos(2)+pos(4)])
fontname='Helvetica'; % Fontsize name
tickdir = 'out';
fsz = 8;
ticksize= [0.02 0.035]; % Fontsize legend
zl = zlabel(gca,'(nm)', 'Interpreter', 'none');
set(zl,'Fontname',fontname, 'Fontsize', fsz) 
xl = xlabel(gca,'(nm)', 'Interpreter', 'none');
set(xl,'Fontname',fontname, 'Fontsize', fsz) 
yl = ylabel(gca,'(nm)', 'Interpreter', 'none');
set(yl,'Fontname',fontname, 'Fontsize', fsz) 
% set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax, 'FontSize', fsz, 'LineWidth', alw);
box off;
axis equal
pos1 = get(fig, 'Position');
fwd = 500; fhg = 500;
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');
axis equal
%%
plot3(dat1(:,1),dat1(:,2),dat1(:,3),'.','MarkerSize',3,'Color','m')