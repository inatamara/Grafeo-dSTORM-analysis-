function [Ksim12,Ksim21,K12,K21,Lsim12,Lsim21,L12,L21,Ksim1,Ksim2,Lsim1,Lsim2,K1,K2,L1,...
L2,KdMs12,LdMs12,KdM12,LdM12,C1r,C2r,inPoint1,inPoint2,inPoint1r,inPoint2r,...
PCF1,PCF2,PCF12,PCF21,PCFsim1,PCFsim2,PCFsim12,PCFsim21,...
Ksim13,Ksim31,K13,K31,Lsim13,Lsim31,L13,L31,Ksim3,Lsim3,K3,L3,...
KdMs13,LdMs13,KdM13,LdM13,inPoint3,inPoint3r,PCF3,PCF13,PCF31,PCFsim3,PCFsim13,PCFsim31,...
Ksim23,Ksim32,K23,K32,Lsim23,Lsim32,L23,L32,...
 KdMs23,LdMs23,KdM23,LdM23,PCF23,PCF32,PCFsim23,PCFsim32,C3r] = ...
randomizationRiplays3col3D(C1,C2,C3,Nsimul,D,B,ifplot,dim,boundarycorrection,varargin)
 % randomizationRiplays2col3D is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
p = 0;
tic
minregmask = 1000;
zb = -400;
ze = 400;
mult = 5;
unitfactor = 10^-3;

if nargin >=10
    if ~isempty(varargin{1}) | varargin{1} > 0
        minregmask = varargin{1};
    end
end
% only for 3D ripley, zb:ze - z range
if nargin >= 11
    if ~isempty(varargin{2}) | varargin{1}(1) > 0
        zb = varargin{2}(1);
        zb = zb(1);
    end
    if ~isempty(varargin{2}) | varargin{2}(2) > 0
        ze = varargin{2}(2);

    end
end

if nargin >=12
    if ~isempty(varargin{3}) | varargin{3} > 0
        mult = varargin{3};
    end
end

if nargin >=13
    if ~isempty(varargin{4}) | varargin{4} > 0
        unitfactor = varargin{4};
    end
end
%%
if isempty(C2) &  isempty(C3)
    colflag = 1; % valid for 2 color
elseif isempty(C3)
    colflag = 2;
else
     colflag = 3;
end

if boundarycorrection
    bcor = 1;
else
    bcor = [];
end
% Loop through object boundaries

numo = numel(B);
nD = length(D);
C1r = cell(numo,1);
C2r = cell(numo,1);
Ksim1 = zeros(nD,Nsimul,numo);
Ksim12 = zeros(nD,Nsimul,numo);
Lsim1 = zeros(nD,Nsimul,numo);
Lsim12 = zeros(nD,Nsimul,numo);
Ksim21 = zeros(nD,Nsimul,numo);
Lsim21 = zeros(nD,Nsimul,numo);
inPoint1r = zeros(Nsimul,numo);
inPoint2r = zeros(Nsimul,numo);
KdMs12 = zeros(nD,Nsimul,numo);
LdMs12 = ones(nD,Nsimul,numo);
Ksim2 = zeros(nD,Nsimul,numo);
Lsim2 = zeros(nD,Nsimul,numo);
K2 = zeros(nD,numo);
L2 = zeros(nD,numo);
K1 = zeros(nD,numo);
L1 = zeros(nD,numo);
K12 = zeros(nD,numo);
L12 = zeros(nD,numo);
K21 = zeros(nD,numo);
L21 = zeros(nD,numo);
KdM12 = zeros(nD,numo);
LdM12 = zeros(nD,numo);
% lam11 = zeros(numo,1);
% lam21 = zeros(numo,1);
% lam12 = zeros(numo,1);
% lam22 = zeros(numo,1);
inPoint2 = zeros(numo,1);
inPoint1 = zeros(numo,1);
PCFsim1 = zeros(nD-1,Nsimul,numo);
PCFsim12 = zeros(nD-1,Nsimul,numo);
PCFsim21 = zeros(nD-1,Nsimul,numo);
PCFsim2 = zeros(nD-1,Nsimul,numo);
PCF2 = zeros(nD-1,numo);
PCF1 = zeros(nD-1,numo);
PCF12 = zeros(nD-1,numo);
PCF21 = zeros(nD-1,numo);

C3r = cell(numo,1);
K3 = zeros(nD,numo);
L3 = zeros(nD,numo);
% vol = zeros(numo,1);
inPoint3 = zeros(numo,1);
PCF3 = zeros(nD-1,numo);
inPoint3r = zeros(Nsimul,numo);
Lsim3 = zeros(nD,Nsimul,numo);
Ksim3 = zeros(nD,Nsimul,numo);
Ksim13 = zeros(nD,Nsimul,numo);
Lsim13 = zeros(nD,Nsimul,numo);
Ksim31 = zeros(nD,Nsimul,numo);
Lsim31 = zeros(nD,Nsimul,numo);
KdMs13 = zeros(nD,Nsimul,numo);
LdMs13 = ones(nD,Nsimul,numo);
K13 = zeros(nD,numo);
L13 = zeros(nD,numo);
K31 = zeros(nD,numo);
L31 = zeros(nD,numo);
KdM13 = zeros(nD,numo);
LdM13 = zeros(nD,numo);
% lam33 = zeros(numo,1);
% lam31 = zeros(numo,1);
% lam13 = zeros(numo,1);
PCFsim13 = zeros(nD-1,Nsimul,numo);
PCFsim31 = zeros(nD-1,Nsimul,numo);
PCF13 = zeros(nD-1,numo);
PCF31 = zeros(nD-1,numo);


Ksim23 = zeros(nD,Nsimul,numo);
Lsim23 = zeros(nD,Nsimul,numo);
Ksim32 = zeros(nD,Nsimul,numo);
Lsim32 = zeros(nD,Nsimul,numo);
KdMs23 = zeros(nD,Nsimul,numo);
LdMs23 = ones(nD,Nsimul,numo);
K23 = zeros(nD,numo);
L23 = zeros(nD,numo);
K32 = zeros(nD,numo);
L32 = zeros(nD,numo);
KdM23 = zeros(nD,numo);
LdM23 = zeros(nD,numo);
% lam33 = zeros(numo,1);
% lam32 = zeros(numo,1);
% lam23 = zeros(numo,1);
PCFsim3 = zeros(nD-1,Nsimul,numo);
PCFsim23 = zeros(nD-1,Nsimul,numo);
PCFsim32 = zeros(nD-1,Nsimul,numo);
PCF23 = zeros(nD-1,numo);
PCF32 = zeros(nD-1,numo);
%%
for kk = 1:numo

n1 = size(C1,1);
inPoint1(kk) = n1;
if colflag > 2
    n3 = size(C3,1);
    inPoint3(kk) = n3;
end
if colflag > 1
    n2 = size(C2,1);
    inPoint2(kk) = n2;
end
R1 = B{kk};
xb = min(R1(:,1));
xe = max(R1(:,1));
yb = min(R1(:,2));
ye = max(R1(:,2));

%% spatial statistics
k2 = convhull(R1(:,1),R1(:,2),'Simplify',true);%,'Simplify',true
boundary =  [R1(k2,1),R1(k2,2),zb*ones(numel(R1(k2,2)),1);...
R1(k2,1),R1(k2,2),ze*ones(numel(R1(k2,2)),1)];
% [k2,av2] = convhull(boundary(:,1),boundary(:,2),boundary(:,3));%,'Simplify',true
% boundary = boundary(k2);
DT = delaunayTriangulation(boundary);
C = convexHull(DT);
TR = triangulation(C,DT.Points);
points = TR.Points;
arg.points = points;
arg.zmax = ze;
arg.zmin = zb;
if colflag == 3
    sprintf('Ripley0 2-2, boundary %d out of %d',kk, numo)
    [K1(:,kk),L1(:,kk),K2(:,kk),L2(:,kk),K3(:,kk),L3(:,kk),K12(:,kk),L12(:,kk),...
    K21(:,kk),L21(:,kk),K13(:,kk),L13(:,kk),K31(:,kk),L31(:,kk),K23(:,kk),L23(:,kk),K32(:,kk),L32(:,kk),...
    PCF1(:,kk),PCF2(:,kk),PCF3(:,kk),PCF12(:,kk),PCF21(:,kk),PCF13(:,kk),PCF31(:,kk),PCF23(:,kk),PCF32(:,kk),...
    lam1(:,kk),lam2(:,kk),lam3(:,kk),vol(:,kk)] = ripleysK3colNEW(C1,C2,C3,R1,D,dim,ifplot,bcor,unitfactor,arg);

    KdM12(:,kk) = (K12(:,kk)*inPoint2(kk) + K21(:,kk)*inPoint1(kk))/(inPoint1(kk) + inPoint2(kk));
    KdM13(:,kk) = (K13(:,kk)*inPoint3(kk) + K31(:,kk)*inPoint1(kk))/(inPoint1(kk) + inPoint3(kk));
    KdM23(:,kk) = (K32(:,kk)*inPoint2(kk) + K23(:,kk)*inPoint3(kk))/(inPoint3(kk) + inPoint2(kk));
    if dim == 3
        LdM12(:,kk) = nthroot(3*KdM12(:,kk)/pi/4,3) - D(:)*unitfactor;
        LdM13(:,kk) = nthroot(3*KdM13(:,kk)/pi/4,3) - D(:)*unitfactor;
        LdM23(:,kk) = nthroot(3*KdM23(:,kk)/pi/4,3) - D(:)*unitfactor;
    elseif dim == 2
        LdM12(:,kk) = sqrt(KdM12(:,kk)/pi) - D(:)*unitfactor;
        LdM13(:,kk) = sqrt(KdM13(:,kk)/pi) - D(:)*unitfactor;
        LdM23(:,kk) = sqrt(KdM23(:,kk)/pi) - D(:)*unitfactor;
    end
    sprintf('Ripley Experimental, boundary %d out of %d',kk, numo)
end
save('RipleyTMP')
%% variable initiation for randomization
rng('shuffle')

for i = 1:Nsimul
    sprintf('Simulation %d',i)
    clear RP1x RP1y RP1z
    RP1x = (xe-xb).*rand(mult*n1,1) + xb;
    RP1y = (ye-yb).*rand(mult*n1,1) + yb;
    if dim == 3
    RP1z = (ze-zb).*rand(mult*n1,1) + zb;
    end
%     try
%          ind = InPolygon(RP1x,RP1y, R1(:,2),R1(:,2));
%     catch
%          ind = inpolygon(RP1x,RP1y, R1(:,1),R1(:,2));
%     end
%         
%     RP1x = RP1x(ind)';
%     RP1y = RP1y(ind)';
%     if dim == 3
%     RP1z = RP1z(ind)';   
%     end
    if numel(RP1x) > n1
        RP1x = RP1x(1:n1);
        RP1y = RP1y(1:n1);
        if dim == 3
        RP1z = RP1z(1:n1);
        end
    end
    C1r{i,kk}(:,2) = RP1y;
    C1r{i,kk}(:,1) = RP1x;
    if dim == 3
    C1r{i,kk}(:,3) = RP1z;
    end
    inPoint1r(i,kk) = size(C1r{i,kk}(:,2),1);
  
     
    
    if colflag == 3
        
        RP3x = (xe-xb).*rand(mult*n3,1) + xb;
        RP3y = (ye-yb).*rand(mult*n3,1) + yb;
        if dim == 3
        RP3z = (ze-zb).*rand(mult*n3,1) + zb;
        end
        
%         try
%              ind = InPolygon(RP3x,RP3y, R1(:,1),R1(:,2));
%         catch
%              ind = inpolygon(RP3x,RP3y, R1(:,1),R1(:,2));
%         end
% 
%         RP3x = RP3x(ind)';
%         RP3y = RP3y(ind)';
%         if dim == 3
%         RP3z = RP3z(ind)';   
%         end
        if numel(RP3x) > n3
        RP3x = RP3x(1:n3);
        RP3y = RP3y(1:n3);
        if dim == 3
        RP3z = RP3z(1:n3);
        end
        end
        C3r{i,kk}(:,2) = RP3y;
        C3r{i,kk}(:,1) = RP3x;
        if dim == 3
        C3r{i,kk}(:,3) = RP3z;
        end
        inPoint3r(i,kk) = size(C3r{i,kk}(:,2),1);

        RP2x = (xe-xb).*rand(mult*n2,1) + xb;
        RP2y = (ye-yb).*rand(mult*n2,1) + yb;
        if dim == 3
        RP2z = (ze-zb).*rand(mult*n2,1) + zb;
        end

%         try
%             ind = InPolygon(RP2x,RP2y, R1(:,1),R1(:,2));
%         catch
%              ind = inpolygon(RP2x,RP2y, R1(:,1),R1(:,2));
%         end
% 
%         RP2x = RP2x(ind)';
%         RP2y = RP2y(ind)';
%         if dim == 3
%         RP2z = RP2z(ind)';  
%         end
        if numel(RP2x) > n2
            RP2x = RP2x(1:n2);
            RP2y = RP2y(1:n2);
            if dim == 3
            RP2z = RP2z(1:n2);
            end
        end
        C2r{i,kk}(:,2) = RP2y;
        C2r{i,kk}(:,1) = RP2x;
        if dim == 3
        C2r{i,kk}(:,3) = RP2z;
        end
        inPoint2r(i,kk) = size(C2r{i,kk}(:,2),1);
       
        
    [Ksim1(:,i,kk),Lsim1(:,i,kk),Ksim2(:,i,kk),Lsim2(:,i,kk),Ksim3(:,i,kk),...
     Lsim3(:,i,kk),Ksim12(:,i,kk),Lsim12(:,i,kk),Ksim21(:,i,kk),Lsim21(:,i,kk),...
     Ksim13(:,i,kk),Lsim13(:,i,kk),Ksim31(:,i,kk),Lsim31(:,i,kk),Ksim23(:,i,kk),...
     Lsim23(:,i,kk),Ksim32(:,i,kk),Lsim32(:,i,kk),PCFsim1(:,i,kk),PCFsim2(:,i,kk),...
     PCFsim3(:,i,kk),PCFsim12(:,i,kk),PCFsim21(:,i,kk),PCFsim13(:,i,kk),PCFsim31(:,i,kk),PCFsim23(:,i,kk),PCFsim32(:,i,kk),...
     ] = ripleysK3colNEW( C1r{i,kk}, C2r{i,kk}, C3r{i,kk},R1,D,dim,ifplot,bcor,unitfactor,arg);
%                                                                                                    (C1,C2,C3,R1,D,dim,ifplot,bcor,unitfactor,arg);
    KdMs12(:,i,kk) = (Ksim12(:,i,kk)*inPoint2r(i,kk) + Ksim21(:,i,kk)*inPoint1r(i,kk))/(inPoint1r(i,kk) + inPoint2r(i,kk));
    KdMs13(:,i,kk) = (Ksim13(:,i,kk)*inPoint3r(i,kk) + Ksim31(:,i,kk)*inPoint1r(i,kk))/(inPoint1r(i,kk) + inPoint3r(i,kk));
    KdMs23(:,i,kk) = (Ksim32(:,i,kk)*inPoint2r(i,kk) + Ksim23(:,i,kk)*inPoint3r(i,kk))/(inPoint3r(i,kk) + inPoint2r(i,kk));
    if dim == 3
        LdMs12(:,i,kk) = nthroot(3*KdMs12(:,i,kk)/pi/4,3) - D(:)*unitfactor;
        LdMs13(:,i,kk) = nthroot(3*KdMs13(:,i,kk)/pi/4,3) - D(:)*unitfactor;
        LdMs23(:,i,kk) = nthroot(3*KdMs23(:,i,kk)/pi/4,3) - D(:)*unitfactor;
    elseif dim == 2
        LdMs12(:,i,kk) = sqrt(KdMs12(:,i,kk)/pi) - D(:)*unitfactor;
        LdMs13(:,i,kk) = sqrt(KdMs13(:,i,kk)/pi) - D(:)*unitfactor;
        LdMs23(:,i,kk) = sqrt(KdMs23(:,i,kk)/pi) - D(:)*unitfactor;
    end
               
        sprintf('Simul %d finished, boundary %d out of %d',i, kk, numo)
        
                clear RP1x RP1y RP1z RP2x RP2y RP2z RP3x RP3y RP3z
    end 
    save('RipleyTMP')
end
end
toc
end
