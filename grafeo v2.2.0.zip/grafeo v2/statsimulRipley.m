function [var, obs,ylab,avvar,UCIvar,LCIvar] = statsimulRipley(choice,out,dtrend,npoly)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
 switch choice
        case 1
             ylab = 'L_{1}';
             var = out.Lsim1;
             obs = out.Lhat1;
        case 2
             ylab = 'L_{2}';
             var = out.Lsim2;
             obs = out.Lhat2;
        case 3
             ylab = 'L_{3}';
             var = out.Lsim3;
             obs = out.Lhat3;
        case 4
             ylab = 'L_{1-2,2-1}';
             var = out.LdMs;
             obs  = out.LdM;
        case 5
             ylab = 'L_{1-3,3-1}';
             var = out.LdMs13;
             obs = out.LdM13;
        case 6
             ylab = 'L_{2-3,3-2}';
             var = out.LdMs23;
             obs = out.LdM23;
        case 7
             ylab = 'L_{1-2}';
             var = out.Lsim12;
             obs = out.L12;
        case 8
             ylab = 'L_{2-1}';
             var = out.Lsim21;
             obs = out.L21;
        case 9
             ylab = 'L_{1-3}';
             var = out.Lsim13;
             obs = out.L13;
        case 10
             ylab = 'L_{3-1}';
             var = out.Lsim31;
             obs = out.L31;
       case 11
             ylab = 'L_{2-3}';
             var = out.Lsim23;
             obs = out.L23;
        case 12
             ylab = 'L_{3-2}';
             var = out.Lsim32;
             obs = out.L32;
        case 13
             ylab = 'PCF_{1}';
             var = out.PCFsim1;
             obs = out.PCF1;
        case 14
             ylab = 'PCF_{2}';
             var = out.PCFsim2;
             obs = out.PCF2;
        case 15
             ylab = 'PCF_{3}';
             var = out.PCFsim3;
             obs = out.PCF3;
        case 16
             ylab = 'PCF_{1-2}';
             var = out.PCFsim12;
             obs = out.PCF12;
        case 17
             ylab = 'PCF_{1-3}';
             var = out.PCFsim13;
             obs = out.PCF13;
       case 18
             ylab = 'PCF_{2-3}';
             var = out.PCFsim23;
             obs = out.PCF23;
        case 19
             ylab = 'PCF_{2-1}';
             var = out.PCFsim21;
             obs = out.PCF21;
        case 20
             ylab = 'PCF_{3-1}';
             var = out.PCFsim31;
             obs = out.PCF31;
        case 21
             ylab = 'PCF_{3-2}';
             var = out.PCFsim32;
             obs = out.PCF32;      
 end
    
if ismember(choice,1:12)
    avvar = squeeze(mean(var,2));
    UCIvar =  squeeze(prctile(var,95,2));% max(K');
    LCIvar =  squeeze(prctile(var,5,2));%min(K');
    if dtrend
        y = detrend(avvar(:,1),npoly);
        trend = avvar(:,1) - y;
        UCIvarDtrend = UCIvar-trend;
        LCIvarDtrend = LCIvar-trend;
        obsDtrend(:,1) = obs(:,1) - trend;
        avvarDtrend(:,1) = avvar(:,1) - trend;
        
        obs = obsDtrend;
        avvar = avvarDtrend;
        UCIvar = UCIvarDtrend;
        LCIvar = LCIvarDtrend;
    end
    else
if dtrend
    avvar = squeeze(mean(var,2));
    UCIvar =  squeeze(prctile(var,95,2));% max(K');
    LCIvar =  squeeze(prctile(var,5,2));%min(K');

    UCIvar = UCIvar./avvar;
    LCIvar = LCIvar./avvar;
    obs(:,1) = obs(:,1)./ avvar;
    avvar(:,1) = avvar(:,1)./avvar;
else
    avvar = squeeze(mean(var,2));
    UCIvar =  squeeze(prctile(var,95,2));% max(K');
    LCIvar =  squeeze(prctile(var,5,2));%min(K');
end
    end
end
