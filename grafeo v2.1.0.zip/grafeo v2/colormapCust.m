function map = colormapCust( c_low,c_high,fn )
%UNTITLED12 Summary of this function goes here
%   Detailed explanation goes here

% T = [c_low;c_high]./fn;
% 
% map = interp1(x/fn,T,linspace(0,1,fn));
if any(c_high > 1)
t = c_high./256;
else
    t = c_high;
end
if any(c_low > 1)
c_low = c_low./256;
end
R = linspace(c_low(1),t(1),fn);
G = linspace(c_low(2),t(2),fn);
B = linspace(c_low(3),t(3),fn);

T = [R', G', B'];

map(1:fn, :) = T;
end
