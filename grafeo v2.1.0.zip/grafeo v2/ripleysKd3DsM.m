function [K,L,lam1,lam2,vol] = ripleysKd3DsM(C1,C2,mask,D,p,dim,varargin)

% ripleysKd3DsM is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

unitfactor = 10^-3;
nD = numel(D);
borcor = 0;
pix = 10;
if ~iscell(mask)
    B = bwboundaries(mask);
else
    B = mask{1};
end
nD = numel(D);
borcor = 0;
pix = 10;
if ~iscell(mask)
    if nargin >= 7 
         pix = varargin{1}; 
         if ~isempty(pix) | pix ~= 0
               B{1} = B{1}*pix;
         end
    end
    if nargin >= 8 & ~isempty(varargin{2})
        borcor = varargin{2}; 
    end
else
    if nargin >= 8 & ~isempty(varargin{2})
        borcor = varargin{2}; 
    end
end
if nargin >= 9 & ~isempty(varargin{3})
    unitfactor = varargin{3}; 
end


xc1 = C1(:,1); yc1 = C1(:,2); 
if dim == 3
zc1 = C1(:,3);
zc2 = C2(:,3);
end
xc2 = C2(:,1); yc2 = C2(:,2); 
% zmin = min(min(zc1),min(zc2));
% zmax = max(max(zc1),max(zc2));
if dim == 3
zmin = min(min(zc1),min(zc2));
zmax = max(max(zc1),max(zc2));
h = zmax - zmin;
elseif dim == 2
    h = 1;
end
inPoint1 = numel(xc1);
inPoint2 = numel(xc2); 

if ~iscell(mask)
    ci = find(mask==1);
    if ~isempty(pix)
        vol = h*unitfactor^2*numel(ci)*pix^2;%*(10^-6) vol of the region of intrest
    else
        vol = h*numel(ci); % vol of the region of intrest  
    end
else
    if dim == 3
        vol = h*abs(polyarea(B(:,1),B(:,2)));
    elseif dim ==2
        vol = abs(polyarea(B(:,1),B(:,2)));
    end
end

fact = vol/(inPoint2*inPoint1);
if inPoint2 == 0
    fact = 0;
    lam2 = 0;
else
    lam2 = inPoint2/vol;
end

if inPoint1 ==0
    fact = 0;
    lam1 = 0;
else
    lam1 = inPoint1/vol;
end

if dim == 3
    Dist = pdist2([xc1,yc1,zc1],[xc2,yc2,zc2]);
elseif dim == 2
    Dist = pdist2([xc1,yc1],[xc2,yc2]);
end

if ~borcor
    Dist = Dist(:);
    Dist = Dist((Dist <= D(end))&(Dist > 0));
    K = zeros(nD,1);
    for j = 1:nD
        kk = numel(D) -j +1;%;%kk = D(end-j+1);
            K(kk) = fact*numel(Dist);
        if kk > 1
            Dist(Dist > D(end-j)) = [];
        end
    end
else
   range = D(end);%nD;
   boundaryCorr = zeros(size(Dist));
    for i = 1:inPoint1
        for j = 1:inPoint2
            if Dist(i,j) <= range
           
                 [xcirc, ycirc] = circleplot(xc(i),yc(i),Dist(i,j));
                try
                     ind= find(InPolygon(xcirc, ycirc, B{1}(:,2),B{1}(:,1)));
                catch
                     ind= find(inpolygon(xcirc, ycirc, B{1}(:,2),B{1}(:,1)));
                end

              if ~isempty(ind)
              boundaryCorr(i,j) = numel(ind)/numel(xcirc);
              
              ind= [];
              end
            end
        end
     end  
    w = boundaryCorr(:);
    weight = 1./w;
    isfin = find(~isfinite(weight));
    weight(isfin)=0;
    Dist = Dist(:);
    K = zeros(nD,1);
    
for i = 1:nD
	ind2 = find(Dist <= D(i) & Dist > 0);
	K(i) = fact*sum(weight(ind2));
end
end

if dim == 3
    K = K*unitfactor^3; 
    L = nthroot(3*K/pi/4,3) -D(:)*unitfactor;
elseif dim == 2
    K = K*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
    L = sqrt(K/pi) - D(:)*unitfactor;
end

green = [23,183,105]/255;
violet = [160,121,167]/255;
if p
% if dim == 3
%     sphered = (4*pi*(D*unitfactor).^3)/3; % spehere
% elseif dim == 2
%     sphered = pi*(D*unitfactor).^2; % circle
% end
figure
plot(D*unitfactor,K,'k')
xlabel('Distances - d'),ylabel('K')
figure,plot(D*unitfactor,L,'r.')
xlabel('Distances - d'),ylabel('L')

figure;
if ~iscell(mask)
    plot(B{1}(:,2),B{1}(:,1),'-k')
else
    plot(B(:,1),B(:,2),'-k')
end
hold on; plot(C1(:,1),C1(:,2),'.','Color',violet);
plot(C2(:,1),C2(:,2),'.','Color',green);
hold off;
end

end

function [x,y] = circleplot(xc1,yc1,r)

t=0:0.25:2*pi;
x=xc1+r*cos(t);
y=yc1+r*sin(t);


% t = 0.:0.01:1;
% [th,ph] = meshgrid( t*2*pi,t*2*pi );
% x = r*cos(th).*cos(ph) ;
% y = r*cos(th).*sin(ph) ;
% z = r*sin(th) ;

end
