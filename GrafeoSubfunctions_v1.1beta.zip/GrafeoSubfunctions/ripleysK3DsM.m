function [K,L,lam,vol] = ripleysK3DsM(c,mask,D,p,dim,varargin)
% ripleysK3DsM is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

% centroids, Nx2 matrix containning x any coordinates of the centroids of
% the clusters

% mask is mask image, with 1s inside studied region and 0s elsewheres 
% xi and yi are vertices of studied region
% range max distance at which K function will be estimated

%% get coordinates of all points (pixels) inside study region
% and innitialization
unitfactor = 10^-3;
if ~iscell(mask)
    B = bwboundaries(mask);
else
    B = mask{1};
end
nD = numel(D);
borcor = 0;
pix = 10;
if ~iscell(mask)
    if nargin >= 6 
         pix = varargin{1}; 
         if ~isempty(pix) | pix ~= 0
               B{1} = B{1}*pix;
         end
    end
    if nargin >= 7 & ~isempty(varargin{2})
        borcor = varargin{2}; 
    end
else
    if nargin >= 7 & ~isempty(varargin{2})
        borcor = varargin{2}; 
    end
end
if nargin >= 8 & ~isempty(varargin{3})
    unitfactor = varargin{3}; 
end
xc = c(:,1); 
yc = c(:,2); %x, z and y coordinates of centroids
if dim == 3
zc = c(:,3);
zmin = min(zc);
zmax = max(zc);
h = zmax - zmin;
end
if ~iscell(mask)
    ci = find(mask==1);
    if dim == 3
    % pixel size 10 nm, A i s in nm^2, transformed to um^2
        vol = h*numel(ci)*pix^2;%*(10^-6)*pix^2; % vol of the region of intrest
    elseif dim == 2
        if ~isempty(pix)
            vol = numel(ci)*pix^2; %*(10^-6)*pix^2 % vol of the region of intrest
        else
            vol = numel(ci);
        end
    end
else
    if dim == 3
        vol = h*abs(polyarea(B(:,1),B(:,2)));
    elseif dim ==2
        vol = abs(polyarea(B(:,1),B(:,2)));
    end
end

inPoint = numel(xc); %number of clusters
fact = vol/inPoint.^2;
lam = 1/fact;
if dim == 3
    Dist = pdist2([xc,yc,zc],[xc,yc,zc]);
elseif dim == 2
    Dist = pdist2([xc,yc],[xc,yc]);
end

if ~borcor

Dist = Dist(:);
Dist = Dist((Dist <= D(end))&(Dist > 0));
K = zeros(nD,1);
% diffD = diff([D(1),D(1)]);
for j = 1:nD
    kk = numel(D) -j +1;% D(end-j+1);
    K(kk) = fact*numel(Dist);

    if kk > 1
        Dist(Dist > D(end-j)) = [];
    end
end

else
   boundaryCorr = zeros(size(Dist));
for i = 1:inPoint
   
    for j = 1:inPoint
        if j ~= i
            if Dist(i,j) <= D(end)

              [xcirc, ycirc] = circleplot(xc(i),yc(i),Dist(i,j));
              if ~iscell(mask)
                  try
                      ind= find(InPolygon(xcirc, ycirc, B{1}(:,2),B{1}(:,1)));
                  catch
                       ind= find(inpolygon(xcirc, ycirc, B{1}(:,2),B{1}(:,1)));
                  end
              else
                  try
                       ind= find(InPolygon(xcirc, ycirc, B(:,1),B(:,2)));
                  catch
                       ind= find(inpolygon(xcirc, ycirc, B(:,1),B(:,2)));
                  end
              end

              if ~isempty(ind)
                  boundaryCorr(i,j) = numel(ind)/numel(xcirc);
                  ind= [];
              end
            end
        end
    end     
end
w = boundaryCorr(:);
weight = 1./w;
isfin = find(~isfinite(weight));
weight(isfin)=0;
Dist = Dist(:);
K = zeros(nD,1);
for i = 1:nD
	ind2 = find(Dist <= D(i) & Dist > 0);
	K(i) = fact*sum(weight(ind2));
end
end

if dim == 3
   K = K*unitfactor^3;% pixel size 10 nm, V i s in nm^3, transformed to um^3
   L = nthroot(3*K/pi/4,3) -D(:)*unitfactor;
elseif dim == 2
    K = K*unitfactor^2;% pixel size 10 nm, A i s in nm^2, transformed to um^2
    L = sqrt(K/pi) - D(:)*unitfactor;
end

if p == 1
    if dim == 3
        sphered = (4*pi*(D*unitfactor).^3)/3; % spehere
    elseif dim == 2
        sphered = pi*(D*unitfactor).^2; % circle
    end
    sphered = sphered(:);
    figure
    subplot(2,2,1),plot(D*unitfactor,K)
    xlabel('Distances'),ylabel(sprintf('K(d)'))
    axis square
    subplot(2,2,2),plot(D*unitfactor,L)
    xlabel('Distances'),ylabel(sprintf('L(d)'))
    axis square
    subplot(2,2,3),plot(D*unitfactor,sphered)
    xlabel('Distances'),ylabel(sprintf('Sphere'))
    axis square

    figure
    if ~iscell(mask)
     plot(B{1}(:,2),B{1}(:,1)),hold on
    else
     plot(B(:,1),B(:,2)),hold on
    end
    hold on; plot(xc,yc,'.');
    hold off;
end
end
% 
function [x,y] = circleplot(xc,yc,r)

t=0:0.25:2*pi;
x=xc+r*cos(t);
y=yc+r*sin(t);
end

