% C2 = datatesseler3d(:,[1,2]);
% C1 = datatesseler3d1(:,[1,2]);
% C2 = datatesselerfilt(:,[1,2]);
% C1 = datatesselerfilt1(:,[1,2]);
C1 = dataoutshift1(:,[1,2]); % shift
C2 = dataout2(:,[1,2]);
 violet = [160,121,167]/255;
green = [23,183,105]/255;
% violet = [188,91,128]/255
f = figure;
ax = axes;
set(ax,'NextPlot','add');%hold on;hold on;
plot(C2(:,1),C2(:,2),'.g','Color',green,'Parent',ax)
plot(C1(:,1),C1(:,2),'.g','Color',violet,'Parent',ax)
axis square
%%
hold on;
for ki = 1:numel(nodes)
    plot(nodes{ki}(:,1),nodes{ki}(:,2),'-k')
end

%%
C1 = dataoutshift1NF(:,[1,2]);
C2 = dataout2NF(:,[1,2]);
 violet = [160,121,167]/255;
green = [23,183,105]/255;

f = figure;
ax = axes;
set(ax,'NextPlot','add');%hold on;hold on;
plot(C1(:,1),C1(:,2),'.g','Color',violet,'Parent',ax)
plot(C2(:,1),C2(:,2),'.g','Color',green,'Parent',ax)

axis square
%%
violet = [160,121,167]/255;
green = [23,183,105]/255;
x = dataoutshift1;
y = dataout2;
f = figure;
ax = axes;
set(ax,'NextPlot','add')
plot(G1,'XData',x(:,1),'YData',x(:,2),'EdgeColor',violet, 'NodeColor',violet,'Parent',ax)
plot(G2,'XData',y(:,1),'YData',y(:,2),'EdgeColor',green, 'NodeColor',green,'Parent',ax)
% plot(G1,'EdgeColor',violet, 'NodeColor',violet,'Parent',ax)
% plot(G2,'EdgeColor',green, 'NodeColor',green,'Parent',ax)
axis square
% C2 = datatesseler3d(:,[1,2]);
% C1 = datatesseler3d1(:,[1,2]);
% C2 = datatesselerfilt(:,[1,2]);
% C1 = datatesselerfilt1(:,[1,2]);
%%
C1 = datatesselerfilt(:,[1,2]);
% C2 = dataout2(:,[1,2]);
 violet = [160,121,167]/255;
green = [23,183,105]/255;
% violet = [188,91,128]/255
f = figure;
ax = axes;
set(ax,'NextPlot','add');%hold on;hold on;

plot(C1(:,1),C1(:,2),'.g','Color',violet,'Parent',ax)
% plot(C2(:,1),C2(:,2),'.g','Color',green,'Parent',ax)

axis square