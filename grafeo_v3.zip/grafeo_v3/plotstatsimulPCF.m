function  f1 = plotstatsimulPCF(obs,avvar,UCIvar,LCIvar,D,unitfactor,colfill,xtick,ytick,linecol,f1,ylab,xlab)
% plotstatsimulPCF is a subfunction of the Grafeo Matlab script package.
% This function permits plotting fexperimenal Point correlation function
% overlaid with randomiation envelopes
% The first version of this function was developped for the following
% publication:  
% Peaucelle et al., iScience 2020 Multicolor 3D-dSTORM Reveals Native-State Ultrastructure of Polysaccharides' 
%Network during Plant Cell Wall Assembly
% Copyright (C) Kalina Tamara Haas, 2020, Versailles, France
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 07/01/2021

alw = 1;    % AxesLineWidth
fsz = 7;      % Fontsize
lw = 1.5;      % LineWidth
msz = 8;       % MarkerSize
fszl = 7; % Fontsize legend 
fontname = 'Helvetica';
% colfill = [66,103,176]/255;
mc = [106,37,58]/255;
xtick = xtick*unitfactor;
for i = 1:numel(ytick)
yticklab{i} = num2str(ytick(i));
end
for i = 1:numel(xtick)
xticklab{i} = num2str(xtick(i));
end
figure(f1)
hold on
for numcell = 1:size(obs,2)
    plt = plot(D*unitfactor,obs(:,numcell),':k','Color',linecol);
    fillplot(D*unitfactor,avvar(:,numcell),UCIvar(:,numcell),LCIvar(:,numcell),0.5,0.5,colfill, colfill,colfill)  
    plt.LineWidth = lw;
end
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');
scalex = 1;
if scalex
set(gca,'XTick',xtick) 
set(gca,'XTickLabel',xticklab)
xlim(gca,[min(xtick),max(xtick)])
end
scaley =1;
if scaley
    set(gca,'YTick',ytick) 
    set(gca,'YTickLabel',yticklab)
    ylim(gca,[min(ytick),max(ytick)]);
end
yl = ylabel(gca, ylab);
set(yl,'Fontname',fontname, 'Fontsize', fsz)  
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% tl = title(sprintf('Cell number: %d ',numcell));
% set(tl,'Fontname',fontname, 'Fontsize', fsz)  
set(gca,'box','off');
xl = xlabel(gca, xlab);
set(xl,'Fontname',fontname, 'Fontsize', fsz)    


end

