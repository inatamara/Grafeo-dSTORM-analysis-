function  f1 = plotstatsimulRipley(obs,avvar,UCIvar,LCIvar,D,unitfactor,colfill,xtick,ytick,linecol,choice,f1,ylab,xlab)
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here

alw = 1;    % AxesLineWidth
fsz = 7;      % Fontsize
lw = 1.5;      % LineWidth
msz = 8;       % MarkerSize
fszl = 7; % Fontsize legend 
fontname = 'Helvetica';
% colfill = [66,103,176]/255;
mc = [106,37,58]/255;
xtick = xtick*unitfactor;
for i = 1:numel(ytick)
yticklab{i} = num2str(ytick(i));
end
for i = 1:numel(xtick)
xticklab{i} = num2str(xtick(i));
end
figure(f1)
hold on
for numcell = 1:size(obs,2)
% f1 = figure;
% hold on;
if ismember(choice,1:12)
    plt = plot(D*unitfactor,obs(:,numcell),':k','Color',linecol);
    plt.LineWidth = lw;
    fillplot(D*unitfactor,avvar(:,numcell),UCIvar(:,numcell),LCIvar(:,numcell),0.5,0.5,colfill, colfill,colfill)
else
     plt = plot(D(1:end-1)*unitfactor,obs(:,numcell),':k','Color',linecol);
    fillplot(D(1:end-1)*unitfactor,avvar(:,numcell),UCIvar(:,numcell),LCIvar(:,numcell),0.5,0.5,colfill, colfill,colfill)  
    plt.LineWidth = lw;
end


set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');
scalex = 1;
if scalex
set(gca,'XTick',xtick) 
set(gca,'XTickLabel',xticklab)
xlim(gca,[min(xtick),max(xtick)])
end
scaley =1;
if scaley
    set(gca,'YTick',ytick) 
    set(gca,'YTickLabel',yticklab)
    ylim(gca,[min(ytick),max(ytick)]);
end
yl = ylabel(gca, ylab);
set(yl,'Fontname',fontname, 'Fontsize', fsz)  
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% tl = title(sprintf('Cell number: %d ',numcell));
% set(tl,'Fontname',fontname, 'Fontsize', fsz)  
set(gca,'box','off');
xl = xlabel(gca, xlab);
set(xl,'Fontname',fontname, 'Fontsize', fsz)    


end

