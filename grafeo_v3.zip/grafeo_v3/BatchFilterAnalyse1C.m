function BatchFilterAnalyse1C(Csusu,subsubdir,searchstring,...
    numn,filtval,ch,dimn,saveflag)

% BatchFilterAnalyse is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
if ~ismac
    flagslash = '\';
else
    flagslash = '/';
end

tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
Csusu1 = Csusu(tfmat);
tfm = ~cellfun('isempty',strfind(Csusu1,searchstring));
selecfiles = Csusu1(tfm);
ns = numel(selecfiles);

%%
for ni = 1:ns   
filetoload = strcat(subsubdir,flagslash,selecfiles{ni});
tmp = load(filetoload);
filetosave3d = strrep(filetoload,searchstring,saveflag);
if ~exist(filetosave3d,'file')
if dimn == 3
    ind = [1,2,5];
elseif dimn == 2
    ind = [1,2];
end
dim = tmp.dim;
if ch == 1
 dataout1 = tmp.dataout1; 
 densitythr1 = tmp.densitythr1;  
 namech1 = tmp.namech1; 
 Vp1 = tmp.Vp1;
 Dp1 = tmp.Dp1;
 photonTH1 = tmp.photonTH1;
 locprec1 = tmp.locprec1;
 x = dataout1(:,ind);
 dataout1NF = dataout1;
 Dp1NF = Dp1;
Vp1NF = Vp1;
Dav11 = knnsearchThr(x,x,numn,'median');
dataout1 = dataout1(Dav11 <= filtval,:);
Dp1 = Dp1(Dav11 <= filtval);
Vp1 = Vp1(Dav11 <= filtval);
 disp(strcat('Saving ...',filetosave3d))
 filtval1 = filtval;
numn11 = numn;
save(filetosave3d,'dataout1',...
        'densitythr1','namech1','Dp1',...
        'Vp1','numn11',...
        'dimn','filtval1','Dav11',...
        'dataout1NF','dim',...
        'Dp1NF','Vp1NF','photonTH1','locprec1') 
elseif ch == 2
 dataout2 = tmp.dataout2;   
 densitythr2 = tmp.densitythr2; 
 namech2 = tmp.namech2;
 Vp2 = tmp.Vp2;
 Dp2 = tmp.Dp2;
 photonTH2 = tmp.photonTH2;
 locprec2 = tmp.locprec2;
 x = dataou2(:,ind);
 Dp2NF = Dp2;
Vp2NF = Vp2;
dataout2NF = dataout2;
Dav22 = knnsearchThr(x,x,numn,'median');
Vp2 = Vp2(Dav22 <= filtval);
Dp2 = Dp2(Dav22 <= filtval);
dataout2 = dataout2(Dav22 <= filtval,:);
disp(strcat('Saving ...',filetosave3d))
filtval2 = filtval;
numn22 = numn;
save(filetosave3d,'dataout2',...
        'densitythr2','namech2','Dp2',...
        'Vp2','numn22',...
        'dimn','filtval2','Dav22',...
        'dataout2NF','dim',...
        'Dp2NF','Vp2NF','photonTH2','locprec2') 
end
else
      disp('Already exists')
end
disp('Finished ...')
end