function [dist,X1upRotxy, X1downRotxy] = pointsInInclinedCylinder(X1,ct,degX,degY,XYZ)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

X1up = X1 + [0,0,ct];
X1down = X1 + [0,0,-ct];
XQx = [1,0,0] + [0,X1(2),X1(3)];
XPx = [-1,0,0]+ [0,X1(2),X1(3)];
ux = XQx - XPx;
x0x = XPx;
XYZold(:,1) = X1up';
XYZold(:,2) = X1down';
% degX = -45;
[XYZnewX, ~, ~] = AxelRot(XYZold, degX, ux, x0x);
% degY = 30;
XQy = [0,1,0] + [X1(1),0,X1(3)];
XPy = [0,-1,0]+ [X1(1),0,X1(3)];
uy = XQy - XPy;
x0y = XPy;
[XYZnewXY, ~, ~] = AxelRot(XYZnewX, degY, uy, x0y);
%
XYZold = XYZold';
XYZnewXY = XYZnewXY';
% XYZnewX = XYZnewX';

X1upRotxy = XYZnewXY(1,:);
X1downRotxy = XYZnewXY(2,:);
% dist = point_to_line(XYZ, X1upRotxy, X1downRotxy);

% BA = ;
% BC  = pdist2(X1downRotxy,X1upRotxy);
B = repmat(X1downRotxy,size(XYZ,1),1);
C = repmat(X1upRotxy,size(XYZ,1),1);
A = XYZ;
BC = C - B; % 
v = A - B;
d = BC ./ sqrt(sum(BC.^2,2)); 
t = dot(v,d,2);
P = B + t .* d;
ind = P(:,3) > C(:,3) | P(:,3) < B(:,3);
dist = sqrt(sum((P-A).^2,2)); 
% dist(ind) = -1;
% P1 = P;
% P1(ind,:) = [];
% XYZ1 = XYZ;
% XYZ1(ind,:) = [];
dist1 = dist;
dist1(ind,:) = [];

% figure;
% hold on
% plot3(X1downRotxy(:,1),X1downRotxy(:,2),X1downRotxy(:,3),'.r','MarkerSize',20)
% plot3(X1upRotxy(:,1),X1upRotxy(:,2),X1upRotxy(:,3),'.b','MarkerSize',20)
% plot3(XYZ(:,1),XYZ(:,2),XYZ(:,3),'.k','MarkerSize',10)
% plot3(P1(:,1),P1(:,2),P1(:,3),'.y','MarkerSize',10)
% plot3(XYZ1(:,1),XYZ1(:,2),XYZ1(:,3),'.m','MarkerSize',10)
 

% function d = point_to_line(pt, v1, v2)
% pt should be nx3
% v1 and v2 are vertices on the line (each 1x3)
% d is a nx1 vector with the orthogonal distances

% v1 = repmat(v1,size(pt,1),1);
% v2 = repmat(v2,size(pt,1),1);
% a = v1 - v2; % 
% b = pt - v2;
% d = sqrt(sum(cross(a,b,2).^2,2)) ./ sqrt(sum(a.^2,2)); 
% 
% %d = norm(cross(a,b)) / norm(a);
% % Normalize couple of vectors
% ae = a ./ sqrt(sum(a.^2,2));
% be = b ./ sqrt(sum(b.^2,2));
% % Two cross products give direction of perpendicular
% h = cross(ae,cross(ae,be,2),2);
% he = h ./ sqrt(sum(h.^2,2));
% % Perpendicular is its base vector times length
% perp = he.*d;


