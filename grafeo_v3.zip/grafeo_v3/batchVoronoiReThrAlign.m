function batchVoronoiReThrAlign(Csusu,subsubdir,flag,...
fac,photonTH1,photonTH2,locprec1,locprec2,densitythr1,densitythr2,...
searchstring,saveflag,varargin)
% ThibatchVoronoiReThrAligns is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

if ~ismac
    flagslash = '\'; %flagslash
else
    flagslash = '/';
end
 
tfmat = ~cellfun('isempty',strfind(Csusu,'.mat'));
Csusu1 = Csusu(tfmat);
tfm = ~cellfun('isempty',strfind(Csusu1,searchstring));
selecfiles = Csusu1(tfm);
ns = numel(selecfiles);

if nargin == 13
    dimn = varargin{1};
else
    dimn = [];
end
tic
for ni = 1:ns   
    filetoload = strcat(subsubdir,flagslash,selecfiles{ni});
    names = strrep(filetoload,searchstring,saveflag);
%     names = strcat(subsubdir,flagslash,saveflag,selecfiles{ni}); %(9:end)
    if ~exist(names,'file')
        try
            tmp = load(filetoload,'dim','leftrightcount','updowncount','zcount','namech1','namech2');
            namech2 = tmp.namech2;
            namech1 = tmp.namech1;
            dim = tmp.dim;
            loadChanel1 = load(strcat(subsubdir,flagslash,namech1));
            loadChanel2 = load(strcat(subsubdir,flagslash,namech2));
            if densitythr1
                [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
                    photonTH1,locprec1,densitythr1,flag(1),fac(1),dimn); 
            else
                [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
                    photonTH1,locprec1,[],flag(1),fac(1),dimn); 
            end
            
            if densitythr2
                [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
                    photonTH2,locprec2,densitythr2,flag(2),fac(2),dimn); 
            else
                [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
                    photonTH2,locprec2,[],flag(2),fac(2),dimn); 
            end
            leftrightcount = tmp.leftrightcount;
            updowncount = tmp.updowncount;
            zcount = tmp.zcount;
            
            dataoutshift1 = dataout1;
            if ~isempty(leftrightcount)
            dataoutshift1(:,1)  = dataoutshift1(:,1) - leftrightcount;
            end
            if ~isempty(updowncount)
            dataoutshift1(:,2)  = dataoutshift1(:,2) - updowncount;
            end
            if dim == 3 & ~isempty(zcount)
                dataoutshift1(:,5)  = dataoutshift1(:,5) - zcount;
            end
            save(names,'dataout1','dataout2',...
            'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
            'leftrightcount','updowncount','zcount',...
            'dim','namech1','namech2','Dp1','Dp2','photonTH1','photonTH2','locprec1','locprec2')
        
         disp(strcat('Completed: ',names))
        catch
            disp('Didn''t work...')
        end
    else
        disp('Already exist')
    end
end
disp('Folder analysed ...')
toc
end
