%% 2d scatter plot
% This function is no longer in use in the Grafeo v3
% 2D scatter
% s_scattplot = s_roi3dscatter + [pbw+pbs 0 0 0];            
% uicontrol('Style','pushbutton','String','2d scatter',...
%            'Tag','roi3dvoronoi','Position',s_scattplot,...
%            'Callback',@scattplot_Callback);
function scattplot_Callback(~,~)
    pos = getPosition(hrect);
    pix = eval(textbox_minPIX1.String);
    violet = eval(colch1.String);
green = eval(colch2.String);
pos = round(pos);
ms = eval(msedit.String);
if ~isempty(pos)
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);

fig1 = figure;
ax1 = axes;
set(ax1,'NextPlot','add')
if pm1.Value == 1
    if flagalign
    ind1 = find(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
    dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);
    x1 = dataoutshift1(ind1,1);
    y1 = dataoutshift1(ind1,2);
    else
    ind1 = find(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
    dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);
    x1 = dataout1(ind1,1);
    y1 = dataout1(ind1,2);
    end
    ind2 = find(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);
    x2 = dataout2(ind2,1);
    y2 = dataout2(ind2,2);
    plot(x1,y1,'.','Color',violet,'MarkerSize',ms(1),'Parent', ax1);    
    plot(x2,y2,'.','Color',green,'MarkerSize',ms(2),'Parent', ax1);  
elseif pm1.Value == 2
    
    if flagalign
        ind1 = find(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);
        x1 = dataoutshift1(ind1,1);
        y1 = dataoutshift1(ind1,2);
    else
        ind1 = find(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);
        x1 = dataout1(ind1,1);
        y1 = dataout1(ind1,2);
    end
    plot(x1,y1,'.','Color',violet,'MarkerSize',ms(1),'Parent', ax1);    
elseif pm1.Value == 3
    ind2 = find(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);
    x2 = dataout2(ind2,1);
    y2 = dataout2(ind2,2);
    plot(x2,y2,'.','Color',green,'MarkerSize',ms(2),'Parent', ax1);  
end
axis equal
box on;
set(ax1,'xlim',[pos(1),pos(1)+pos(3)])
set(ax1,'ylim',[pos(2),pos(2)+pos(4)])
set(ax1,'xtick',[],'ytick',[]);
pos1 = get(fig1, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig1, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig1,'color','w')
set(fig1,'InvertHardcopy','on');
end
end