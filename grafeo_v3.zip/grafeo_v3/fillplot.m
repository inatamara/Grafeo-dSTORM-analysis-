function fillplot( x,y,y_up,y_low,fill_transparency,edge_transparency,fill_color, edge_color,line_color )
% fillplot is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018


n1 = length(x);
n2 = length(y);
n3 = length(y_up);
n4 = length(y_low);
x = x(:)';
y = y(:)';
y_up = y_up(:)';
y_low = y_low(:)';

if (n1~=n2)|(n1~=n3)|(n3~=n2)|(n3~=n4)
    error('Input vectors should have the same length')
end

h = fill([x,fliplr(x)],[y_up,fliplr(y_low)],fill_color);
set(h,'EdgeColor',edge_color,'FaceAlpha',fill_transparency,'EdgeAlpha',edge_transparency)
hold on;
plot(x,y,'Color',line_color,'LineWidth',1.5)
hold off;
end

