function xyrand = randomPTSinBoundary(x,y,nsample,dim,zb,ze,ifplot)
% Delauney triangulation of the boundary
XY = [x(:),y(:)];
tri = delaunay(XY);

% shp = alphaShape(x(:),y(:));
% shp.Alpha = 550;
% figure;plot(shp)

% tri = alphaTriangulation(shp);
% compute the area of each triangle 
% use a 2x2 determinant, in a vectorized form
v1 = XY(tri(:,1),:);
v2 = XY(tri(:,2),:);
v3 = XY(tri(:,3),:);
    
% translate
v1 = v1-v3;
v2 = v2-v3;
    
% vectorized determinant
% divide by factorial(2) for the area
areas = (v1(:,1).*v2(:,2) - v1(:,2).*v2(:,1))/2;
% normalize the areas to sum to 1
areas = abs(areas/sum(areas));
% pick a random triangle, proportional to the relative area of each triangle. 
% You can do this for many points at once, using the discretize tool. 
% I'll assume you want to generate nsample points. I'll do these computations for the data provided, here, for 1000 points.
% nsample = 1000;
R = rand(nsample,1);
tind = discretize(R,cumsum([0;areas]));
% Next, for each triangle chosen, we will find ONE point that lives inside that triangle. Again, a vectorized computation.
v1 = XY(tri(tind,1),:);
v2 = XY(tri(tind,2),:);
v3 = XY(tri(tind,3),:);
R1 = rand(nsample,1);
xyrand = v1.*repmat(R1,[1 2]) + v2.*repmat(1-R1,[1 2]);
R2 = sqrt(rand(nsample,1));
xyrand = xyrand.*repmat(R2,[1 2]) + v3.*repmat(1-R2,[1 2]);
% I used repmat above, but it is also easily done using scalar dimension expansion as found in R2016b or later, or using bsxfun.

if dim == 3
RP2z = (ze-zb).*rand(nsample,1) + zb;
xyrand(:,3) = RP2z;
end
if ifplot
    figure;
plot(xyrand(:,1),xyrand(:,2),'.', 'MarkerSize', 1)
hold on
plot(x,y,'r-')
end