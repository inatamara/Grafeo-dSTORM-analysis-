function [rho,sig,yfit,xdata,ydata] = PCFsinglemoleculefit1gauss(D,obs2,N,p,x0, varargin)
% PCFfit1gauss1exGauss is a subfunction of the Grafeo Matlab script package.
% This function allows fitting a sum of Gaussian and exGaussian to Point correlation function.
% The first version of this function was developped for the following
% publication:  
% Peaucelle et al., iScience 2020 Multicolor 3D-dSTORM Reveals Native-State Ultrastructure of Polysaccharides' 
%Network during Plant Cell Wall Assembly
% Copyright (C) Kalina Tamara Haas, 2020, Versailles, France
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 07/01/2021
if nargin == 5
    lb = [0,0];
    ub = [inf,inf];
elseif nargin == 7
    lb = varargin{1};   
    ub = varargin{2}; 
elseif nargin == 6
    lb = varargin{1};   
end

xdata = D;
if numel(N) == 1
xdata = xdata(1:N);
xdata = xdata(:);
ydata = obs2(1:N);
elseif numel(N) == 2
 xdata = xdata(N(1):N(2));
xdata = xdata(:);
ydata = obs2(N(1):N(2));   
end
ydata = ydata(:);

% options = optimoptions('lsqcurvefit','Algorithm','levenberg-marquardt');
options = optimoptions('lsqcurvefit','TolFun',1e-10);
fun =  @(x,xdata)(exp(-(xdata).^2/(4*(x(2))^2))/(4*pi*x(2)^2)/x(1));
bestx = lsqcurvefit(fun,x0,xdata,ydata,lb,ub,options);

rho = bestx(1);
sig = bestx(2);
yfit = exp(-(xdata).^2/(4*sig^2))/(4*pi*sig^2)/rho;

%
if p
figure

plot(xdata,ydata,'*b');
hold on
plot(xdata,yfit,'-r');

xlabel('xdata')
ylabel('Response Data and Curve')
title('Data and Best Fitting Exponential Curve')
legend('Data','Fitted Curve')
hold off
end
