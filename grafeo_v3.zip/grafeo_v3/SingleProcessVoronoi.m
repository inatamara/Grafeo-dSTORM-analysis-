function SingleProcessVoronoi(namech1,namech2,subsubdir,flagch1,flagch2,...
        flag,fac,photonTH1,photonTH2,locprec1,locprec2,algnflag,...
        densitythr1,densitythr2,saveflag,dim)
% SingleProcessVoronoi is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
tic
loadChanel1 = load(strcat(subsubdir,namech1));
loadChanel2 = load(strcat(subsubdir,namech2));

if densitythr1
    [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
        photonTH1,locprec1,densitythr1,flag(1),fac(1),dim); 
else
    [dataout1,densitythr1,dim,Vp1,Dp1] = voronoiData(loadChanel1,...
        photonTH1,locprec1,[],flag(1),fac(1),dim); 
end

if densitythr2
    [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
        photonTH2,locprec2,densitythr2,flag(2),fac(2),dim); 
else
    [dataout2,densitythr2,dim,Vp2,Dp2] = voronoiData(loadChanel2,...
       photonTH2,locprec2,[],flag(2),fac(2),dim); 
end
if algnflag
    try
        if dim == 3
            ind = [1,2,5];
        elseif dim == 2
            ind = [1,2];
        end
        [~,leftrightcount,updowncount,zcount,~,exitflag,output] = ...
            simulanielminim(dataout1(:,ind),dataout2(:,ind),dim); 
        dataoutshift1 = dataout1;
        dataoutshift1(:,1)  = dataout1(:,1) - leftrightcount;
        dataoutshift1(:,2)  = dataout1(:,2) - updowncount;
    if dim == 3
        dataoutshift1(:,5)  = dataout1(:,5) - zcount;
    end
    catch
        dataoutshift1 = [];
        leftrightcount = [];
        updowncount = [];
        exitflag = [];
        output = [];
        zcount = [];
    end
else
    dataoutshift1 = [];
    leftrightcount = [];
    updowncount = [];
    exitflag = [];
    output = [];
    zcount = [];                
end
uisave({'dataout1','dataout2',...
'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
'leftrightcount','updowncount','exitflag', 'output','zcount',...
'dim','namech1','namech2','Dp1','Dp2','photonTH2','locprec2',...
'photonTH1','locprec1'},...
strcat(subsubdir,saveflag,flagch1,'_',flagch2,'_','.mat'))
disp('Finished ...')
toc
end


