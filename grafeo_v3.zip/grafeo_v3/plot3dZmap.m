   % convert to n x 3 matrix
%    L = [x(:) y(:) L(:)];
% p.colorrange = [];
% L = dat1;   
function plot3dZmap(L,cmap,ax,mark_ch,mark_sz,varargin)
if nargin == 6
    alp = varargin{1};
else
    alp = 1;
end
p.colorrange = []; 
p.colordata = L(:,3);                
if isempty(p.colorrange)                 
   min_c = min(p.colordata);            
   max_c = max(p.colordata);
else                                    
   min_c = p.colorrange(1);
   max_c = p.colorrange(2);
end
range_c = max_c - min_c;

% Get current colormap
% cmap = colormap;
% cmap = pink;
if range_c < 0, cmap = flipud(cmap); end
clen = length(cmap);
% Calculate color value for each point
L(:,4) = ...
   min(max(round((p.colordata-min(min_c,max_c))*(clen-1)/abs(range_c)),1),clen);

% Don't plot points with NaN color values
L(isnan(p.colordata),3) = NaN;
% Sort by color value
L = sortrows(L,4);


%-- Plot data points in groups by color value

% Build index vector of color transitions (last point for each color)
dLix = [find(diff(L(:,4))>0); size(L,1)];

% nxtplot = get(gca,'NextPlot');     % save 'NextPlot' property value
s = 1;                             % index of 1st point in a  color group
set(ax,'NextPlot','add');%hold on;hold on;
  for k = 1:length(dLix)             % loop over each non-empty color group
     h = scatter3(L(s:dLix(k),1),L(s:dLix(k),2),L(s:dLix(k),3),mark_sz,cmap(L(s,4),:),'filled'); 
       set(h, 'MarkerEdgeAlpha', alp, 'MarkerFaceAlpha', alp);
     s = dLix(k)+1;                  % next group starts at next point
     if k == 1, hold on; end         % add next group to same axes
  end
  
  
%    for k = 1:length(dLix)             % loop over each non-empty color group
%      plot1 = plot3(L(s:dLix(k),1), ...       % points in this group x
%            L(s:dLix(k),2), ...       %                      y
%            L(s:dLix(k),3), ...       %                      z
%            mark_ch,                          ... % marker character
%            'MarkerSize',mark_sz,             ... % marker size
%            'MarkerEdgeColor',cmap(L(s,4),:), ... % same marker color from cmap
%            'MarkerFaceColor',cmap(L(s,4),:), ... % for all points in group
%            'Tag','plot3k');                      % tag each group
%        plot1.Color(4) = alp;
%      s = dLix(k)+1;                  % next group starts at next point
%      if k == 1, hold on; end         % add next group to same axes
%   end 
end