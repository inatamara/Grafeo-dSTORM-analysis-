%%
s_roi2dgraph = s_roi3dvoronoi - 5.5*[0 pbh+pbs 0 0];            
uicontrol('Style','pushbutton','String','2d Graph',...
           'Tag','roi2dgraph','Position',s_roi2dgraph,...
           'Callback',@roi2dgraph_Callback);
       %% loadding graph data
s_loadgraph = s_roi2dgraph + [pbw + pbs 0 0 0];                 
uicontrol('Style','pushbutton','String','Load graph',...
           'Tag','loadgraph','Position',s_loadgraph,...
           'Callback',@loadgraph_Callback); 
%% load graph-based colocalization or object analysis file
Gsub1 = [];WC1 = [];XYZnodes1 = [];Gsub2 = [];WC2 = [];
XYZnodes2 = [];Cen1 = []; Cen2 = [];
function roi2dgraph_Callback(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);
yellow =  eval(colch3.String);
if ~isempty(pos0) | flagroi
if ~isempty(pos0) & ishghandle(hrect)
pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
else isempty(pos0) | flagroi
    polyin = polyshape(nodes{1}(:,1),nodes{1}(:,2));
   [xlim,ylim] = boundingbox(polyin);
xmin = xlim(1);
xmax = xlim(2);
ymin = ylim(1);
ymax = ylim(2);
pos(1) = xmin;
pos(3) = xmax - xmin;
pos(2) = ymin;
pos(4) = ymax - pos(2);
end

fig = figure;
ax = axes;
ms = eval(msedit.String);
set(ax,'NextPlot','add');
if pm1.Value == 1 % two colors

ind1 = find(Cen1(:,1) <= xmax & Cen1(:,1) >= xmin &...
Cen1(:,2) <= ymax & Cen1(:,2) >= ymin);
GrapsSu1 = Gsub1(ind1);
XY1 = XYZnodes1(ind1);

ind2 = find(Cen2(:,1) <= xmax & Cen2(:,1) >= xmin &...
Cen2(:,2) <= ymax & Cen2(:,2) >= ymin);
GrapsSu2 = Gsub2(ind2);
XY2 = XYZnodes2(ind2);

ns1 = numel(XY1);
ns2 = numel(XY2);

pathcol = [242,187,22]/255;
pathcol2= [127,21,26]/255;

for ii = 1:ns1
p1 = plot(GrapsSu1{ii},'XData',XY1{ii}(:,1),'YData',XY1{ii}(:,2),'EdgeColor',violet,...
    'NodeColor',violet,'MarkerSize',ms(1),'Parent',ax);
p1.NodeLabel = {};
p1.Marker = '.';

end
for ii = 1:ns2
p2 = plot(GrapsSu2{ii},'XData',XY2{ii}(:,1),'YData',XY2{ii}(:,2),'EdgeColor',green, ...
    'NodeColor',green,'MarkerSize',ms(2),'Parent',ax);
p2.NodeLabel = {};
p2.Marker = '.';

end
elseif pm1.Value == 2 % ch&nel 1
    
    ind1 = find(Cen1(:,1) <= xmax & Cen1(:,1) >= xmin &...
    Cen1(:,2) <= ymax & Cen1(:,2) >= ymin);
    GrapsSu1 = Gsub1(ind1);
    XY1 = XYZnodes1(ind1); % ,1:2
    ns1 = numel(XY1);
    for ii = 1:ns1
    p1 = plot(GrapsSu1{ii},'XData',XY1{ii}(:,1),'YData',XY1{ii}(:,2),...
        'EdgeColor',violet, 'NodeColor',violet,'Parent',ax);
    p1.NodeLabel = {};
    p1.Marker = '.';
    end

elseif pm1.Value == 3 % chanel 2
    ind2 = find(Cen2(:,1) <= xmax & Cen2(:,1) >= xmin &...
    Cen2(:,2) <= ymax & Cen2(:,2) >= ymin);
    GrapsSu2 = Gsub2(ind2);
    XY2 = XYZnodes2(ind2);
    ns2 = numel(XY2);
%     ms = 0.1;
    for ii = 1:ns2
        p2 = plot(GrapsSu2{ii},'XData',XY2{ii}(:,1),'YData',XY2{ii}(:,2),'EdgeColor',green, ...
            'NodeColor',green,'MarkerSize',ms(2),'Parent',ax);
        p2.NodeLabel = {};
        p2.Marker = '.';
    end
end
alw = 0.5;
figs = eval(ifig.String); 
axis equal
box on;
set(ax,'xtick',[],'ytick',[]);
set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax, 'LineWidth', alw);
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');
end 
end
%%
function loadgraph_Callback(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);
 cla(ha,'reset')
 [filenamepreal,pathreal] = uigetfile('*.mat','Get a file with graph data');
 flagalign =0;
if pm1.Value == 1

tmp = load(strcat(pathreal,filenamepreal),'dim','dat1','dat2',...
    'Dp1filt','Vp1filt','Dp2filt','Vp2filt','leftrightcount','updowncount','zcount',...
        'densitythr1','densitythr2','namech2','namech1','dim',...
        'locprec2','photonTH2','locprec1','photonTH1'); %
disp('Loading graph data...')

end
if pm1.Value == 1 
    dim = tmp.dim;
    dataoutshift1 = tmp.dat1;
    Vp1 = tmp.Vp1filt;
    Dp1 = tmp.Dp1filt;
    dataout2 = tmp.dat2;    
    Vp2 = tmp.Vp2filt;
    Dp2 = tmp.Dp2filt;
    leftrightcount = tmp.leftrightcount;    
    updowncount = tmp.updowncount;
    zcount = tmp.zcount;
     zcount = tmp.zcount; 
    densitythr1 = tmp.densitythr1;
    densitythr2 = tmp.densitythr2; 
    textbox_minD2.String = num2str(densitythr2);
    textbox_minD1.String = num2str(densitythr1);
    dim = tmp.dim;
    try
    namech2 = tmp.namech2;
    namech1 = tmp.namech1; 
    catch
    namech2 = tmp.tmp568;
    namech1 = tmp.tmp647; 
    end
     flagalign =0;
    try
        photonTH1 = tmp.photonTH1;
        locprec1 = tmp.locprec1;
        photonTH2 = tmp.photonTH2;
        locprec2 = tmp.locprec2;
    catch
        photonTH1 = min(dataout1(:,3));
        locprec1 = max(dataout1(:,4));
        photonTH2 = min(dataout2(:,3));
        locprec2 = max(dataout2(:,4));
    end
        textbox_minP2.String = photonTH2;  
        textbox_minLP2.String = locprec2;
        textbox_minP1.String = photonTH1;  
        textbox_minLP1.String = locprec1;

     textbox_meanDen1.String = num2str(mean(Dp1));
    textbox_medianDen1.String = num2str(median(Dp1));
    textbox_minDen1.String = num2str(min(Dp1));
    textbox_maxDen1.String = num2str(max(Dp1));
    textbox_meanDen2.String = num2str(mean(Dp2));
    textbox_medianDen2.String = num2str(median(Dp2));
    textbox_minDen2.String = num2str(min(Dp2));
    textbox_maxDen2.String = num2str(max(Dp2));
    visu1 = 1;
    visu2 = 1;
     if ~isempty(leftrightcount) | ~isempty(updowncount) | ~isempty(zcount)
        flagalign = 1;
    else
        flagalign = 0;
    end  
        dataout1=dataoutshift1; 
         if ~isempty(leftrightcount)
        dataout1(:,1) = dataout1(:,1) + leftrightcount;
         end
         if ~isempty(updowncount)
        dataout1(:,2) = dataout1(:,2) + updowncount;
         end
        if dim == 3 & ~isempty(zcount)
         dataout1(:,5) = dataout1(:,5) + zcount;
        end
    cla(ha,'reset')
    violet = eval(colch1.String);
    green = eval(colch2.String);
    if isempty(dataoutshift1)
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    else
        plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    end
    set(ha,'NextPlot','add');%hold on;
    plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
    disp('Loading finished')

end

% if pm1.Value == 1
% 
%     plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
%     set(ha,'NextPlot','add');%hold on;
%     plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
%     try
%         leftrightcount = tmp.leftrightcount;
%         updowncount = tmp.updowncount;
%         try
%          zcount = tmp.zcount;
%         catch
%             zcount = 0;
%         end
%     catch
%          [filenamepreal1,pathreal1] = uigetfile('*.mat','Get a file with alignment data');
%          tmp1 = load(strcat(pathreal1,filenamepreal1),'leftrightcount','updowncount',...
%          'zcount'); %
%         leftrightcount = tmp1.leftrightcount;
%         updowncount = tmp1.updowncount;
%         try
%          zcount = tmp1.zcount;
%         catch
%             zcount = 0;
%         end
%     end
%     if isempty(zcount)
%         dim = 2;
%     else
%         dim = 3;
%     end
%      flagalign = 1;
%      disp('Loading align finished')
%      dataout1 = dataoutshift1; 
%      if ~isempty(leftrightcount)
%         dataout1(:,1) = dataout1(:,1) + leftrightcount;
%      end
%      if ~isempty(updowncount)
%         dataout1(:,2) = dataout1(:,2) + updowncount;
%      end
%     if dim == 3 & ~isempty(zcount)
%      dataout1(:,5) = dataout1(:,5) + zcount;
%     end
%     flagalign = 1;  
% end
end

%% end of voronoi visaulization