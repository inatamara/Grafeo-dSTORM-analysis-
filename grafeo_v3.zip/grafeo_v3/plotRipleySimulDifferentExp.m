


folder = 'D:\STORMmeristem\2017_07_31\CBM3_6_8.45ph_callose-647_sk1000-CF568_CBM3-FITC\ripleysAnalysis\';

% out1 = load(strcat(folder,'filt_647_568_488_4_dim_3_ROIripleynSIM25_wall_1_bc-ball.mat'),...
% 'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
% 'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
% 'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
% 'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
% 'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
% 'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');
% 
out1 = load(strcat(folder,'filt_647_568_488_4_dim_3_ROIripley_Nsim25_wall_1NEW2.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');
out2 = load(strcat(folder,'filt_647_568_488_4_dim_3_ROIripley_Nsim25_wall_2aNEW21.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

out3 = load(strcat(folder,'filt_647_568_488_3_dim_3_ROIripley_Nsim25_wall_4.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

out4 = load(strcat(folder,'filt_647_568_488_2_dim_3_ROIripley_Nsim25_wall_4NEW2.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

out5 = load(strcat(folder,'filt_647_568_488_2_dim_3_ROIripley_Nsim25_wall_5halveNEW21.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

out6 = load(strcat(folder,'filt_647_568_488_2_dim_3_ROIripley_Nsim25_wall_6NEW2.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

out7 = load(strcat(folder,'filt_647_568_488_2_dim_3_ROIripley_Nsim25_wall_7NEW2.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

out8 = load(strcat(folder,'filt_647_568_488_3_dim_3_ROIripley_Nsim25_wall_8NEW2.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

out9 = load(strcat(folder,'filt_647_568_488_3_dim_3_ROIripley_Nsim25_wall_9.mat'),...
'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');

% out10 = load(strcat(folder,'filt_647_568_488_4_dim_3_ROIripleynSIM50_wall_10_bc-ball.mat'),...
% 'Lsim12','Lsim21','L12','L21','Lsim1','Lsim2','Lhat1',...
% 'Lhat2','KdMs','LdMs','KdM','LdM','LdM23','LdM13',...
% 'PCF1','PCF2','PCF12','PCF21','PCFsim1','PCFsim2','PCFsim12','PCFsim21',...
% 'Lsim13','Lsim31','Lhat13','Lhat31','Lsim3','Khat3','Lhat3',...
% 'LdMs13','LdM13','PCF3','PCF13','PCF31','PCFsim3','PCFsim13','PCFsim31',...
% 'Lsim23','Lsim32','Lhat23','Lhat32','LdMs23','PCF23','PCF32','PCFsim23','PCFsim32','D');


%%
 prompt = {...
    'Enterx label:',...
    'Enter y ticks',...
    'Enter x ticks',...
    'Enter 1 to scale x axes, 0 otherwise',...
    'Enter 1 to scale y axes, 0 otherwise',...
    'To detrend, enter 1'};
    dlg_title = 'Input';
    num_lines = 1;
    def = {'Distance (nm)','[-0.5,1,2.5,10,20,30]','[10,500]','1','0','1'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    xlab = answer{1};
    ytick = str2num(answer{2});
    xtick = str2num(answer{3}); 
    scalex = str2num(answer{4}); 
    scaley = str2num(answer{5}); 
    dtrend = str2num(answer{6}); 
    %
        choice = menu('chose variable to plot',...
    'Lsim1','Lsim2','Lsim3','LdMs12','LdMs13','LdMs23',...
    'Lsim12','Lsim21','Lsim13','Lsim31','Lsim23','Lsim32',...
    'PCFsim1','PCFsim2','PCFsim3','PCFsim12','PCFsim13','PCFsim23',...
    'PCFsim21','PCFsim31','PCFsim32');
   %
   legendlab = {'Plate 1', 'rnd: 95% CI 1','rnd: mean 1',...
       'Plate 2', 'rnd: 95% CI 2','rnd: mean 2',...
    'Plate 3', 'rnd: 95% CI 3','rnd: mean 3',...
    'Plate 4', 'rnd: 95% CI 4','rnd: mean 4',...
    'Plate 5', 'rnd: 95% CI 5','rnd: mean 5',...
    'Plate 6', 'rnd: 95% CI 6','rnd: mean 6',...
    'Plate 7', 'rnd: 95% CI 7','rnd: mean 7',...
    'Plate 8', 'rnd: 95% CI 8','rnd: mean 8',...
    'Plate 9', 'rnd: 95% CI 9','rnd: mean 9',...
    };
unitfactor = 1;
   npoly = 2;
[var1, obs1,ylab,avvar1,UCIvar1,LCIvar1] = statsimulRipley(choice,out1,dtrend,3);
[var2, obs2,ylab2,avvar2,UCIvar2,LCIvar2] = statsimulRipley(choice,out2,dtrend,3);
 [var3, obs3,ylab,avvar3,UCIvar3,LCIvar3] = statsimulRipley(choice,out3,dtrend,npoly);
[var4, obs4,ylab,avvar4,UCIvar4,LCIvar4] = statsimulRipley(choice,out4,dtrend,npoly);
[var5, obs5,ylab5,avvar5,UCIvar5,LCIvar5] = statsimulRipley(choice,out5,dtrend,3);
[var6, obs6,ylab6,avvar6,UCIvar6,LCIvar6] = statsimulRipley(choice,out6,dtrend,2);
[var7, obs7,ylab7,avvar7,UCIvar7,LCIvar7] = statsimulRipley(choice,out7,dtrend,npoly);
[var8, obs8,ylab8,avvar8,UCIvar8,LCIvar8] = statsimulRipley(choice,out8,dtrend,npoly);
[var9, obs9,ylab9,avvar9,UCIvar9,LCIvar9] = statsimulRipley(choice,out9,dtrend,npoly);
 map = parula(9);%colormapCust( [252,141,89]/256,[153,213,148]/256,7);
colfill2 = map(1,:);%'m';[41 7 89]/256;
colfill3 = map(2,:);%'g';[1 8 124]/256;
colfill4 = map(3,:);%'c';[43 28 140]/256;
colfill5= map(4,:);%'y';[64 72 201]/256;
colfill6 =map(5,:);% 'k';[62 56 242]/256;
colfill7 = map(6,:);%[228,117,0]/255;%[59 66 217]/256;
colfill8 = map(7,:);%[80 90 252]/256;
colfill9 =  map(8,:);%[92 115 242]/256;
colfill10 =  map(9,:);%[92 115 242]/256;
% colfill1 65 174 242
plflag = 0;
if plflag
   f1 = figure;
   hold on
f1 = plotstatsimulRipley(obs1,avvar1,UCIvar1,LCIvar1,out1.D,unitfactor,colfill10,xtick,ytick,colfill10,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs2,avvar2,UCIvar2,LCIvar2,out2.D,unitfactor,colfill2,xtick,ytick,colfill2,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs3,avvar3,UCIvar3,LCIvar3,out3.D,unitfactor,colfill3,xtick,ytick,colfill3,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs4,avvar4,UCIvar4,LCIvar4,out4.D,unitfactor,colfill4,xtick,ytick,colfill4,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs5,avvar5,UCIvar5,LCIvar5,out5.D,unitfactor,colfill5,xtick,ytick,colfill5,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs6,avvar6,UCIvar6,LCIvar6,out6.D,unitfactor,colfill6,xtick,ytick,colfill6,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs7,avvar7,UCIvar7,LCIvar7,out7.D,unitfactor,colfill7,xtick,ytick,colfill7,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs8,avvar8,UCIvar8,LCIvar8,out8.D,unitfactor,colfill8,xtick,ytick,colfill8,choice,f1,ylab,xlab)
f1 = plotstatsimulRipley(obs9,avvar9,UCIvar9,LCIvar9,out9.D,unitfactor,colfill9,xtick,ytick,colfill9,choice,f1,ylab,xlab)
% f1 = plotstatsimulRipley(obs10,avvar10,UCIvar10,LCIvar10,out10.D,unitfactor,colfill10,xtick,ytick,colfill10,choice,f1,ylab,xlab)
%
l = legend(legendlab,'Location','northeast'); % southeast northwest
fszl= 7;
fontname = 'Helvetica';
set(l, 'Interpreter', 'none','FontSize', fszl,'color','w');
set(l,'Fontname',fontname) 
width = 4.5;     % Width in inches
height = 4.5;    % Height in inches
pos = get(f1, 'Position');
set(f1, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(f1,'color','w')
set(f1,'InvertHardcopy','on');
set(f1,'PaperUnits', 'inches');
end
% ytick = [0.5,3];
% xtick = [0, 500,1000];
% for i = 1:numel(ytick)
% yticklab{i} = num2str(ytick(i));
% end
% for i = 1:numel(xtick)
% xticklab{i} = num2str(xtick(i));
% end
% yticklab
colfill = [92 115 242]/255;
colline = [41 7 89]/255;
plall = 0;
if plall
f1 = figure;
set(f1,'NextPlot','add')
% cla

 ha = tight_subplot(3,3,[.05 .05],[.05 .05],[.05 .05])
  axes(ha(1)); 
 f1 = plotstatsimulRipley(obs1,avvar1,UCIvar1,LCIvar1,out1.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
 ylim(ha(1),[min(ytick),max(ytick)]);
 xlim(ha(1),[min(xtick),max(xtick)]);
% %  set(gca,'XTickLabel','');
% %   set(gca,'YTickLabel','')
 axes(ha(2)); 
f1 = plotstatsimulRipley(obs2,avvar2,UCIvar2,LCIvar2,out2.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
  ylim(ha(2),[min(ytick),max(ytick)]);
 xlim(ha(2),[min(xtick),max(xtick)]);
%   set(gca,'XTickLabel','');
%   set(gca,'YTickLabel','')
 axes(ha(3));
  
f1 = plotstatsimulRipley(obs3,avvar3,UCIvar3,LCIvar3,out3.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
 ylim(ha(3),[min(ytick),max(ytick)]);
 xlim(ha(3),[min(xtick),max(xtick)]);
 axes(ha(4));
f1 = plotstatsimulRipley(obs4,avvar4,UCIvar4,LCIvar4,out4.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')

 axes(ha(5)); 
f1 = plotstatsimulRipley(obs5,avvar5,UCIvar5,LCIvar5,out5.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')

 axes(ha(6)); 
f1 = plotstatsimulRipley(obs6,avvar6,UCIvar6,LCIvar6,out6.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')

 axes(ha(7)); 
f1 = plotstatsimulRipley(obs7,avvar7,UCIvar7,LCIvar7,out7.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
   ylim(ha(7),[min(ytick),max(ytick)]);
 xlim(ha(7),[min(xtick),max(xtick)]);
 axes(ha(8)); 
f1 = plotstatsimulRipley(obs8,avvar8,UCIvar8,LCIvar8,out8.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
 axes(ha(9)); 
f1 = plotstatsimulRipley(obs9,avvar9,UCIvar9,LCIvar9,out9.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
%   set(gca,'XTickLabel','');
%   set(gca,'YTickLabel','')
% set(ha(1:9),'XTick',xtick) 
% set(ha(1:9),'XTickLabel',xticklab)
% set(ha(1:9),'YTick',ytick) 
% set(ha(1:9),'YTickLabel',yticklab)
%           set(ha(1:9),'XTickLabel',''); set(ha,'YTickLabel','')
width = 6;     % Width in inche9
height = 4;    % Height in inches
pos = get(gcf, 'Position');
set(f1, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(f1,'color','w')
set(f1,'InvertHardcopy','on');
set(f1,'PaperUnits', 'inches');
end
colfill = [92 115 242]/255;
colline = [41 7 89]/255;
%
f1 = figure;
set(f1,'NextPlot','add')
% cla

 ha = tight_subplot(1,6,[.05 .05],[.175 .05],[.05 .05])
%   axes(ha(1)); 
%  f1 = plotstatsimulRipley(obs1,avvar1,UCIvar1,LCIvar1,out1.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
%  ylim(ha(1),[min(ytick),max(ytick)]);
%  xlim(ha(1),[min(xtick),max(xtick)]);
% % %  set(gca,'XTickLabel','');
% % %   set(gca,'YTickLabel','')
plfit = 1;
p=0;
n = [5,25];
 axes(ha(1)); 
f1 = plotstatsimulRipley(obs3,avvar3,UCIvar3,LCIvar3,out3.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
if plfit
    x0 = [25,60];
    [yfit3,A(1),lambda(1),xdata3,ydata3] = PCFfitexpo(out3.D,obs3,n,p,x0);
    hold on
    plot(xdata3,yfit3,'-r','LineWidth',2)
end
  ylim([min(ytick),max(ytick)]);
  legend off
% 
% UCIvar2(1) = UCIvar2(2);
% LCIvar2(1) = LCIvar2(2);
% f1 = plotstatsimulRipley(obs2,avvar2,UCIvar2,LCIvar2,out2.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
% if plfit
%     x0 = [25,60];
%     [yfit2,A(1),lambda(1),xdata2,ydata2] = PCFfitexpo(out2.D,obs2,n,p,x0);
%     hold on
%     plot(xdata2,yfit2,'-r','LineWidth',2)
% end

% f1 = plotstatsimulRipley(obs1,avvar1,UCIvar1,LCIvar1,out1.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
% if plfit
%     x0 = [25,60];
%     [yfit1,A(1),lambda(1),xdata1,ydata1] = PCFfitexpo(out1.D,obs1,n,p,x0);
%     hold on
%     plot(xdata1,yfit1,'-r','LineWidth',2)
% end

legend off
 axes(ha(2));
f1 = plotstatsimulRipley(obs4,avvar4,UCIvar4,LCIvar4,out4.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
if plfit
    x0 = [25,60];
    [yfit4,A(2),lambda(2),xdata4,ydata4] = PCFfitexpo(out4.D,obs4,n,p,x0);
    hold on
    plot(xdata4,yfit4,'-r','LineWidth',2)
end
legend off
  ylim([min(ytick),max(ytick)]);

legend off
 axes(ha(3)); 
f1 = plotstatsimulRipley(obs5,avvar5,UCIvar5,LCIvar5,out5.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
if plfit
    x0 = [1,100];
    xdat = out5.D;
    
    [yfit5,A(3),lambda(3),xdata5,ydata5] = PCFfitexpo(out5.D,obs5,n,p,x0);
    hold on
    plot(xdata5,yfit5,'-r','LineWidth',2)
end
legend off
  ylim([min(ytick),max(ytick)]);

 axes(ha(4)); 
f1 = plotstatsimulRipley(obs6,avvar6,UCIvar6,LCIvar6,out6.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
if plfit
    x0 = [35,60];
    [yfit6,A(4),lambda(4),xdata6,ydata6] = PCFfitexpo(out6.D,obs6,n,p,x0);
    hold on
    plot(xdata6,yfit6,'-r','LineWidth',2)
end
legend off
  ylim([min(ytick),max(ytick)]);
 axes(ha(5)); 

f1 = plotstatsimulRipley(obs7,avvar7,UCIvar7,LCIvar7,out7.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
if plfit
    x0 = [25,40];
    [yfit7,A(5),lambda(5),xdata7,ydata7] = PCFfitexpo(out7.D,obs7,n,p,x0);
    hold on
    plot(xdata7,yfit7,'-r','LineWidth',2)
end
  ylim([min(ytick),max(ytick)]);

 axes(ha(6)); 
 f1 = plotstatsimulRipley(obs8,avvar8,UCIvar8,LCIvar8,out8.D,unitfactor,colfill,xtick,ytick,colline,choice,f1,'','')
if plfit
    x0 = [1,100];
    xdat = out8.D;
    
    [yfit8,A(6),lambda(6),xdata8,ydata8] = PCFfitexpo(out8.D,obs8,n,p,x0);
    hold on
    plot(xdata8,yfit8,'-r','LineWidth',2)
end
  ylim([min(ytick),max(ytick)]);
legend off

%   set(gca,'XTickLabel','');
% set(ha(1:5),'XTickLabel',xticklab)
% set(ha(1:5),'YTick',ytick) 
% set(ha(1:5),'YTickLabel',yticklab)
%           set(ha(1:5),'XTickLabel',''); set(ha,'YTickLabel','')
width = 12;     % Width in inche5
height = 2;    % Height in inches
pos = get(f1, 'Position');
set(f1, 'Position', [pos(1)-100 pos(2)-100 width*50, height*50]); %<- Set size
set(f1,'color','w')
set(f1,'InvertHardcopy','on');
set(f1,'PaperUnits', 'inches');
