function [K1,L1,K2,L2,K3,L3,K12,L12,K21,L21,K13,L13,K31,L31,K23,L23,K32,L32,...
    PCF1,PCF2,PCF3,PCF12,PCF21,PCF13,PCF31,PCF23,PCF32,lam1,lam2,lam3,vol] = ripleysK3col(C1,C2,C3,B,D,dim,varargin)
% ripleysKd3DsM is a subfunction of the Grafeo 1.beta version program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018
% ,p
unitfactor = 10^-3;
nD = numel(D);
borcor = 0;
ifplot = 0;
nD = numel(D);
borcor = 0;

if nargin >= 7 
     ifplot = varargin{1}; 
end
if nargin >= 8 & ~isempty(varargin{2})
    borcor = varargin{2}; 
end

if nargin >= 9 & ~isempty(varargin{3})
    unitfactor = varargin{3}; 
end

if isempty(C3)
    col = 2;
elseif isempty(C3) & isempty(C2)
    col = 1;
elseif ~isempty(C3) & ~isempty(C2) & ~isempty(C1)
    col = 3;
end

if col == 3
    if dim == 3
        zc3 = C3(:,3);zc2 = C2(:,3);
    end
    xc3 = C3(:,1); yc3 = C3(:,2); 
    inPoint3 = numel(xc3);
    if inPoint3 == 0
        fact3 = 0;
        lam3 = 0;
        fact13 = 0;
        fact23 = 0;
    end
else
    inPoint3 = 0;
     fact3 = 0;
    lam3 = 0;
    fact13 = 0;
    fact23 = 0;
end

if dim == 3
    zc1 = C1(:,3);zc2 = C2(:,3);
end

xc2 = C2(:,1); yc2 = C2(:,2); 
xc1 = C1(:,1); yc1 = C1(:,2); 
inPoint1 = numel(xc1);
inPoint2 = numel(xc2); 

if dim == 3
    if nargin >= 10 & ~isempty(varargin{4})
        arg3 = varargin{4}; 
        zmin = arg3.zmin;
        zmax = arg3.zmax;
        h = zmax - zmin;
    else
        if col == 3
            zmin = min(min(zc1),min(zc2),min(zc3));
            zmax = max(max(zc1),max(zc2),max(zc3));
            h = zmax - zmin;
        elseif col == 2
            zmin = min(min(zc1),min(zc2));
            zmax = max(max(zc1),max(zc2));
            h = zmax - zmin;
        end
    end
elseif dim == 2
    h = 1;
end

if dim == 3
    vol = h*abs(polyarea(B(:,1),B(:,2)));
elseif dim ==2
    vol = abs(polyarea(B(:,1),B(:,2)));
end

fact12 = vol/(inPoint2*inPoint1);
fact1 = vol/(inPoint1*inPoint1);
fact2 = vol/(inPoint2*inPoint2);
if inPoint2 == 0
    fact12 = 0;
    fact2 = 0;
    lam2 = 0;
else
    lam2 = inPoint2/vol;
end

if inPoint1 ==0
    fact12 = 0;
    lam1 = 0;
else
    lam1 = inPoint1/vol;
end

if col == 3
    if inPoint3 == 0
    
    lam3 = 0;
    fact13 = 0;
    fact23 = 0;
    fact3 = 0;
    else
        lam3 = inPoint3/vol;
        fact13 = vol/(inPoint3*inPoint1);
        fact23 = vol/(inPoint3*inPoint2);
        fact3 = vol/(inPoint3*inPoint3);
    end
end

if dim == 3
    Dist12 = pdist2([xc1,yc1,zc1],[xc2,yc2,zc2]);
    Dist21 = pdist2([xc2,yc2,zc2],[xc1,yc1,zc1]);
    Dist2 = pdist2([xc2,yc2,zc2],[xc2,yc2,zc2]);
    Dist1 = pdist2([xc1,yc1,zc1],[xc1,yc1,zc1]);
elseif dim == 2
    Dist12 = pdist2([xc1,yc1],[xc2,yc2]);
    Dist21 = pdist2([xc2,yc2],[xc1,yc1]);
    Dist2 = pdist2([xc2,yc2],[xc2,yc2]);
    Dist1 = pdist2([xc1,yc1],[xc1,yc1]);
end
if col == 3
    if dim == 3
        Dist13 = pdist2([xc1,yc1,zc1],[xc3,yc3,zc3]);
        Dist31 = pdist2([xc3,yc3,zc3],[xc1,yc1,zc1]);
        Dist23 = pdist2([xc2,yc2,zc2],[xc3,yc3,zc3]);
        Dist32 = pdist2([xc3,yc3,zc3],[xc2,yc2,zc2]);
        Dist3 = pdist2([xc3,yc3,zc3],[xc3,yc3,zc3]);
    elseif dim == 2
        Dist13 = pdist2([xc1,yc1],[xc3,yc3]);
        Dist31 = pdist2([xc3,yc3],[xc1,yc1]);
        Dist23 = pdist2([xc2,yc2],[xc3,yc3]);
        Dist32 = pdist2([xc3,yc3],[xc2,yc2]);
        Dist3 = pdist2([xc3,yc3],[xc3,yc3]);
    end 
boundaryCorr32 = zeros(size(Dist32));
boundaryCorr23 = zeros(size(Dist23));
boundaryCorr3 = zeros(size(Dist3));
boundaryCorr31 = zeros(size(Dist31));
boundaryCorr13 = zeros(size(Dist13));
K23 = zeros(nD,1);
K13 = zeros(nD,1);
K31 = zeros(nD,1);
K3 = zeros(nD,1);   
K32 = zeros(nD,1);
if ~borcor
    Dist13 = Dist13(:);
    Dist13 = Dist13((Dist13 <= D(end))&(Dist13 > 0));
    
    Dist23 = Dist23(:);
    Dist23 = Dist23((Dist23 <= D(end))&(Dist23 > 0));
    
    Dist3 = Dist3(:);
    Dist3 = Dist3((Dist3 <= D(end))&(Dist3 > 0));

    Dist32 = Dist32(:);
    Dist32 = Dist32((Dist32 <= D(end))&(Dist32 > 0));
    
    Dist31 = Dist31(:);
    Dist31 = Dist31((Dist31 <= D(end))&(Dist31 > 0));
    
end
end

boundaryCorr12 = zeros(size(Dist12));
boundaryCorr21 = zeros(size(Dist21));
boundaryCorr1 = zeros(size(Dist1));
boundaryCorr2 = zeros(size(Dist2));
range = D(end);%nD;
K21 = zeros(nD,1);
K1 = zeros(nD,1);
K2 = zeros(nD,1);   
K12 = zeros(nD,1);

if ~borcor
    Dist12 = Dist12(:);
    Dist12 = Dist12((Dist12 <= D(end))&(Dist12 > 0));
    
    Dist21 = Dist21(:);
    Dist21 = Dist21((Dist21 <= D(end))&(Dist21 > 0));
    
    Dist1 = Dist1(:);
    Dist1 = Dist1((Dist1 <= D(end))&(Dist1 > 0));
    
   Dist2 = Dist2(:);
    Dist2 = Dist2((Dist2 <= D(end))&(Dist2 > 0));
    
    for j = 1:nD
        kk = numel(D) -j +1;%;%kk = D(end-j+1);
        K12(kk) = fact12*numel(Dist12);
        K21(kk) = fact12*numel(Dist21);
        K1(kk) = fact1*numel(Dist1);
        K2(kk) = fact2*numel(Dist2);
        if col == 3
            K32(kk) = fact23*numel(Dist32);
            K23(kk) = fact23*numel(Dist23);
            K3(kk) = fact3*numel(Dist3);
            K13(kk) = fact13*numel(Dist13);
            K31(kk) = fact13*numel(Dist31);
        end
        if kk > 1
            Dist12(Dist12 > D(end-j)) = [];
            Dist21(Dist21 > D(end-j)) = [];
            Dist1(Dist1 > D(end-j)) = [];
            Dist2(Dist2 > D(end-j)) = [];
        end
        
        if kk > 1 & col == 3
            Dist32(Dist32 > D(end-j)) = [];
            Dist23(Dist23 > D(end-j)) = [];
            Dist3(Dist3 > D(end-j)) = [];
            Dist13(Dist13 > D(end-j)) = [];
            Dist31(Dist31 > D(end-j)) = [];
        end
    end
elseif borcor && dim == 2
    for i = 1:inPoint1
        
        for j = 1:inPoint1
            if Dist1(i,j) <= range  & Dist1(i,j) > 0
                boundaryCorr1(i,j) = bocor2D(Dist1(i,j),range,B,xc1(i),yc1(i));
            end
        end 
        
        clear j
        for j = 1:inPoint2
            if Dist12(i,j) <= range  & Dist12(i,j) > 0
                boundaryCorr12(i,j) = bocor2D(Dist12(i,j),range,B,xc1(i),yc1(i));
            end
            if Dist21(j,i) <= range  & Dist21(j,i) > 0
                boundaryCorr21(j,i) = bocor2D(Dist21(j,i),range,B,xc2(j),yc2(j));
            end
            
            for k = 1:inPoint2
                if Dist2(j,k) <= range  & Dist2(j,k) > 0
                    boundaryCorr2(j,k) = bocor2D(Dist2(j,k),range,B,xc2(j),yc2(j));
                end
            end
            if col == 3
                for k = 1:inPoint3
                    if Dist23(j,k) <= range  & Dist23(j,k) > 0
                        boundaryCorr23(j,k) = bocor2D(Dist23(j,k),range,B,xc2(j),yc2(j));
                    end
                    if Dist32(k,j) <= range  & Dist32(k,j) > 0
                        boundaryCorr32(k,j) = bocor2D(Dist32(k,j),range,B,xc3(k),yc3(k));
                    end
                end
            end
        end
        clear j
        if col == 3
        for j = 1:inPoint3
            if Dist13(i,j) <= range  & Dist13(i,j) > 0
                boundaryCorr13(i,j) = bocor2D(Dist13(i,j),range,B,xc1(i),yc1(i));
            end
            if Dist31(j,i) <= range  & Dist31(j,i) > 0
                boundaryCorr31(j,i) = bocor2D(Dist31(j,i),range,B,xc3(j),yc3(j));
            end
        for k = 1:inPoint3
            if Dist3(j,k) <= range  & Dist3(j,k) > 0
            boundaryCorr3(j,k) = bocor2D(Dist3(j,k),range,B,xc3(j),yc3(j));
            end
        end
        end
        end
        
     end  
elseif borcor && dim == 3
     if  nargin >= 10 & ~isempty(varargin{4})
        arg = varargin{4}; 
        points = arg.points;
     else
        k2 = convhull(B(:,1),B(:,2),'Simplify',true);%,'Simplify',true
        boundary =  [B(k2,1),B(k2,2),zmin*ones(numel(B(k2,1)),1);...
        B(k2,1),B(k2,2),zmax*ones(numel(B(k2,1)),1)];
        % [k2,av2] = convhull(boundary(:,1),boundary(:,2),boundary(:,3));%,'Simplify',true % boundary = boundary(k2);
        DT = delaunayTriangulation(boundary);
        [C,v] = convexHull(DT);
        TR = triangulation(C,DT.Points);
        points = TR.Points;
     end
    xmin = min(points(:,1));
    xmax = max(points(:,1));
    ymin = min(points(:,2));
    ymax = max(points(:,2));
% fv.vertices = TR.Points; 
% fv.faces = TR.ConnectivityList;
% fv.faces = fliplr(fv.faces); 
% F = faceNormal(TR); 
% P = incenter(TR);
% figure;trisurf(TR,'FaceColor','cyan');
% hold on  
% quiver3(P(:,1),P(:,2),P(:,3), F(:,1),F(:,2),F(:,3),0.5,'color','r');
% plot3(xc1,yc1,zc1,'.m','MarkerSize',20)
    for i = 1:inPoint1
        for j = 1:inPoint1
            if Dist1(i,j) > 0 & Dist1(i,j) <= range
             boundaryCorr1(i,j) = bocor3D(Dist1(i,j),xc1(i),yc1(i),zc1(i),zmin,zmax,xmin,xmax,ymin,ymax);
            end
        end
        clear j
        for j = 1:inPoint2
            if Dist12(i,j) > 0 & Dist12(i,j) <= range
            boundaryCorr12(i,j) = bocor3D(Dist12(i,j),xc1(i),yc1(i),zc1(i),zmin,zmax,xmin,xmax,ymin,ymax);
            end
            if Dist21(j,i) > 0 & Dist21(j,i) <= range
            boundaryCorr21(j,i) = bocor3D(Dist21(j,i),xc2(j),yc2(j),zc2(j),zmin,zmax,xmin,xmax,ymin,ymax);
            end
            for k = 1:inPoint2
            if Dist2(j,k) > 0 & Dist2(j,k) <= range
            boundaryCorr2(j,k) = bocor3D(Dist2(j,k),xc2(j),yc2(j),zc2(j),zmin,zmax,xmin,xmax,ymin,ymax);
            end
            end
            if col == 3
            for k = 1:inPoint3
                if Dist23(j,k) > 0 & Dist23(j,k) <= range
                boundaryCorr23(j,k) = bocor3D(Dist23(j,k),xc2(j),yc2(j),zc2(j),zmin,zmax,xmin,xmax,ymin,ymax);
                end
                if Dist32(k,j) > 0 & Dist32(k,j) <= range
                boundaryCorr32(k,j) = bocor3D(Dist32(k,j),xc3(k),yc3(k),zc3(k),zmin,zmax,xmin,xmax,ymin,ymax);
                end
            end
            end
        end
        clear j
        if col == 3
            for j = 1:inPoint3
                if Dist13(i,j) > 0 & Dist13(i,j) <= range
                boundaryCorr13(i,j) = bocor3D(Dist13(i,j),xc1(i),yc1(i),zc1(i),zmin,zmax,xmin,xmax,ymin,ymax);
                end
                if Dist31(j,i) > 0 & Dist31(j,i) <= range
                boundaryCorr31(j,i) = bocor3D(Dist31(j,i),xc3(j),yc3(j),zc3(j),zmin,zmax,xmin,xmax,ymin,ymax);
                end
                for k = 1:inPoint3
                    if Dist3(j,k) > 0 & Dist3(j,k) <= range
                    boundaryCorr3(j,k) = bocor3D(Dist3(j,k),xc3(j),yc3(j),zc3(j),zmin,zmax,xmin,xmax,ymin,ymax);
                    end
                end
            end
        end
    end  
end
if borcor
    weight12 = 1./boundaryCorr12(:);
    isfin = find(~isfinite(weight12));
    weight12(isfin)=0;
    Dist12 = Dist12(:);
    weight21 = 1./boundaryCorr21(:);
    isfin = find(~isfinite(weight21));
    weight21(isfin)=0;
    Dist21 = Dist21(:);
    weight1 = 1./boundaryCorr1(:);
    isfin = find(~isfinite(weight1));
    weight1(isfin)=0;
    Dist1 = Dist1(:);
    weight2 = 1./boundaryCorr2(:);
    isfin = find(~isfinite(weight2));
    weight2(isfin)=0;
    Dist2 = Dist2(:);
    if col == 3
        weight13 = 1./boundaryCorr13(:);
        isfin = find(~isfinite(weight13));
        weight13(isfin)=0;
        Dist13 = Dist13(:);
        weight31 = 1./boundaryCorr31(:);
        isfin = find(~isfinite(weight31));
        weight31(isfin)=0;
        Dist31 = Dist31(:);
        weight3 = 1./boundaryCorr3(:);
        isfin = find(~isfinite(weight3));
        weight3(isfin)=0;
        Dist3 = Dist3(:);
        weight32 = 1./boundaryCorr32(:);
        isfin = find(~isfinite(weight32));
        weight32(isfin)=0;
        Dist32 = Dist32(:);
        weight23 = 1./boundaryCorr23(:);
        isfin = find(~isfinite(weight23));
        weight23(isfin)=0;
        Dist23 = Dist23(:);
    end
    for i = 1:nD
        ind2 = find(Dist12 <= D(i) & Dist12 > 0);
        K12(i) = fact12*sum(weight12(ind2)); clear ind2
        ind2 = find(Dist21 <= D(i) & Dist21 > 0);
        K21(i) = fact12*sum(weight21(ind2)); clear ind2
        ind2 = find(Dist1 <= D(i) & Dist1 > 0);
        K1(i) = fact1*sum(weight1(ind2)); clear ind2
        ind2 = find(Dist2 <= D(i) & Dist2 > 0);
        K2(i) = fact2*sum(weight2(ind2)); clear ind2
        if col == 3
            ind2 = find(Dist13 <= D(i) & Dist13 > 0);
            K13(i) = fact13*sum(weight13(ind2)); clear ind2
            ind2 = find(Dist31 <= D(i) & Dist31 > 0);
            K31(i) = fact13*sum(weight31(ind2)); clear ind2
            ind2 = find(Dist3 <= D(i) & Dist3 > 0);
            K3(i) = fact3*sum(weight3(ind2)); clear ind2
            ind2 = find(Dist23 <= D(i) & Dist23 > 0);
            K23(i) = fact23*sum(weight23(ind2)); clear ind2
            ind2 = find(Dist32 <= D(i) & Dist32 > 0);
            K32(i) = fact23*sum(weight32(ind2)); clear ind2
        end
    end
end
r = D(:);
dr = diff(r);
r1 = r(2:end);
if dim == 3
    K12 = K12*unitfactor^3; 
    L12 = nthroot(3*K12/pi/4,3) -D(:)*unitfactor;
%      BinVolume = diff(4/3*pi*D.^3); PCF12 = diff(K12)./BinVolume';
    PCF12 = diff(K12)./(4*pi*r1.*r1.*dr);
    K21 = K21*unitfactor^3; 
    L21 = nthroot(3*K21/pi/4,3) -D(:)*unitfactor;
    PCF21 = diff(K21)./(4*pi*r1.*r1.*dr);
    
    K1 = K1*unitfactor^3; 
    L1 = nthroot(3*K1/pi/4,3) -D(:)*unitfactor;
%      BinVolume = diff(4/3*pi*D.^3); PCF12 = diff(K12)./BinVolume';
    PCF1 = diff(K1)./(4*pi*r1.*r1.*dr);
    K2 = K2*unitfactor^3; 
    L2 = nthroot(3*K2/pi/4,3) -D(:)*unitfactor;
    PCF2 = diff(K2)./(4*pi*r1.*r1.*dr);
    if col == 3
    K13 = K13*unitfactor^3; 
    L13 = nthroot(3*K13/pi/4,3) -D(:)*unitfactor;
%      BinVolume = diff(4/3*pi*D.^3); PCF12 = diff(K12)./BinVolume';
    PCF13 = diff(K13)./(4*pi*r1.*r1.*dr);
    K31 = K31*unitfactor^3; 
    L31 = nthroot(3*K31/pi/4,3) -D(:)*unitfactor;
    PCF31 = diff(K31)./(4*pi*r1.*r1.*dr);
    
    K23 = K23*unitfactor^3; 
    L23 = nthroot(3*K23/pi/4,3) -D(:)*unitfactor;
%      BinVolume = diff(4/3*pi*D.^3); PCF12 = diff(K12)./BinVolume';
    PCF23 = diff(K23)./(4*pi*r1.*r1.*dr);
    K32 = K32*unitfactor^3; 
    L32 = nthroot(3*K32/pi/4,3) -D(:)*unitfactor;
    PCF32 = diff(K32)./(4*pi*r1.*r1.*dr);
    
    K3 = K3*unitfactor^3; 
    L3 = nthroot(3*K3/pi/4,3) -D(:)*unitfactor;
    PCF3 = diff(K3)./(4*pi*r1.*r1.*dr);
    end
elseif dim == 2
    K12 = K12*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
    L12 = sqrt(K12/pi) - D(:)*unitfactor;
%     BinVolume = diff(pi*D.^2);PCF12 = diff(K12)./BinVolume';
    PCF12 = diff(K12)./(2*pi*r1.*dr);
    K21 = K21*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
    L21 = sqrt(K21/pi) - D(:)*unitfactor;
    PCF21 = diff(K21)./(2*pi*r1.*dr);
    
    K1 = K1*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
    L1 = sqrt(K1/pi) - D(:)*unitfactor;
%     BinVolume = diff(pi*D.^2);PCF12 = diff(K12)./BinVolume';
    PCF1 = diff(K1)./(2*pi*r1.*dr);
    K2 = K2*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
    L2 = sqrt(K2/pi) - D(:)*unitfactor;
    PCF2 = diff(K2)./(2*pi*r1.*dr);
    if col == 3
         K13 = K13*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
        L13 = sqrt(K13/pi) - D(:)*unitfactor;
    %     BinVolume = diff(pi*D.^2);PCF12 = diff(K12)./BinVolume';
        PCF13 = diff(K13)./(2*pi*r1.*dr);
        K23 = K23*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
        L23 = sqrt(K23/pi) - D(:)*unitfactor;
        PCF23 = diff(K23)./(2*pi*r1.*dr);

         K31 = K31*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
        L31 = sqrt(K31/pi) - D(:)*unitfactor;
    %     BinVolume = diff(pi*D.^2);PCF12 = diff(K12)./BinVolume';
        PCF31 = diff(K31)./(2*pi*r1.*dr);
        K32 = K32*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
        L32 = sqrt(K32/pi) - D(:)*unitfactor;
        PCF32 = diff(K32)./(2*pi*r1.*dr);
        
        K3 = K3*unitfactor^2; % pixel size 10 nm, A i s in nm^2, transformed to um^2
        L3 = sqrt(K3/pi) - D(:)*unitfactor;
        PCF3 = diff(K3)./(2*pi*r1.*dr);
    end
end

 if col < 3
    K1 =[]; 
    L1 = [];
    PCF1 = [];

    K2 =[]; 
    L2 = [];
    PCF2 = [];

    K3 =[]; 
    L3 = [];
    PCF3 = [];

    K13 =[]; 
    L13 = [];
    PCF13 = [];

    K23 =[]; 
    L23 = [];
    PCF23 = [];

    K31 =[]; 
    L31 = [];
    PCF31 = [];

    K32 =[]; 
    L32 = [];
    PCF32 = [];
 end

if ifplot
    green = [32,183,105]/255;
violet = [160,121,167]/255;
% if dim == 3
%     sphered = (4*pi*(D*unitfactor).^3)/3; % spehere
% elseif dim == 2
%     sphered = pi*(D*unitfactor).^2; % circle
% end
figure
plot(D*unitfactor,K12,'K12')
xlabel('Distances - d'),ylabel('K12')
figure,plot(D*unitfactor,L12,'r.')
xlabel('Distances - d'),ylabel('L12')

figure;
if ~iscell(mask)
    plot(B{1}(:,2),B{1}(:,1),'-K12')
else
    plot(B(:,1),B(:,2),'-K12')
end
hold on; plot(C1(:,1),C1(:,2),'.','Color',violet);
plot(C2(:,1),C2(:,2),'.','Color',green);
hold off;
end

end

function [x,y] = circleplot(xc1,yc1,r)
t=0:0.25:2*pi;
x=xc1+r*cos(t);
y=yc1+r*sin(t);
end
