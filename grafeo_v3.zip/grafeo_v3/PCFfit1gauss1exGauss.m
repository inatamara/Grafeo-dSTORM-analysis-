function [rho,A,d,yfit,xdata,ydata] = PCFfit1gauss1exGauss(D,obs2,N,p,x0, sig, varargin)
% PCFfit1gauss1exGauss is a subfunction of the Grafeo Matlab script package.
% This function allows fitting a sum of Gaussian and exGaussian to Point correlation function.
% The first version of this function was developped for the following
% publication:  
% Peaucelle et al., iScience 2020 Multicolor 3D-dSTORM Reveals Native-State Ultrastructure of Polysaccharides' 
%Network during Plant Cell Wall Assembly
% Copyright (C) Kalina Tamara Haas, 2020, Versailles, France
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 07/01/2021
if nargin == 6
    lb = [0,0,0];
    ub = [inf,inf,inf];
elseif nargin == 8
    lb = varargin{1};   
    ub = varargin{2}; 
elseif nargin == 7
    lb = varargin{1};   
end

xdata = D;
if numel(N) == 1
xdata = xdata(1:N);
xdata = xdata(:);
ydata = obs2(1:N);
elseif numel(N) == 2
 xdata = xdata(N(1):N(2));
xdata = xdata(:);
ydata = obs2(N(1):N(2));   
end
ydata = ydata(:);
ncdf = @(xdata) 0.5*(1+erf(xdata/sqrt(2)));

% options = optimoptions('lsqcurvefit','Algorithm','levenberg-marquardt');
options = optimoptions('lsqcurvefit','TolFun',1e-10);
mu = 0;
sig = sqrt(2)*sig; % twice sig, because autocorelation function of PCF has double sigma.
fun =  @(x,xdata)(1+exp(-(xdata).^2/(2*(sig)^2))/(2*pi*sig^2)/x(1) + x(2)*exp((mu/x(3))+(sig^2/(2*x(3)^2))-...
            (xdata/x(3))).*ncdf( (xdata-mu-(sig^2/x(3)))./sig));
bestx = lsqcurvefit(fun,x0,xdata,ydata,lb,ub,options);

rho = bestx(1);
A = bestx(2);
d = bestx(3);
yfit1 = 1+exp(-(xdata).^2/(2*sig^2))/(2*pi*sig^2)/rho;
yfit2 = A*exp((xc2/d)+(sig^2/(2*d^2))-...
    (xdata/d)).*ncdf( (xdata-xc2-(sig^2/d))./sig);%(1/d).*
yfit = yfit1 + yfit2;
%
if p
figure

plot(xdata,ydata,'*b');
hold on
plot(xdata,yfit,'-r');

xlabel('xdata')
ylabel('Response Data and Curve')
title('Data and Best Fitting Exponential Curve')
legend('Data','Fitted Curve')
hold off
end
