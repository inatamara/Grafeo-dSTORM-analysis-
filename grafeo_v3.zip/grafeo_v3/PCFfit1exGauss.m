function [rho,A,d,yfit,xdata,ydata] = PCFfit1exGauss(D,obs2,N,p,x0,sig1,sig2, varargin)
%  PCFfit1exGauss is a subfunction of the Grafeo Matlab script package.
% This function allows fitting an exGaussian to Point correlation function.
% The first version of this function was developped for the following
% publication:  
% Peaucelle et al., iScience 2020 Multicolor 3D-dSTORM Reveals Native-State Ultrastructure of Polysaccharides' 
%Network during Plant Cell Wall Assembly
% Copyright (C) Kalina Tamara Haas, 2020, Versailles, France
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 07/01/2021
if nargin == 7
    lb = [0,5];
ub = [inf,inf];
elseif nargin == 9
 lb = varargin{1};   
 ub = varargin{2}; 
 elseif nargin == 8
 lb = varargin{1};   
 ub = [inf,inf];
end

xdata = D;
if numel(N) == 1
xdata = xdata(1:N);
xdata = xdata(:);
ydata = obs2(1:N);
elseif numel(N) == 2
 xdata = xdata(N(1):N(2));
xdata = xdata(:);
ydata = obs2(N(1):N(2));   
end
ydata = ydata(:);
ncdf = @(xdata) 0.5*(1+erf(xdata/sqrt(2)));

% options = optimoptions('lsqcurvefit','Algorithm','levenberg-marquardt');
options = optimoptions('lsqcurvefit','TolFun',1e-10);
sig = sqrt(sig1^2 + sig2^2); % PCF call pdm

mu = 0;
fun =  @(x,xdata)(1+ x(1).*exp((mu/x(2))+(sig^2/(2*x(2)^2))-...
            (xdata/x(2))).*ncdf( (xdata-mu-(sig^2/x(2)))./sig));

bestx = lsqcurvefit(fun,x0,xdata,ydata,lb,ub,options);

rho = 1;
A = bestx(1);
d = bestx(2);
yfit1 = rho;

yfit2 = A.*exp((xc2/d)+(sig^2/(2*d^2))-...
    (xdata/d)).*ncdf( (xdata-xc2-(sig^2/d))./sig);
yfit = yfit1 + yfit2;
%
if p
figure

plot(xdata,ydata,'*b');
hold on
plot(xdata,yfit,'-r');
% plot(xdata,yfit2,'--m');
xlabel('xdata')
ylabel('Response Data and Curve')
title('Data and Best Fitting Exponential Curve')
legend('Data','Fitted Curve')
hold off
end
