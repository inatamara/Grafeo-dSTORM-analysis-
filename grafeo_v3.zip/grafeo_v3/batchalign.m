function batchalign(Csusu,subsubdir,searchstring,saveflag,dim,varargin)
% batchalign is a subfunction of the Grafeo MAtlab script package.
% This function permits automatic alignement of two and three color, 2D
% and 3D dSTORM pointillist data set.
% The first version of this function was developped for the following
% publication:  Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018, https://doi.org/10.1093/nar/gkx1303
% The current version was updated for the following publication:
% Peaucelle et al., iScience 2020 Multicolor 3D-dSTORM Reveals Native-State Ultrastructure of Polysaccharides' 
%Network during Plant Cell Wall Assembly
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 07/01/2021
if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

    tfm = ~cellfun('isempty',strfind(Csusu,searchstring));
    Csusu1 = Csusu(tfm); 
    nfile = numel(Csusu1);
for ni = 1:nfile
if dim == 3
ind = [1,2,5];
elseif dim == 2
ind = [1,2];
end
filetoload = strcat(subsubdir,flagslash,Csusu1{ni});
filetosave = strrep(filetoload,searchstring,saveflag);

load(filetoload,'dataout1','dataout2',...
'densitythr1','densitythr2','Vp1','Vp2',...
'namech1','namech2','Dp1','Dp2','photonTH1','photonTH2','locprec1','locprec2')
ch = 2;
if nargin >= 6
    zreject = varargin{1};
    if zreject(1) > 0
       dataout1 = dataout1(dataout1(:,8) > 0,:); 
    end
    if zreject(2) > 0
       dataout2 = dataout2(dataout2(:,8) > 0,:); 
    end
end

if nargin >= 7
   if varargin{2} ==  3
       load(filetoload,'dataout3','densitythr3','Vp3','namech3','Dp3','photonTH3','locprec3')
    if zreject(3) > 0 & numel(zreject) == 3
       dataout3 = dataout3(dataout3(:,8) > 0,:); 
    end
    ch = 3;
    roidata = [];
    if nargin >= 8
   roidata = varargin{3};
   if ~isempty(roidata)
   dat3 = dataout3(dataout3(:,1) <= roidata.xmax & dataout3(:,1) >= roidata.xmin &...
    dataout3(:,2) <= roidata.ymax & dataout3(:,2) >= roidata.ymin,:);
   end
   end       
end
% try
if nargin >= 8
   roidata = varargin{3};
   if ~isempty(roidata)
   dat1 = dataout1(dataout1(:,1) <= roidata.xmax & dataout1(:,1) >= roidata.xmin &...
dataout1(:,2) <= roidata.ymax & dataout1(:,2) >= roidata.ymin,:);

dat2 = dataout2(dataout2(:,1) <= roidata.xmax & dataout2(:,1) >= roidata.xmin &...
dataout2(:,2) <= roidata.ymax & dataout2(:,2) >= roidata.ymin,:);
   end
end

if ~isempty(roidata)
        [~,leftrightcount,updowncount,zcount,~,exitflag,output] = ...
        simulanielminim(dat1(:,ind),dat2(:,ind),dim); % aligment
else
    [~,leftrightcount,updowncount,zcount,~,exitflag,output] = ...
        simulanielminim(dataout1(:,ind),dataout2(:,ind),dim); % aligment
end
    dataoutshift1 = dataout1;
    if ~isempty(leftrightcount)
        dataoutshift1(:,1)  = dataout1(:,1) - leftrightcount;
    end
    if ~isempty(updowncount)
        dataoutshift1(:,2)  = dataout1(:,2) - updowncount;
    end
if dim == 3
    if ~isempty(zcount)
        dataoutshift1(:,5)  = dataout1(:,5) - zcount;
    end
end
% catch
%     dataoutshift1 = [];
%     leftrightcount = [];
%     updowncount = [];
%     exitflag = [];
%     output = [];
%     zcount = [];
% end
if ch == 3
    if ~isempty(roidata)
       [~,leftrightcount3,updowncount3,zcount3,~,exitflag3,output3] = ...
        simulanielminim(dat3(:,ind),dat2(:,ind),dim); % aligment
else
       [~,leftrightcount3,updowncount3,zcount3,~,exitflag3,output3] = ...
        simulanielminim(dataout3(:,ind),dataout2(:,ind),dim); % aligment
    end
    dataoutshift3 = dataout3;
    if ~isempty(leftrightcount3)
        dataoutshift3(:,1)  = dataout3(:,1) - leftrightcount3;
    end
    if ~isempty(updowncount)
        dataoutshift3(:,2)  = dataout3(:,2) - updowncount3;
    end
if dim == 3
    if ~isempty(zcount3)
        dataoutshift3(:,5)  = dataout3(:,5) - zcount;
    end
end 
save(filetosave,'dataout1','dataout2',...
'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
'leftrightcount','updowncount','exitflag', 'output','zcount',...
'dim','namech1','namech2','Dp1','Dp2','photonTH1','photonTH2',...
'locprec1','locprec2','exitflag','dataout3','densitythr3','Vp3','dataoutshift3',...
'leftrightcount3','updowncount3','exitflag3', 'output3','zcount3',...
'dim','namech3','Dp3','photonTH3','locprec3','output')
else
save(filetosave,'dataout1','dataout2',...
'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
'leftrightcount','updowncount','exitflag', 'output','zcount',...
'dim','namech1','namech2','Dp1','Dp2','photonTH1','photonTH2',...
'locprec1','locprec2','exitflag','output')
end

end
end

