function boundaryCorr = bocor2D(dist,B,x,y)

 [xcirc, ycirc] = circleplot(x,y,dist);
try
     ind= find(InPolygon(xcirc, ycirc, B(:,1),B(:,2)));
catch
     ind= find(inpolygon(xcirc, ycirc, B(:,1),B(:,2)));
end
if ~isempty(ind)
boundaryCorr = numel(ind)/numel(xcirc);ind= [];
end

function [x,y] = circleplot(xc1,yc1,r)
t=0:0.25:2*pi;
x=xc1+r*cos(t);
y=yc1+r*sin(t);



