function boundaryCorr = bocor3D_cylinder(p1,p2,R,N,zmin,zmax,xmin,xmax,ymin,ymax,pl)

%     pts = spherecustom(16,dist,x,y,z);
% [x1,y1,z1] = rand_pick_sphere(1000,0,dist,x,y,z,1);
pts = rndpointsincylinder(p1,p2,R,N,pl);
% pts = [x1,y1,z1];
    npts = numel(pts(:,1));
    pts = pts(pts(:,3) >= zmin & pts(:,3) <= zmax & pts(:,2) >= ymin & pts(:,2) <= ymax & pts(:,1) >= xmin & pts(:,1) <= xmax,:);
%               ind = inpolyhedron(fv, pts);     % Test which are inside the patch
   boundaryCorr = size(pts,1)/npts;





