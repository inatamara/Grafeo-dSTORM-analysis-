function [Ksim12,Ksim21,K12,K21,Lsim12,Lsim21,L12,L21,Ksim1,Ksim2,Lsim1,Lsim2,K1,K2,L1,...
L2,KdMs12,LdMs12,KdM12,LdM12,C1r,C2r,inPoint1,inPoint2,...
PCF1,PCF2,PCF12,PCF21,PCFsim1,PCFsim2,PCFsim12,PCFsim21,...
Ksim13,Ksim31,K13,K31,Lsim13,Lsim31,L13,L31,Ksim3,Lsim3,K3,L3,...
KdMs13,LdMs13,KdM13,LdM13,inPoint3,PCF3,PCF13,PCF31,PCFsim3,PCFsim13,PCFsim31,...
Ksim23,Ksim32,K23,K32,Lsim23,Lsim32,L23,L32,...
 KdMs23,LdMs23,KdM23,LdM23,PCF23,PCF32,PCFsim23,PCFsim32,C3r,lam1,lam2,lam3,vol,boundary,...
 borcor1,borcor2,borcor3,borcorSIM1,borcorSIM2,borcorSIM3] = ...
randomizationRiplays3col3DNEW(C1,C2,C3,Nsimul,D,B,ifplot,dim,boundarycorrection,varargin)
 % randomizationRiplays2col3D is a subfunction of the Grafeo 2.2.0 program.
% Grafeo was first developped for the following publication (version 1):
% Haas et al., "Single-molecule localization microscopy reveals molecular transactions 
% during RAD51 filament assembly at cellular DNA damage sites", NAR 2018, https://doi.org/10.1093/nar/gkx1303
% Grafeo version 2.1.0 was developped for the following publication:
% Pectin homogalacturonan nanofilament expansion drives morphogenesis in
% plant epidermal cells, Haas et al., Science 2020. DOI: 10.1126/science.aaz5103
% The current version 2.2.0 includes three color data visualization and processing,
% Rapid calculation of 3D boundary corrected Ripley's and PCF function for small ROIs, and others.
% % The 2.2.0 updates were developped for the following article, curently under review in iScience:
% Peaucelle et. al., Multicolor 3D-dSTORM reveals native-state ultrastructure of
% polysaccharides� network during plant cell wall assembly.
% Copyright (C) Kalina Tamara Haas, 2020, Paris, France
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% The updated versions of this repository will be uploaded on the github:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% or
% personal page: https://sites.google.com/site/kalinathaas/
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: kalina.haas@inrae.fr, inakuflers@gmail.com
% twitter: @KalinaHaas
% Last modified: 04/08/2020
% initializing parameters if not supplied by the user
%%
inPoint1  = [];inPoint2 = [];inPoint3 = [];
borcor1  = [];borcor2 = [];borcor3 = [];
n1 = 0; n2 = 0;n3 = 0;
C1r = [];
C2r = [];
Ksim1 = [];
Ksim12 = [];
Lsim1 = [];
Lsim12 = [];
Ksim21 = [];
Lsim21 = [];
KdMs12 = [];
LdMs12 = [];
Ksim2 = [];
Lsim2 = [];
K2 = [];
L2 = [];
K1 = [];
L1 = [];
K12 = [];
L12 = [];
K21 = [];
L21 = [];
KdM12 = [];
LdM12 = [];
lam1 = [];
lam2 = [];
lam3 = [];
vol = [];
PCFsim1 = [];
PCFsim12 = [];
PCFsim21 = [];
PCFsim2 = [];
PCF2 = [];
PCF1 = [];
PCF12 = [];
PCF21 = [];
borcorSIM1 = [];
borcorSIM2 = [];
borcorSIM3 = [];
C3r = [];
K3 = [];
L3 = [];
PCF3 = [];
Lsim3 = [];
Ksim3 = [];
Ksim13 = [];
Lsim13 = [];
Ksim31 = [];
Lsim31 = [];
KdMs13 = [];
LdMs13 = [];
K13 = [];
L13 = [];
K31 = [];
L31 = [];
KdM13 = [];
LdM13 = [];
PCFsim13 = [];
PCFsim31 = [];
PCF13 = [];
PCF31 = [];
Ksim23 = [];
Lsim23 = [];
Ksim32 = [];
Lsim32 = [];
KdMs23 = [];
LdMs23 = [];
K23 = [];
L23 = [];
K32 = [];
L32 = [];
KdM23 = [];
LdM23 = [];
PCFsim3 = [];
PCFsim23 = [];
PCFsim32 = [];
PCF23 = [];
PCF32 = [];
%%
p = 0;
tic
minregmask = 1000;
zb = -400;
ze = 400;
mult = 5;
unitfactor = 10^-3;

if nargin >=10
    if ~isempty(varargin{1}) | varargin{1} > 0
        minregmask = varargin{1};
    end
end
if isempty(C2) &  isempty(C3)
    col = 1; % one color data only
elseif isempty(C3)
    col = 2;
else
     col = 3;
end
% only for 3D ripley, zb:ze - z range
if nargin >= 11
    if ~isempty(varargin{2})
        zb = varargin{2}(1);
        ze = varargin{2}(2);
    else
        if col == 3
        zb = min([min(C1(:,3)),min(C2(:,3)),min(C3(:,3))]);
        ze = max([max(C1(:,3)),max(C2(:,3)),max(C3(:,3))]);
        elseif col == 2
        zb = min([min(C1(:,3)),min(C2(:,3))]);
        ze = max([max(C1(:,3)),max(C2(:,3))]);
        elseif col == 1
        zb = min(C1(:,3));
        ze = max(C1(:,3));
        end
    end
end

if nargin >=12
    if ~isempty(varargin{3}) | varargin{3} > 0
        mult = varargin{3};
    end
end

if nargin >=13
    if ~isempty(varargin{4}) | varargin{4} > 0
        unitfactor = varargin{4}; % by default in nm
    end
end
%%
if boundarycorrection
    bcor = 1;
else
    bcor = [];
end
% Loop through object boundaries

numo = 1;%numel(B); % currently working only for one ROI
n1 = size(C1,1);
inPoint1(1) = n1;
if col > 2
    n3 = size(C3,1);
    inPoint3(1) = n3;
end
if col > 1
    n2 = size(C2,1);
    inPoint2(1) = n2;
end
% memory allocation
nD = length(D);
C1r = cell(numo,1);
K1 = zeros(nD,numo);
L1 = zeros(nD,numo);
C2r = cell(numo,1);
borcorSIM1 = zeros(n1,Nsimul);
PCF1 = zeros(nD-1,numo);
lam1 = zeros(numo,1);
PCFsim1 = zeros(nD-1,Nsimul,numo);
Ksim1 = zeros(nD,Nsimul,numo);
Lsim1 = zeros(nD,Nsimul,numo);
if col > 1
Ksim12 = zeros(nD,Nsimul,numo);
Lsim12 = zeros(nD,Nsimul,numo);
Ksim21 = zeros(nD,Nsimul,numo);
Lsim21 = zeros(nD,Nsimul,numo);
KdMs12 = zeros(nD,Nsimul,numo);
LdMs12 = ones(nD,Nsimul,numo);
Ksim2 = zeros(nD,Nsimul,numo);
Lsim2 = zeros(nD,Nsimul,numo);
K2 = zeros(nD,numo);
L2 = zeros(nD,numo);
K12 = zeros(nD,numo);
L12 = zeros(nD,numo);
K21 = zeros(nD,numo);
L21 = zeros(nD,numo);
KdM12 = zeros(nD,numo);
LdM12 = zeros(nD,numo);
lam2 = zeros(numo,1);
lam3 = zeros(numo,1);
vol = zeros(numo,1);
PCFsim12 = zeros(nD-1,Nsimul,numo);
PCFsim21 = zeros(nD-1,Nsimul,numo);
PCFsim2 = zeros(nD-1,Nsimul,numo);
PCF2 = zeros(nD-1,numo);
PCF12 = zeros(nD-1,numo);
PCF21 = zeros(nD-1,numo);
borcorSIM2 = zeros(n2,Nsimul);
end
if col == 3
borcorSIM3 = zeros(n3,Nsimul);
C3r = cell(numo,1);
K3 = zeros(nD,numo);
L3 = zeros(nD,numo);
PCF3 = zeros(nD-1,numo);
Lsim3 = zeros(nD,Nsimul,numo);
Ksim3 = zeros(nD,Nsimul,numo);
Ksim13 = zeros(nD,Nsimul,numo);
Lsim13 = zeros(nD,Nsimul,numo);
Ksim31 = zeros(nD,Nsimul,numo);
Lsim31 = zeros(nD,Nsimul,numo);
KdMs13 = zeros(nD,Nsimul,numo);
LdMs13 = ones(nD,Nsimul,numo);
K13 = zeros(nD,numo);
L13 = zeros(nD,numo);
K31 = zeros(nD,numo);
L31 = zeros(nD,numo);
KdM13 = zeros(nD,numo);
LdM13 = zeros(nD,numo);
PCFsim13 = zeros(nD-1,Nsimul,numo);
PCFsim31 = zeros(nD-1,Nsimul,numo);
PCF13 = zeros(nD-1,numo);
PCF31 = zeros(nD-1,numo);
Ksim23 = zeros(nD,Nsimul,numo);
Lsim23 = zeros(nD,Nsimul,numo);
Ksim32 = zeros(nD,Nsimul,numo);
Lsim32 = zeros(nD,Nsimul,numo);
KdMs23 = zeros(nD,Nsimul,numo);
LdMs23 = ones(nD,Nsimul,numo);
K23 = zeros(nD,numo);
L23 = zeros(nD,numo);
K32 = zeros(nD,numo);
L32 = zeros(nD,numo);
KdM23 = zeros(nD,numo);
LdM23 = zeros(nD,numo);
PCFsim3 = zeros(nD-1,Nsimul,numo);
PCFsim23 = zeros(nD-1,Nsimul,numo);
PCFsim32 = zeros(nD-1,Nsimul,numo);
PCF23 = zeros(nD-1,numo);
PCF32 = zeros(nD-1,numo);
end
R1 = B{1};
%% spatial statistics
% supplied roi should be as close to convex roi as possible. Use 'Test ROI'
% button to test if your ROI is convex
k2 = convhull(R1(:,1),R1(:,2),'Simplify',true);%,'Simplify',true
boundary =  [R1(k2,1),R1(k2,2),zb*ones(numel(R1(k2,2)),1);...
R1(k2,1),R1(k2,2),ze*ones(numel(R1(k2,2)),1)];
% [k2,av2] = convhull(boundary(:,1),boundary(:,2),boundary(:,3));%,'Simplify',true
% boundary = boundary(k2);
DT = delaunayTriangulation(boundary);
C = convexHull(DT);
TR = triangulation(C,DT.Points);
points = TR.Points;
arg.points = points;
arg.zmax = ze;
arg.zmin = zb;
if col == 3
    [K1,L1,K2,L2,K3,L3,K12,L12,...
    K21,L21,K13,L13,K31,L31,K23,L23,K32,L32,...
    PCF1,PCF2,PCF3,PCF12,PCF21,PCF13,PCF31,PCF23,PCF32,...
    lam1,lam2,lam3,vol,...
    borcor1,borcor2,borcor3] = ripleysK3colNEW(C1,C2,C3,R1,D,dim,ifplot,bcor,unitfactor,arg);

    KdM12 = (K12*inPoint2(1) + K21*inPoint1)/(inPoint1 + inPoint2);
    KdM13 = (K13*inPoint3 + K31*inPoint1)/(inPoint1 + inPoint3);
    KdM23 = (K32*inPoint2 + K23*inPoint3)/(inPoint3 + inPoint2);
    if dim == 3
        LdM12 = nthroot(3*KdM12/pi/4,3) - D(:)*unitfactor;
        LdM13 = nthroot(3*KdM13/pi/4,3) - D(:)*unitfactor;
        LdM23 = nthroot(3*KdM23/pi/4,3) - D(:)*unitfactor;
    elseif dim == 2
        LdM12 = sqrt(KdM12/pi) - D(:)*unitfactor;
        LdM13 = sqrt(KdM13/pi) - D(:)*unitfactor;
        LdM23 = sqrt(KdM23/pi) - D(:)*unitfactor;
    end
    
elseif col == 2
    [K1,L1,K2,L2,~,~,K12,L12,...
    K21,L21,~,~,~,~,~,~,~,~,...
    PCF1,PCF2,~,PCF12,PCF21,~,~,~,~,...
    lam1,lam2,~,vol,...
    borcor1,borcor2,~] = ripleysK3colNEW(C1,C2,[],R1,D,dim,ifplot,bcor,unitfactor,arg);

    KdM12 = (K12*inPoint2(1) + K21*inPoint1)/(inPoint1 + inPoint2);
    KdM13 = [];
    KdM23 = [];
    if dim == 3
        LdM12 = nthroot(3*KdM12/pi/4,3) - D(:)*unitfactor;
        LdM13 = [];
        LdM23 = [];
    elseif dim == 2
        LdM12 = sqrt(KdM12/pi) - D(:)*unitfactor;
        LdM13 = [];
        LdM23 = [];
    end
elseif col == 1
    [K1,L1,~,~,~,~,~,~,...
    ~,~,~,~,~,~,~,~,~,~,...
    PCF1,~,~,~,~,~,~,~,~,...
    lam1,~,~,vol,...
    borcor1,~,~] = ripleysK3colNEW(C1,[],[],R1,D,dim,ifplot,bcor,unitfactor,arg);

    KdM12 = [];
    KdM13 = [];
    KdM23 = [];
    LdM12 = [];
    LdM13 = [];
    LdM23 = [];
end
% save('RipleyTMP')
%% variable initiation for randomization
rng('shuffle') % initialize rundom number generation
ifplot1 = 0;
for i = 1:Nsimul
    sprintf('Simulation %d',i)
    
     C1r{i,1} = randomPTSinBoundary(R1(k2,1),R1(k2,2),n1,3,zb,ze,ifplot1);
     if col > 1
     C2r{i,1} = randomPTSinBoundary(R1(k2,1),R1(k2,2),n2,3,zb,ze,ifplot1);
     end
    
    if col == 3
       C3r{i,1} = randomPTSinBoundary(R1(k2,1),R1(k2,2),n3,3,zb,ze,ifplot1);
          
    [Ksim1(:,i),Lsim1(:,i),Ksim2(:,i),Lsim2(:,i),Ksim3(:,i),...
     Lsim3(:,i),Ksim12(:,i),Lsim12(:,i),Ksim21(:,i),Lsim21(:,i),...
     Ksim13(:,i),Lsim13(:,i),Ksim31(:,i),Lsim31(:,i),Ksim23(:,i),...
     Lsim23(:,i),Ksim32(:,i),Lsim32(:,i),PCFsim1(:,i),PCFsim2(:,i),...
     PCFsim3(:,i),PCFsim12(:,i),PCFsim21(:,i),PCFsim13(:,i),...
     PCFsim31(:,i),PCFsim23(:,i),PCFsim32(:,i),...
     borcorSIM1(:,i),borcorSIM2(:,i),borcorSIM3(:,i)] = ...
     ripleysK3colNEW( C1r{i,1}, C2r{i,1}, C3r{i,1},R1,D,dim,ifplot,bcor,unitfactor,arg);
%                                                                                                    (C1,C2,C3,R1,D,dim,ifplot,bcor,unitfactor,arg);
    KdMs12(:,i) = (Ksim12(:,i)*n2 + Ksim21(:,i)*n1)/(n2 + n1);
    KdMs13(:,i) = (Ksim13(:,i)*n3 + Ksim31(:,i)*n1)/(n3+n1);
    KdMs23(:,i) = (Ksim32(:,i)*n2+ Ksim23(:,i)*n3)/(n2+n3);
    if dim == 3
        LdMs12(:,i) = nthroot(3*KdMs12(:,i)/pi/4,3) - D(:)*unitfactor;
        LdMs13(:,i) = nthroot(3*KdMs13(:,i)/pi/4,3) - D(:)*unitfactor;
        LdMs23(:,i) = nthroot(3*KdMs23(:,i)/pi/4,3) - D(:)*unitfactor;
    elseif dim == 2
        LdMs12(:,i) = sqrt(KdMs12(:,i)/pi) - D(:)*unitfactor;
        LdMs13(:,i) = sqrt(KdMs13(:,i)/pi) - D(:)*unitfactor;
        LdMs23(:,i) = sqrt(KdMs23(:,i)/pi) - D(:)*unitfactor;
    end
    elseif col == 2
      
    [Ksim1(:,i),Lsim1(:,i),Ksim2(:,i),Lsim2(:,i),~,...
     ~,Ksim12(:,i),Lsim12(:,i),Ksim21(:,i),Lsim21(:,i),...
     ~,~,~,~,~,...
     ~,~,~,PCFsim1(:,i),PCFsim2(:,i),...
     ~,PCFsim12(:,i),PCFsim21(:,i),~,...
     ~,~,~,...
     borcorSIM1(:,i),borcorSIM2(:,i),~] = ...
     ripleysK3colNEW( C1r{i,1}, C2r{i,1}, [],R1,D,dim,ifplot,bcor,unitfactor,arg);
%                                                                                                    (C1,C2,C3,R1,D,dim,ifplot,bcor,unitfactor,arg);
    KdMs12(:,i) = (Ksim12(:,i)*n2 + Ksim21(:,i)*n1)/(n2 + n1);
    KdMs13 = [];
    KdMs23 = [];
    if dim == 3
        LdMs12(:,i) = nthroot(3*KdMs12(:,i)/pi/4,3) - D(:)*unitfactor;
        LdMs13 = [];
        LdMs23 = [];
    elseif dim == 2
        LdMs12(:,i) = sqrt(KdMs12(:,i)/pi) - D(:)*unitfactor;
        LdMs13 = [];
        LdMs23 = [];
    end
    elseif col == 1
        
    [Ksim1(:,i),Lsim1(:,i),~,~,~,...
     ~,~,~,~,~,...
     ~,~,~,~,~,...
     ~,~,~,PCFsim1(:,i),~,...
     ~,~,~,~,...
     ~,~,~,...
     borcorSIM1(:,i),~,~] = ...
     ripleysK3colNEW( C1r{i,1}, [], [],R1,D,dim,ifplot,bcor,unitfactor,arg);
    KdMs13 = [];
    KdMs23 = [];                                                                                         
    KdMs12 = [];
    KdMs13 = [];
    KdMs23 = [];
    LdMs12= [];
    LdMs13 = [];
    LdMs23 = [];
    end 
    
    save('RipleyTMP')
end
               
        sprintf('Simul %d finished, boundary %d out of %d',i, 1, numo)
        clear RP1x RP1y RP1z RP2x RP2y RP2z RP3x RP3y RP3z
toc
end
