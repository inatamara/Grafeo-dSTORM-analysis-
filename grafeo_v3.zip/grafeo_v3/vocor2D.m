function boundaryCorr = vocor2D(dist,range,B,x,y)
if dist <= range  & dist > 0
 [xcirc, ycirc] = circleplot(x,y,dist);
try
     ind= find(InPolygon(xcirc, ycirc, B{1}(:,2),B{1}(:,1)));
catch
     ind= find(inpolygon(xcirc, ycirc, B{1}(:,2),B{1}(:,1)));
end
if ~isempty(ind)
boundaryCorr = numel(ind)/numel(xcirc);ind= [];
end
end

