function grafeo
% This is version 1.beta of Grafeo program.
% To cite and acknowledge this version beta program use:
% Haas et al., 'Single-molecule localization microscopy 
% reveals molecular transactions during RAD51 filament assembly at cellular
% DNA damage sites',  Nucleic Acids Research, 2018,gkx1303, https://doi.org/10.1093/nar/gkx1303
% Copyright (C) Kalina Tamara Haas, 2017, Cambridge, UK
% you can download the licence from here:
% https://github.com/inatamara/Grafeo-dSTORM-analysis-
% For help on this program and any other related inquiries please contact:
% Author: Kalina Tamara Haas
% e-mail: inakuflers@wp.pl
% twitter: @KalinaHaas
% Last modified: 11/01/2018

set(0,'units','pixels')

Pix_SS = get(0,'screensize');
if ~ismac
    flagslash = '\';
else
    flagslash = '/';
end
%%
fac1 = 7;
fac2 = 8;
% width = floor(fac1*Pix_SS(3)/fac2);
% height = floor(width*Pix_SS(4)/Pix_SS(3));
% left = floor((Pix_SS(3)-width)/2);
% bottom = floor((Pix_SS(4)-height)/2);
% width = 1100;
% height = 850;
% left = 100;
% bottom = 20;
% width = 2*Pix_SS(3)/3;
height = floor(3*Pix_SS(4)/4);
width = 4*height/3;

left = floor((Pix_SS(3)-width)/2);
bottom = floor((Pix_SS(4)-height)/2);
%%

f = figure('Visible','on','Position',[left bottom floor(width) height],...
'NumberTitle','off','Menubar','none','Toolbar','none',...
 'Name', 'Grafeo v.1.2beta'); %, 'resize', 'off' 

movegui(f,'center');
width_ha = 7/8*height;%floor((width - left_ha)/2);
height_ha = width_ha;
% pbw = 65; pbh = 15;pbs = 7;
pbw = floor(width/25); 
pbh = floor(height/75);
% pbhe = floor(height/65);
pbs = floor(pbh/2);
% set(f,'FontSize',floor(7*pbh/8))
left_ha = floor(1.5*pbw);
bottom_ha = floor((height-width_ha)/4);
%% image axes
ha = axes('Parent', f,'Units','pixels','Position',[left_ha,bottom_ha,width_ha,height_ha]);
set(ha, 'XTick', [], 'YTick', []);
%%
global Vp1 Vp2 dataout2 dataout1 Dp1 Dp2 tmpch2 tmpch1
global pathreal filenamepreal dataoutshift1 namech1 namech2 photonTH1 locprec1
global im1pw im2pw densitythr2 photonTH2 locprec2 densitythr1
 zcount = 0;
totalMask1 = [];
flagmask = 0;
pos0 = []; 
hrect = [];
api = [];
flagalign = 0; 
updowncount = 0;
leftrightcount = 0;
visu1 = 0;
visu2 = 0;
imRGB = [];

% green = [255 178 33]/255;
%orange
% green = [255 102 0]/255;
% green = [23,183,105]/255;
% violet = [160,121,167]/255;
yellow = [228,117,0]/255;
violet = [23,183,105]/255;
green = [160,121,167]/255;
% violet = [188,91,128]/255;
namech1 = [];
namech2 = [];
dim = 0;
Dp3 = [];
dataout3 = [];
namech3 = [];
locprec3 = [];
photonTH3 = [];
tmpch3 = [];
Vp3 = [];
%% 
s_minPpos= [left_ha+width_ha + pbs,bottom_ha+height_ha - pbh,pbw,pbh];

s_panelvoronoi = [s_minPpos(1)-pbs/2,s_minPpos(2)-6.25*(pbh+pbs),6*(pbw+pbs),8*(pbh+pbs)];
pvoronoi = uipanel(f,'units','pixels','Title','Voronoi Tessellation parameters',...
             'Position',s_panelvoronoi,'FontSize',9,'FontWeight','bold');
         

uicontrol('Style','text',...
                'String','min photon #',...
                'Position',s_minPpos);
s_textval_minP1 = s_minPpos + [s_minPpos(3) + pbs 0 0 0];             
textbox_minP1 = uicontrol('Style','edit',...
                'String','1000',...
                'Position',s_textval_minP1);
%             get(textbox_minP1,'Extent')
s_textval_minP2 = s_textval_minP1 + [s_textval_minP1(3) + pbs 0 0 0];             
textbox_minP2 = uicontrol('Style','edit',...
                'String','1000',...
                'Position',s_textval_minP2);  
                     
s_minD = s_textval_minP2 + [s_textval_minP2(3) + pbs,0,0,0];
uicontrol('Style','text',...
                'String','min Density',...
                'Position',s_minD);  
s_textvalminD1 = s_minD + [s_minD(3) + pbs 0 0 0];             
textbox_minDen1 = uicontrol('Style','edit',...
                'String','0',...
                'Position',s_textvalminD1);
            
s_textvalmaxD2 = s_textvalminD1 + [s_textvalminD1(3) + pbs 0 0 0];             
textbox_minDen2 = uicontrol('Style','edit',...
                'String','0','Position',s_textvalmaxD2);  
                      
s_maxD = s_minD - [0,s_minD(4) + pbs,0,0];
uicontrol('Style','text',...
                'String','max Density',...
                'Position',s_maxD);  
            
s_textvalmaxD1 = s_maxD + [s_maxD(3) + pbs 0 0 0];             
textbox_maxDen1 = uicontrol('Style','edit',...
                'String','0',...
                'Position',s_textvalmaxD1);
s_textvalmaxD2 = s_textvalmaxD1 + [s_textvalmaxD1(3) + pbs 0 0 0];             
textbox_maxDen2 = uicontrol('Style','edit',...
                'String','0',...
                'Position',s_textvalmaxD2);  
                    
s_meanD = s_maxD - [0,s_maxD(4) + pbs,0,0];
uicontrol('Style','text',...
                'String','mean Density',...
                'Position',s_meanD);  
            
s_textvalmeanD1 = s_meanD + [s_meanD(3) + pbs 0 0 0];             
textbox_meanDen1 = uicontrol('Style','edit',...
                'String','0',...
                'Position',s_textvalmeanD1);
s_textvalmeanD2 = s_textvalmeanD1 + [s_textvalmeanD1(3) + pbs 0 0 0];             
textbox_meanDen2 = uicontrol('Style','edit',...
                'String','0',...
                'Position',s_textvalmeanD2);  

s_medianD = s_meanD - [0,s_meanD(4) + pbs,0,0];
uicontrol('Style','text',...
                'String','median Density',...
                'Position',s_medianD);  
            
s_textvalmedianD1 = s_medianD + [s_medianD(3) + pbs 0 0 0];             
textbox_medianDen1 = uicontrol('Style','edit',...
                'String','0',...
                'Position',s_textvalmedianD1);
s_textvalmedianD2 = s_textvalmedianD1 + [s_textvalmedianD1(3) + pbs 0 0 0];             
textbox_medianDen2 = uicontrol('Style','edit',...
                'String','0',...
                'Position',s_textvalmedianD2);  
            

s_minLPpos =  s_minPpos - [0 s_minPpos(4) + pbs 0 0];  
uicontrol('Style','text',...
                'String','Loc. Prec.',...
                'Position',s_minLPpos);
textval_minLP1 = s_minLPpos + [s_minLPpos(3) + pbs 0 0 0];             
textbox_minLP1 = uicontrol('Style','edit',...
                'String','20',...
                'Position',textval_minLP1);
textval_minLP2 = textval_minLP1 + [textval_minLP1(3) + pbs 0 0 0];             
textbox_minLP2 = uicontrol('Style','edit',...
                'String','20',...
                'Position',textval_minLP2);

s_minDpos =  s_minLPpos - [0 s_minLPpos(4) + pbs 0 0];  
uicontrol('Style','text',...
                'String','Density',...
                'Position',s_minDpos);
textval_minD1 = s_minDpos + [s_minDpos(3) + pbs 0 0 0];             
textbox_minD1 = uicontrol('Style','edit',...
                'String','0.0001',...
                'Position',textval_minD1);
textval_minD2 = textval_minD1 + [textval_minD1(3) + pbs 0 0 0];             
textbox_minD2 = uicontrol('Style','edit',...
                'String','0.0005',...
                'Position',textval_minD2);

s_minIMpos =  s_minDpos - [0 s_minDpos(4) + pbs 0 0];  
uicontrol('Style','text',...
                'String','Image size',...
                'Position',s_minIMpos);
textval_minIM1 = s_minIMpos + [s_minIMpos(3) + pbs 0 0 0];             
textbox_minIM1 = uicontrol('Style','edit',...
                'String','4200',...
                'Position',textval_minIM1);
            
textval_minIM1y = textval_minIM1 + [textval_minIM1(3) + pbs 0 0 0];             
textbox_minIM1y = uicontrol('Style','edit',...
                'String','4200',...
                'Position',textval_minIM1y);

s_minPIXpos =  s_minIMpos - [0 s_minIMpos(4) + pbs 0 0];  
uicontrol('Style','text',...
                'String','Pixel size',...
                'Position',s_minPIXpos);
textval_minPIX1 = s_minPIXpos + [s_minPIXpos(3) + pbs 0 0 0];             
textbox_minPIX1 = uicontrol('Style','edit',...
                'String','10',...
                'Position',textval_minPIX1); 

s_minMAXIMpos =  s_minPIXpos - [0 s_minPIXpos(4) + pbs 0 0];  
uicontrol('Style','text',...
                'String','IM max',...
                'Position',s_minMAXIMpos);
textval_minMAXIM1 = s_minMAXIMpos + [s_minMAXIMpos(3) + pbs 0 0 0];             
textbox_minMAXIM1 = uicontrol('Style','edit',...
                'String','5000',...
                'Position',textval_minMAXIM1);

textval_minMAXIM2 = textval_minMAXIM1 + [textval_minMAXIM1(3) + pbs 0 0 0];             
textbox_minMAXIM2 = uicontrol('Style','edit',...
                'String','1000',...
                'Position',textval_minMAXIM2);

s_minSTEPpos =  s_minMAXIMpos - [0 s_minMAXIMpos(4) + pbs 0 0];  
uicontrol('Style','text',...
                'String','Step',...
                'Position',s_minSTEPpos);
s_text_minSTEP1 = s_minSTEPpos + [s_minSTEPpos(3) + pbs 0 0 0];             
textbox_minSTEP1 = uicontrol('Style','edit',...
                'String','100',...
                'Position',s_text_minSTEP1);

s_pushup = s_minSTEPpos - [0 s_minSTEPpos(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','UP',...
           'Tag','pushup','Position',s_pushup,...
           'Callback',@pushup_Callback);
s_pushdown = s_pushup - [0 s_pushup(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','DOWN',...
           'Tag','pushdown','Position',s_pushdown,...
           'Callback',@pushdown_Callback);
s_pushleft = s_pushdown - [0 s_pushdown(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','LEFT',...
           'Tag','pushleft','Position',s_pushleft,...
           'Callback',@pushleft_Callback);
s_pushright = s_pushleft - [0 s_pushleft(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','RIGHT',...
           'Tag','pushright','Position',s_pushright,...
           'Callback',@pushright_Callback);
s_pushresetX = s_pushright - [0 s_pushright(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','RESET x',...
           'Tag','pushresetX','Position',s_pushresetX,...
           'Callback',@pushresetX_Callback); 
       
s_pushresetY = s_pushresetX - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','RESET Y',...
           'Tag','pushrightY','Position',s_pushresetY,...
           'Callback',@pushresetY_Callback); 
s_pushresetZ = s_pushresetY - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','RESET Z',...
           'Tag','pushrightZ','Position',s_pushresetZ,...
           'Callback',@pushresetZ_Callback);  
s_pushresetALL = s_pushresetZ - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','RESET ALL',...
           'Tag','pushrightALL','Position',s_pushresetALL,...
           'Callback',@pushresetALL_Callback);  

pix = eval(textbox_minPIX1.String);
Nmax = eval(textbox_minIM1.String);

%%
function pushup_Callback(~,~)
step = -eval(textbox_minSTEP1.String);
if ~flagalign
   dataoutshift1 = dataout1;  
   flagalign = 1;
end  
   dataoutshift1(:,2) = dataoutshift1(:,2) - step;
   if ~isempty(updowncount)
       updowncount = updowncount + step;
   else
       updowncount = step;
   end
   cla(ha,'reset')
   violet = eval(colch1.String);
   green = eval(colch2.String);
   plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
   set(ha,'NextPlot','add');%hold on;
   plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
end
%down
function pushdown_Callback(~,~)
step = eval(textbox_minSTEP1.String);
if ~flagalign
   dataoutshift1 = dataout1;
end  
   dataoutshift1(:,2) = dataoutshift1(:,2) - step;
   if ~isempty(updowncount)
       updowncount = updowncount + step;
   else
       updowncount = step;
   end
   cla(ha,'reset')
   violet = eval(colch1.String);
   green = eval(colch2.String);
   plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
   set(ha,'NextPlot','add');%hold on;
   plot(dataout2(:,1),dataout2(:,2),'.m','Color',green','Parent', ha);  
   flagalign = 1;
end
% left
function pushleft_Callback(~,~)
step = eval(textbox_minSTEP1.String);
if ~flagalign
   dataoutshift1 = dataout1; 
   flagalign = 1;
end 
   dataoutshift1(:,1) = dataoutshift1(:,1) - step;
   if ~isempty(leftrightcount)
       leftrightcount = leftrightcount + step;
   else
       leftrightcount = step;
   end
   cla(ha,'reset')
   violet = eval(colch1.String);
   green = eval(colch2.String);
   plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
   set(ha,'NextPlot','add');%hold on;
   plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha);  
end
% right
function pushright_Callback(~,~)
step = -eval(textbox_minSTEP1.String);
if ~flagalign
    dataoutshift1 = dataout1; 
    flagalign = 1;
end  
dataoutshift1(:,1) = dataoutshift1(:,1) - step;
if ~isempty(leftrightcount)
    leftrightcount = leftrightcount + step;
else
    leftrightcount = step;
end
cla(ha,'reset')
violet = eval(colch1.String);
green = eval(colch2.String);
plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
set(ha,'NextPlot','add');%hold on;
plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha);  
end
% reset
function pushresetX_Callback(~,~)
dataoutshift1(:,1) = dataoutshift1(:,1)+ leftrightcount;
leftrightcount = 0;
disp('Reset X') 
end
function pushresetY_Callback(~,~)
dataoutshift1(:,2) = dataoutshift1(:,2) + updowncount;
updowncount = 0;
disp('Reset Y') 
end
function pushresetZ_Callback(~,~)
dataoutshift1(:,5) = dataoutshift1(:,5) + zcount;
zcount = 0;
disp('Reset Push') 
end
function pushresetALL_Callback(~,~)
flagalign = 0; 
updowncount = 0;
leftrightcount = 0;
zcount = 0;
disp('Reset all') 
end
%%


s_pushup3 = s_pushup + [s_pushup(3) + pbs 0 0 0];            
uicontrol('Style','pushbutton','String','Ch3: UP',...save
           'Tag','pushup','Position',s_pushup3,...
           'Callback',@pushup3_Callback);
s_pushdown3 = s_pushup3 - [0 s_pushup3(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','Ch3: DOWN',...
           'Tag','pushdown','Position',s_pushdown3,...
           'Callback',@pushdown3_Callback);
s_pushleft3 = s_pushdown3 - [0 s_pushdown3(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','Ch3: LEFT',...
           'Tag','pushleft','Position',s_pushleft3,...
           'Callback',@pushleft3_Callback);
       
s_pushright3 = s_pushleft3 - [0 s_pushleft3(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','Ch3: RIGHT',...
           'Tag','pushright','Position',s_pushright3,...
           'Callback',@pushright3_Callback);
flagalign3 = 0;  
updowncount3 = [];
leftrightcount3 = [];
dataoutshift3 = [];
function pushup3_Callback(~,~)
step = -eval(textbox_minSTEP1.String);
if pm1.Value == 5
%    flagalign3 = 0;
if ~flagalign3
   dataoutshift3 = dataout3;  
   flagalign3 = 1;
end  
   dataoutshift3(:,2) = dataoutshift3(:,2) - step;
   if ~isempty(updowncount)
       updowncount3 = updowncount3 + step;
   else
       updowncount3 = step;
   end
   cla(ha,'reset')
   violet = eval(colch1.String);
   green = eval(colch2.String);
   yellow = eval(colch3.String);
   
   set(ha,'NextPlot','add');%hold on;
   try
       plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);  
   catch
       plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);    
   end
   plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
   plot(dataoutshift3(:,1),dataoutshift3(:,2),'.g','Color',yellow,'Parent', ha);   
   
end
end
%down
function pushdown3_Callback(~,~)
step = eval(textbox_minSTEP1.String);
if pm1.Value == 5
if ~flagalign3
   dataoutshift3 = dataout3;
end  
   dataoutshift3(:,2) = dataoutshift3(:,2) - step;
   if ~isempty(updowncount3)
       updowncount3 = updowncount3 + step;
   else
       updowncount3 = step;
   end
   cla(ha,'reset')
   violet = eval(colch1.String);
   green = eval(colch2.String);
yellow = eval(colch3.String);
   set(ha,'NextPlot','add');%hold on;
   
   try
       plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);  
   catch
       plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);    
   end
   plot(dataout2(:,1),dataout2(:,2),'.m','Color',green','Parent', ha); 
      plot(dataoutshift3(:,1),dataoutshift3(:,2),'.g','Color',yellow,'Parent', ha);   
   flagalign3 = 1;
end
end
% left
function pushleft3_Callback(~,~)
step = eval(textbox_minSTEP1.String);
if pm1.Value == 5
if ~flagalign3
   dataoutshift3 = dataout3; 
   flagalign3 = 1;
end 
   dataoutshift3(:,1) = dataoutshift3(:,1) - step;
   if ~isempty(leftrightcount)
       leftrightcount3 = leftrightcount3 + step;
   else
       leftrightcount3 = step;
   end
   cla(ha,'reset')
   violet = eval(colch1.String);
   green = eval(colch2.String);
  
   set(ha,'NextPlot','add');%hold on;
   
    try
       plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);  
   catch
       plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);    
    end
    plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha);  
       plot(dataoutshift3(:,1),dataoutshift3(:,2),'.g','Color',yellow,'Parent', ha); 
end
end
% right
function pushright3_Callback(~,~)
step = -eval(textbox_minSTEP1.String);
if pm1.Value == 5
if ~flagalign3
    dataoutshift3 = dataout3; 
    flagalign3 = 1;
end  
dataoutshift3(:,1) = dataoutshift3(:,1) - step;
if ~isempty(leftrightcount3)
    leftrightcount3 = leftrightcount3 + step;
else
    leftrightcount3 = step;
end
cla(ha,'reset')
violet = eval(colch1.String);
green = eval(colch2.String);
yellow = eval(colch3.String);

set(ha,'NextPlot','add');%hold on;
   try
       plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);  
   catch
       plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);    
   end

   plot(dataoutshift3(:,1),dataoutshift3(:,2),'.g','Color',yellow,'Parent', ha); 
   plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
end
end
%%
s_pushzup3 = s_pushright3 - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','C3: z up',...
           'Tag','pushzup','Position',s_pushzup3,...
           'Callback',@pushzup3_Callback);
%%
zcount3 = [];
function pushzup3_Callback(~,~)

    violet = eval(colch1.String);
    green = eval(colch2.String);
     yellow = eval(colch3.String);
    step = -eval(textbox_minSTEP1.String);
    if ~flagalign
       dataoutshift3 = dataout3;  
        dataoutshift3(:,5) = dataoutshift3(:,5) - step;
       flagalign = 1;
    end  
       dataoutshift3(:,5) = dataoutshift3(:,5) - step;
       zcount3 = zcount3 + step;
if ~isempty(pos0)

pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
fig = figure;
ax = axes;
set(ax,'NextPlot','add');
if pm1.Value == 5
    if flagalign3
        dat3 = dataoutshift3(dataoutshift3(:,1) <= xmax & dataoutshift3(:,1) >= xmin &...
        dataoutshift3(:,2) <= ymax & dataoutshift3(:,2) >= ymin,[1,2,5]);
    else
        dat3 = dataout3(dataout3(:,1) <= xmax & dataout3(:,1) >= xmin &...
        dataout3(:,2) <= ymax & dataout3(:,2) >= ymin,[1,2,5]);
    end
    if flagalign
        dat1 = dataoutshift1(dataoutshift3(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),30,yellow,'filled','Parent', ax)

    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);

    scatter3(dat3(:,1),dat3(:,2),dat3(:,3),30,violet,'filled','Parent', ax) %,'markertype','.'
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),30,green,'filled','Parent', ax)

end

    az = 188;
    el = 20;
    view(az, el);
    axis square
    alw = 1;    % AxesLineWidth
    fsz = 10;      % Fontsize
    set(ax,'xlim',[pos(1),pos(1)+pos(3)])
    set(ax,'ylim',[pos(2),pos(2)+pos(4)])
    fontname = 'Helvetica';
    set(ax, 'FontSize', fsz, 'LineWidth', alw);
    zl = zlabel(ax, 'Z [nm]');
    set(zl,'Fontname',fontname, 'Fontsize', fsz)   
    box on;
    pos1 = get(fig, 'Position');
    figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
    set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
    set(fig,'color','w')
    set(fig,'InvertHardcopy','on');
end   
end
%%
s_pushzdown3 = s_pushzup3 - [0 pbh + pbs 0 0];                 
uicontrol('Style','pushbutton','String','C3: Z down',...
           'Tag','pushzdown','Position',s_pushzdown3,...
           'Callback',@pushzdown3_Callback); 
%%
function pushzdown3_Callback(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);
yellow = eval(colch3.String);
step = eval(textbox_minSTEP1.String);
if ~flagalign3
   dataoutshift3 = dataout3;  
   flagalign3 = 1;
   dataoutshift3(:,5) = dataoutshift3(:,5) - step;
end  
       dataoutshift3(:,5) = dataoutshift3(:,5) - step;
       zcount3 = zcount3 + step;
       
if ~isempty(pos0)

pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);

fig = figure;
ax = axes;
set(ax,'NextPlot','add');
if pm1.Value == 1
    if flagalign3
        dat3 = dataoutshift3(dataoutshift3(:,1) <= xmax & dataoutshift3(:,1) >= xmin &...
        dataoutshift3(:,2) <= ymax & dataoutshift3(:,2) >= ymin,[1,2,5]);
    else
        dat3 = dataout3(dataout3(:,1) <= xmax & dataout3(:,1) >= xmin &...
        dataout3(:,2) <= ymax & dataout3(:,2) >= ymin,[1,2,5]);
    end
    if flagalign
        dat1 = dataoutshift1(dataoutshift3(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),30,yellow,'filled','Parent', ax)
    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    scatter3(dat3(:,1),dat3(:,2),dat3(:,3),30,yellow,'filled','Parent', ax) %,'markertype','.'
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),30,green,'filled','Parent', ax)

end
az = 188;
el = 20;
view(az, el);
axis square
alw = 1;    % AxesLineWidth
fsz = 10;      % Fontsize
set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
fontname = 'Helvetica';
set(ax, 'FontSize', fsz, 'LineWidth', alw);
zl = zlabel(ax, 'Z [nm]');
set(zl,'Fontname',fontname, 'Fontsize', fsz)   
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');   
end
end
%%
s_roi3dvoronoianim = s_pushzdown3 - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','3d animate',...
           'Tag','roi3dvoronoianim','Position',s_roi3dvoronoianim,...
           'Callback',@roi3dvoronoianim_Callback);
function roi3dvoronoianim_Callback(hObject,eventdata)
if ~isempty(pos0)
    
    Zval = eval(Zsel3dscatter.String);
    zfilterval = zfilter.Value;
    zmapval = zmap.Value;
    nodeyesval = nodeyes.Value;   
    
    prompt = {'Enter initial and final azymuth angle:',...
        'Enter initial and final elevation angle:',...
         'Enter step for azymuth angle:',...
        'Enter step for elevation angle:',...
        'Enter zoom factor:',...
        'Enter animation save name',...
        'Enter frame rate',...
        'Enter zoom frequency',...
        'Enter number of zoom steps'};
    dlg_title = 'Input';
    num_lines = 1;
    def = {'[5,360]','[5,180]','10','10','0','AnimWall_','6','3','3'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    azim = str2num(answer{1});
    elev = str2num(answer{2});
    degStep = str2num(answer{3});
    degStepelev = str2num(answer{4});
     zoomfac = str2num(answer{5}); 
     Frate = str2num(answer{7});
     savename = answer{6};  
pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
fig = figure;

ms = 4;
ax = axes;
set(ax,'NextPlot','add');%hold on;hold on;
alw = 1;    % AxesLineWidth
clear fanim
violet = eval(colch1.String);
green = eval(colch2.String);
yellow =  eval(colch3.String);
if pm1.Value == 1
  
    if flagalign
    dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
    dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
    dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
    dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
if sum(dat2(:,3)) & Zval & zfilterval
      dat1 = dat1(dat1(:,3)>Zval(1) & dat1(:,3)<Zval(2),:);  
      dat2 = dat2(dat2(:,3)>Zval(1) & dat2(:,3)<Zval(2),:);     
    end
    if ~isempty(polyreg) & nodeyesval
        [inpo1,onpo1] = inpolygon(dat1(:,1),dat1(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat1 = dat1(inpo1 | onpo1,:);
        [inpo2,onpo2] = inpolygon(dat2(:,1),dat2(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat2 = dat2(inpo2 | onpo2,:);
    end
    if zmapval
        % orange map
%        chigh = [255,161,21]/255;
%        clow = [102,64,8]/255;
%        mapUP = colormapCust( clow,chigh,256);       
         % violet map
       chigh = [186,158,255]/255;
       clow = [186,158,0]/255;
       
       chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
       cmap = colormapCust( clow,chigh,256);  
%         cmap = AdvancedColormap('al');
green  = [1,142,91]/255;
       plot3(dat2(:,1),dat2(:,2),dat2(:,3),'.','MarkerSize',ms,'Color',green)  
       plot3dZmap(dat1,cmap,ax,'.',5)
    else
    
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),ms,violet,'filled') %,'markertype','.'
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),ms,green,'filled')
   
    end
    
    set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax,'xtick',[],'ytick',[],'ztick',[]);
set(ax, 'LineWidth', alw);
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
% set(fig,'color','w')
% set(fig,'InvertHardcopy','on');
axis equal

      qual = 100;
    writerObj = VideoWriter(strcat(pathreal,flagslash,savename));
    writerObj.FrameRate = Frate;
    writerObj.Quality = qual;
    % writerObj.VideoCompressionMethod = 'None';
    open(writerObj);
    az = azim(1);
    el = elev(1);
    view([az,el])
    fanim(1) = getframe(fig);
    kk= 1;
    h = zoom(fig);
    h.Enable = 'on';
    for iel = elev(1):degStepelev:azim(2)
        iaz = azim(1);
        view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
      if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      end
        
    end
    for iaz = azim(1):degStep:azim(2)
       iel = elev(1);
      view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
       if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
       end
    end
    az = azim(1);
    el = elev(1);
    view([az,el])
    kk= kk+ 1;
    fanim(kk) = getframe(fig);
    writeVideo(writerObj,fanim(kk));
    close(writerObj)
    elseif pm1.Value == 5
  
    if flagalign
        dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    
    if flagalign3
        dat3 = dataoutshift3(dataoutshift3(:,1) <= xmax & dataoutshift3(:,1) >= xmin &...
        dataoutshift3(:,2) <= ymax & dataoutshift3(:,2) >= ymin,[1,2,5]);
    else
        dat3 = dataout3(dataout3(:,1) <= xmax & dataout3(:,1) >= xmin &...
        dataout3(:,2) <= ymax & dataout3(:,2) >= ymin,[1,2,5]);
    end

    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);

if ~isempty(polyreg)  & nodeyesval
        [inpo1,onpo1] = inpolygon(dat1(:,1),dat1(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat1 = dat1(inpo1 | onpo1,:);
        [inpo2,onpo2] = inpolygon(dat2(:,1),dat2(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat2 = dat2(inpo2 | onpo2,:);
        [inpo3,onpo3] = inpolygon(dat3(:,1),dat3(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat3 = dat3(inpo3 | onpo3,:);
    end
    
    if sum(dat2(:,3)) & Zval & zfilterval
      dat1 = dat1(dat1(:,3)>Zval(1) & dat1(:,3)<Zval(2),:);  
      dat2 = dat2(dat2(:,3)>Zval(1) & dat2(:,3)<Zval(2),:);  
      dat3 = dat3(dat3(:,3)>Zval(1) & dat3(:,3)<Zval(2),:);  
    end
    if zmapval
       chigh = [186,158,255]/255;
       clow = [186,158,0]/255;
       chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
       cmap = colormapCust( clow,chigh,256);  
%         cmap = AdvancedColormap('al');
       plot3dZmap(dat1,cmap,ax,'.',8)
       green  = [1,142,91]/255;
       plot3(dat2(:,1),dat2(:,2),dat2(:,3),'.','MarkerSize',ms,'Color',green)  
       plot3(dat3(:,1),dat3(:,2),dat3(:,3),'.','MarkerSize',ms,'Color','b')  
    else
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),ms,violet,'filled') %,'markertype','.'
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),ms,green,'filled')
    scatter3(dat3(:,1),dat3(:,2),dat3(:,3),ms,yellow,'filled')
    end
    
    set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax,'xtick',[],'ytick',[],'ztick',[]);
set(ax, 'LineWidth', alw);
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
% set(fig,'color','w')
% set(fig,'InvertHardcopy','on');
axis equal

      qual = 100;
    writerObj = VideoWriter(strcat(pathreal,flagslash,savename));
    writerObj.FrameRate = Frate;
    writerObj.Quality = qual;
    % writerObj.VideoCompressionMethod = 'None';
    open(writerObj);
    az = azim(1);
    el = elev(1);
    view([az,el])
    fanim(1) = getframe(fig);
    kk= 1;
    h = zoom(fig);
    h.Enable = 'on';
      for iel = elev(1):degStepelev:azim(2)
        iaz = azim(1);
        view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
      if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      end
        
    end
    for iaz = azim(1):degStep:azim(2)
       iel = elev(1);
      view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
       if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
       end
    end
    az = azim(1);
    el = elev(1);
    view([az,el])
    kk= kk+ 1;
    fanim(kk) = getframe(fig);
    writeVideo(writerObj,fanim(kk));
    close(writerObj)
    
elseif pm1.Value == 2
    if flagalign

    dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
    dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else

    dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
    dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    if sum(dat1(:,3)) & Zval & zfilterval
      dat1 = dat1(dat1(:,3)>Zval(1) & dat1(:,3)<Zval(2),:);    
    end
     if ~isempty(polyreg) & nodeyesval
        [inpo1,onpo1] = inpolygon(dat1(:,1),dat1(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat1 = dat1(inpo1 | onpo1,:);
    end
    if zmapval
       chigh = [186,158,255]/255;
       clow = [186,158,0]/255;
       
       chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
       cmap = colormapCust( clow,chigh,256);  
       plot3dZmap(dat1,cmap,ax,'.',5)
    else
    
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),ms,violet,'filled') %,'markertype','.'
   
    end
          set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax,'xtick',[],'ytick',[],'ztick',[]);
set(ax, 'LineWidth', alw);
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
% set(fig,'color','w')
% set(fig,'InvertHardcopy','on');
axis equal

      qual = 100;
    writerObj = VideoWriter(strcat(pathreal,flagslash,savename));
    writerObj.FrameRate = Frate;
    writerObj.Quality = qual;
    % writerObj.VideoCompressionMethod = 'None';
   open(writerObj);
    az = azim(1);
    el = elev(1);
    view([az,el])
    fanim(1) = getframe(fig);
    kk= 1;
    h = zoom(fig);
    h.Enable = 'on';
      for iel = elev(1):degStepelev:azim(2)
        iaz = azim(1);
        view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
      if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      end
        
      end
    for iaz = azim(1):degStep:azim(2)
       iel = elev(1);
      view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
       if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
       end
    end
    az = azim(1);
    el = elev(1);
    view([az,el])
    kk= kk+ 1;
    fanim(kk) = getframe(fig);
    writeVideo(writerObj,fanim(kk));
    close(writerObj)
elseif pm1.Value == 3
    
    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    if sum(dat2(:,3)) & Zval & zfilterval
      dat2 = dat2(dat2(:,3)>Zval(1) & dat2(:,3)<Zval(2),:);   
    end
 if ~isempty(polyreg) & nodeyesval
        [inpo2,onpo2] = inpolygon(dat2(:,1),dat2(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat2 = dat2(inpo2 | onpo2,:);
    end
    if zmapval
       chigh = [186,158,255]/255;
       clow = [186,158,0]/255;
       
       chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
       cmap = colormapCust( clow,chigh,256);  
       plot3dZmap(dat2,cmap,ax,'.',5)
    else
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),ms,green,'filled')
   
    end
         set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax,'xtick',[],'ytick',[],'ztick',[]);
set(ax, 'LineWidth', alw);
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
% set(fig,'color','w')
% set(fig,'InvertHardcopy','on');
axis equal

      qual = 100;
    writerObj = VideoWriter(strcat(pathreal,flagslash,savename));
    writerObj.FrameRate = Frate;
    writerObj.Quality = qual;
    % writerObj.VideoCompressionMethod = 'None';
  open(writerObj);
    az = azim(1);
    el = elev(1);
    view([az,el])
    fanim(1) = getframe(fig);
    kk= 1;
    h = zoom(fig);
    h.Enable = 'on';
      for iel = elev(1):degStepelev:azim(2)
        iaz = azim(1);
        view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
      if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      end
        
    end
    for iaz = azim(1):degStep:azim(2)
       iel = elev(1);
      view([iaz,iel])
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      view([iaz,iel])
       if zoomfac
      h.Direction = 'in';
      zoom(zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
      h.Direction = 'out';
      zoom(1./zoomfac)
      kk= kk+ 1;
      fanim(kk) = getframe(fig);
      writeVideo(writerObj,fanim(kk));
       end
    end
    az = azim(1);
    el = elev(1);
    view([az,el])
    kk= kk+ 1;
    fanim(kk) = getframe(fig);
    writeVideo(writerObj,fanim(kk));
    close(writerObj)
    
end
end
end
%% save align
s_savealign = s_pushresetALL - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','Save align',...
           'Tag','savealign','Position',s_savealign,...
           'Callback',@savealign_Callback);        
function savealign_Callback(~,~)
    if flagalign
        filenamesavealign = strcat(namech1(1:end-28),'_',namech2(1:end-28),'_algnd.mat');
        uisave({'leftrightcount','updowncount','zcount'},filenamesavealign) 
    disp('Saveing finished')
    end
end
%% load align
s_loadalign = s_savealign - [0 s_savealign(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','Load align',...
           'Tag','loadalign','Position',s_loadalign,...
           'Callback',@loadalign_Callback); 
function loadalign_Callback(~,~)
       [filename,path] = uigetfile('*.mat*','Select file with aligned data...');
        tmp = load(strcat(path,flagslash,filename),'leftrightcount','updowncount','zcount');
        leftrightcount = tmp.leftrightcount;
        updowncount = tmp.updowncount;
       
        try
         zcount = tmp.zcount;
        catch
            zcount = 0;
        end
        
        if ~isempty(leftrightcount) | ~isempty(updowncount)
            flagalign = 1;
        else
            flagalign = 0;
        end
         disp('Loading align finished')
end
%% apply align
s_applyalign = s_loadalign - [0 s_loadalign(4) + pbs 0 0];            
uicontrol('Style','pushbutton','String','Apply align',...
           'Tag','sapplyalign','Position',s_applyalign,...
           'Callback',@applyalign_Callback); 
function applyalign_Callback(~,~)
if visu1 && visu2 && flagalign
    dataoutshift1 = dataout1; 
    if ~isempty(leftrightcount)
        dataoutshift1(:,1) = dataoutshift1(:,1) - leftrightcount;
    end
    if ~isempty(updowncount)
        dataoutshift1(:,2) = dataoutshift1(:,2) - updowncount;
    end
    if dim == 3
        if ~isempty(zcount)
            dataoutshift1(:,5) = dataoutshift1(:,5) - zcount;
        end
    end
    cla(ha,'reset')
    violet = eval(colch1.String);
    green = eval(colch2.String);
    plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    set(ha,'NextPlot','add');%hold on;hold on;
    plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha);   
    flagalign = 1;
end
end   
%% load voronoi 1

% s_loadimage1 = [left_ha,2*bottom_ha+height_ha-floor(bottom_ha/2)-floor(bottom_ha/6),pbw+pbs,pbh];
s_loadimage1 = [left_ha,bottom_ha+height_ha+2*pbh+3*pbs,pbw,pbh];
uicontrol('Style','pushbutton','String','Load 1 or 2',...
           'Tag','loadimage1','Position',s_loadimage1,...
           'Callback',@loadimage1_Callback);
       
s_pm1 = s_loadimage1 + [0 pbh+2*pbs pbw 0];              
pm1 = uicontrol('Style','popupmenu',...
                'String',{'1+2 Chanel','1 Chanel','2 Chanel','3 Chanel','1+2+3 Chanel'},...
                'Value',1,'Position',s_pm1 -[0 -2*pbs pbs 2*pbs]);
            
           
namech1 = [];
chnl = 0;
s_clearax = [left_ha,bottom_ha+height_ha+pbs,2*pbw,pbh];
clearax = uicontrol('Style','checkbox',...
                'String','Clear axis',...
                'Value',0,'Position',s_clearax); %s_pm1 -[s_pm1(1) pbs 5*pbs -2*pbs]
% clearax.FontSize = 7;
function loadimage1_Callback(~,~)
    [namech,pathreal] = uigetfile('*.mat*','Select tesselated data...');
    tmpch = load(strcat(pathreal,flagslash,namech));
    filenamepreal = namech;
    violet = eval(colch1.String);
    clearaxis = clearax.Value;
    green = eval(colch2.String);
    chnl = tmpch.ch;
     flagalign =0;
    if pm1.Value == 2
        namech1 = namech;
        tmpch1 = load(strcat(pathreal,flagslash,namech1));
        dataout1 = tmpch1.dataout1;
        densitythr1 = tmpch1.densitythr1;
        textbox_minD1.String = num2str(densitythr1);
        namech1 = tmpch1.namech1; 
        Vp1 = tmpch1.Vp1;
        Dp1 = tmpch1.Dp1; 
        textbox_meanDen1.String = num2str(mean(Dp1));
        textbox_medianDen1.String = num2str(median(Dp1));
        textbox_minDen1.String = num2str(min(Dp1));
        textbox_maxDen1.String = num2str(max(Dp1));
        try
            photonTH1 = tmpch.photonTH1;
            locprec1 = tmpch.locprec1;
        catch
            photonTH1 = min(dataout1(:,3));
            locprec1 = min(dataout1(:,4));
        end
        textbox_minP1.String = photonTH1;  
        textbox_minLP1.String = locprec1;
        visu1 = 1;
        if clearaxis
        cla(ha,'reset')
        end
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha); 
        set(ha,'NextPlot','add');
        chnl = 1;
        visu1 = 1;
    elseif pm1.Value == 3
        namech2 = namech;
        tmpch2 = load(strcat(pathreal,flagslash,namech2));
        dataout2 = tmpch2.dataout2;
        densitythr2 = tmpch2.densitythr2;
        textbox_minD2.String = num2str(densitythr2);
        namech2 = tmpch2.namech2; 
        Vp2 = tmpch2.Vp2;
        Dp2 = tmpch2.Dp2;
        textbox_meanDen2.String = num2str(mean(Dp2));
        textbox_medianDen2.String = num2str(median(Dp2));
        textbox_minDen2.String = num2str(min(Dp2));
        textbox_maxDen2.String = num2str(max(Dp2));
        try
            photonTH2 = tmpch2.photonTH2;
            locprec2 = tmpch2.locprec2;
        catch
            photonTH2 = min(dataout2(:,3));
            locprec2 = min(dataout2(:,4));
        end
        textbox_minP2.String = photonTH2;  
        textbox_minLP2.String = locprec2;
        if clearaxis
        cla(ha,'reset')
        end
        plot(dataout2(:,1),dataout2(:,2),'.g','Color',green,'Parent', ha); 
        set(ha,'NextPlot','add');
        chnl = 2;
        visu2 = 1;
    end
    disp('Loading finished')
end
%%
s_loadraw = s_loadimage1 + [pbw + pbs 0 0 0];              
uicontrol('Style','pushbutton',...
                'String','1, 2, 3 raw',...
                'Position',s_loadraw,...
                'tag','loadraw',...
                'Callback',@loadraw_Callback);
namech1 = [];
chnl = 0;
vr = [];
cr = [];
numfr = 0;

function loadraw_Callback(~,~)
     flagalign =0;
     clearaxis = clearax.Value;
    if pm1.Value == 2
    [namech,pathreal] = uigetfile('*.mat*','Select raw tesselated data for chanel 1...');
    
    filenamepreal = namech;
    tmpch1 = load(strcat(pathreal,flagslash,namech));
    namech1 = namech;
    tmpch1 = load(strcat(pathreal,flagslash,namech1));
    dataout1 = tmpch1.datatesselerfilt;
    violet = eval(colch1.String);
    dataout1 = dataout1(:,[1,2,3,5,6,4,7,8]);
    Vp1 = tmpch1.Vp;
    Dp1 = 1./tmpch1.VOLp;
    dim = tmpch1.dim;
%     vr = tmpch1.v;
%     cr = tmpch1.c;
%     numfr = tmpch1.numfr;
%     textbox_minD1.String = num2str(densitythr1);
    textbox_meanDen1.String = num2str(mean(Dp1));
    textbox_medianDen1.String = num2str(median(Dp1));
    textbox_minDen1.String = num2str(min(Dp1));
    textbox_maxDen1.String = num2str(max(Dp1));
    try
        photonTH1 = tmpch1.photonTH;
        locprec1 = tmpch1.locprec;
    catch
        photonTH1 = min(dataout1(:,3));
        locprec1 = max(dataout1(:,4));
    end
    textbox_minP1.String = photonTH1;  
    textbox_minLP1.String = locprec1;
    visu1 = 1;
    dataoutshift1 = [];
    zcount = [];
    leftrightcount = [];
    updowncount = [];
    if clearaxis
    cla(ha,'reset')
    end
    plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha); 
    set(ha,'NextPlot','add');
    chnl = 1;
    disp('Loading finished')
    
    elseif pm1.Value == 3
    [namech,pathreal] = uigetfile('*.mat*','Select raw tesselated data for chanel 2...');
     filenamepreal = namech;
    namech2 = namech;
    tmpch2 = load(strcat(pathreal,flagslash,namech2));
    dataout2 = tmpch2.datatesselerfilt;
    dataout2 = dataout2(:,[1,2,3,5,6,4,7,8]);
    green = eval(colch2.String);
    Vp2 = tmpch2.Vp;
    Dp2 = 1./tmpch2.VOLp;
    dim = tmpch2.dim;
%     vr = tmpch1.v;
%     cr = tmpch1.c;
%     numfr = tmpch1.numfr;
        textbox_meanDen2.String = num2str(mean(Dp2));
        textbox_medianDen2.String = num2str(median(Dp2));
        textbox_minDen2.String = num2str(min(Dp2));
        textbox_maxDen2.String = num2str(max(Dp2));
        try
            photonTH2 = tmpch2.photonTH;
            locprec2 = tmpch2.locprec;
        catch
            photonTH2 = min(dataout2(:,3));
            locprec2 = max(dataout2(:,4));
        end
        textbox_minP2.String = photonTH2;  
        textbox_minLP2.String = locprec2;
    visu2 = 1;
    if clearaxis
    cla(ha,'reset')
    end
    plot(dataout2(:,1),dataout2(:,2),'.g','Color',green,'Parent', ha); 
    chnl = 2;
    set(ha,'NextPlot','add');
    disp('Loading finished') 
elseif pm1.Value == 4
    [namech,pathreal] = uigetfile('*.mat*','Select raw tesselated data for chanel 3...');
     filenamepreal = namech;
    namech3 = namech;
    tmpch3 = load(strcat(pathreal,flagslash,namech3));
    dataout3 = tmpch3.datatesselerfilt;
    dataout3 = dataout3(:,[1,2,3,5,6,4,7,8]);
    yellow = eval(colch3.String);
    dim = tmpch3.dim;
    Vp3 = tmpch3.Vp;
    Dp3 = 1./tmpch3.VOLp;
%     textbox_meanDen2.String = num2str(mean(Dp2));
%     textbox_medianDen2.String = num2str(median(Dp2));
%     textbox_minDen2.String = num2str(min(Dp2));
%     textbox_maxDen2.String = num2str(max(Dp2));
        try
            photonTH3 = tmpch3.photonTH;
            locprec3 = tmpch3.locprec;
        catch
            photonTH3 = min(dataout3(:,3));
            locprec3 = max(dataout3(:,4));
        end
%         textbox_minP2.String = photonTH3;  
%         textbox_minLP2.String = locprec3;
    visu3 = 1;
    if clearaxis
    cla(ha,'reset')
    end
    plot(dataout3(:,1),dataout3(:,2),'.g','Color',yellow,'Parent', ha); 
    chnl = 3;
    set(ha,'NextPlot','add');
    disp('Loading finished') 
    else
        msgbox('Select chanel 1, 2 or 3 from the list box...')
    end
    
end
%% load prealign
s_loadprealign  =  s_loadimage1 - [0 pbh+pbs 0 0];  
uicontrol('Style','pushbutton','String','Load 1+2/3',...
           'Tag','loadprealign','Position',s_loadprealign,...
           'Callback',@loadprealign_Callback);
densitythr3 = [];
visu3 = 0;
function loadprealign_Callback(~,~) 
    
if  pm1.Value == 1
[filenamepreal,pathreal] = uigetfile('*.mat*','Load 2 color processed file ...');
    tmp = load(strcat(pathreal,flagslash,filenamepreal));
    dataout1 = tmp.dataout1;
    dataout2 = tmp.dataout2;
    dim = tmp.dim;
    dataoutshift1 = tmp.dataoutshift1;
    leftrightcount = tmp.leftrightcount;
    updowncount = tmp.updowncount;
    zcount = tmp.zcount; 
    densitythr1 = tmp.densitythr1;
    densitythr2 = tmp.densitythr2; 
    textbox_minD2.String = num2str(densitythr2);
    textbox_minD1.String = num2str(densitythr1);
    try
    namech2 = tmp.namech2;
    namech1 = tmp.namech1; 
    catch
            namech2 = tmp.tmp568;
    namech1 = tmp.tmp647; 
    end
     flagalign =0;
    try
        photonTH1 = tmp.photonTH1;
        locprec1 = tmp.locprec1;
        photonTH2 = tmp.photonTH2;
        locprec2 = tmp.locprec2;
    catch
        photonTH1 = min(dataout1(:,3));
        locprec1 = max(dataout1(:,4));
        photonTH2 = min(dataout2(:,3));
        locprec2 = max(dataout2(:,4));
    end
        textbox_minP2.String = photonTH2;  
        textbox_minLP2.String = locprec2;
        textbox_minP1.String = photonTH1;  
        textbox_minLP1.String = locprec1;
    try
        Vp2 = tmp.Vp2;
        Vp1 = tmp.Vp1;
        Dp2 = tmp.Dp2;
        Dp1 = tmp.Dp1;
    catch exception
         msgText = getReport(exception);
    end
    textbox_meanDen1.String = num2str(mean(Dp1));
    textbox_medianDen1.String = num2str(median(Dp1));
    textbox_minDen1.String = num2str(min(Dp1));
    textbox_maxDen1.String = num2str(max(Dp1));
    textbox_meanDen2.String = num2str(mean(Dp2));
    textbox_medianDen2.String = num2str(median(Dp2));
    textbox_minDen2.String = num2str(min(Dp2));
    textbox_maxDen2.String = num2str(max(Dp2));
    visu1 = 1;
    visu2 = 1;
     if ~isempty(leftrightcount) | ~isempty(updowncount) | ~isempty(zcount)
        flagalign = 1;
    else
        flagalign = 0;
    end  
    cla(ha,'reset')
    violet = eval(colch1.String);
    green = eval(colch2.String);
    if isempty(dataoutshift1)
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    else
        plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    end
    set(ha,'NextPlot','add');%hold on;
    plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
    disp('Loading finished')
elseif  pm1.Value == 5 
    [filenamepreal,pathreal] = uigetfile('*.mat*','Load 3 color processed file ...');
    tmp = load(strcat(pathreal,flagslash,filenamepreal));
    dataout1 = tmp.dataout1;
    dataout2 = tmp.dataout2;
    dim = tmp.dim;
    dataoutshift1 = tmp.dataoutshift1;
    leftrightcount = tmp.leftrightcount;
    updowncount = tmp.updowncount;
    zcount = tmp.zcount; 
    densitythr1 = tmp.densitythr1;
    densitythr2 = tmp.densitythr2; 
    textbox_minD2.String = num2str(densitythr2);
    textbox_minD1.String = num2str(densitythr1);
    try
    namech2 = tmp.namech2;
    namech1 = tmp.namech1; 
    catch
            namech2 = tmp.tmp568;
    namech1 = tmp.tmp647; 
    end
     flagalign =0;
    try
        photonTH1 = tmp.photonTH1;
        locprec1 = tmp.locprec1;
        photonTH2 = tmp.photonTH2;
        locprec2 = tmp.locprec2;
    catch
        photonTH1 = min(dataout1(:,3));
        locprec1 = max(dataout1(:,4));
        photonTH2 = min(dataout2(:,3));
        locprec2 = max(dataout2(:,4));
    end
        textbox_minP2.String = photonTH2;  
        textbox_minLP2.String = locprec2;
        textbox_minP1.String = photonTH1;  
        textbox_minLP1.String = locprec1;
    try
        Vp2 = tmp.Vp2;
        Vp1 = tmp.Vp1;
        Dp2 = tmp.Dp2;
        Dp1 = tmp.Dp1;
    catch exception
         msgText = getReport(exception);
    end
    textbox_meanDen1.String = num2str(mean(Dp1));
    textbox_medianDen1.String = num2str(median(Dp1));
    textbox_minDen1.String = num2str(min(Dp1));
    textbox_maxDen1.String = num2str(max(Dp1));
    textbox_meanDen2.String = num2str(mean(Dp2));
    textbox_medianDen2.String = num2str(median(Dp2));
    textbox_minDen2.String = num2str(min(Dp2));
    textbox_maxDen2.String = num2str(max(Dp2));
    visu1 = 1;
    visu2 = 1;
     if ~isempty(leftrightcount) | ~isempty(updowncount) | ~isempty(zcount)
        flagalign = 1;
    else
        flagalign = 0;
    end  
    cla(ha,'reset')
    violet = eval(colch1.String);
    green = eval(colch2.String);
    if isempty(dataoutshift1)
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    else
        plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    end
    set(ha,'NextPlot','add');%hold on;
    plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
dataout3 = tmp.dataout3;
dataoutshift3 = tmp.dataoutshift3;
dim = tmp.dim;
densitythr3 = tmp.densitythr3;
% textbox_minD3.String = num2str(densitythr3);
namech3 = tmp.namech3; 
try
    photonTH3 = tmp.photonTH3;
    locprec3 = tmp.locprec3;
catch
    photonTH3 = min(dataout3(:,3));
    locprec3 = max(dataout3(:,4));
end
%     textbox_minP3.String = photonTH3;  
%     textbox_minLP3.String = locprec3;
try
    Vp3 = tmp.Vp3;
    Dp3 = tmp.Dp3;
catch exception
     msgText = getReport(exception);
end
% textbox_meanDen3.String = num2str(mean(Dp3));
% textbox_medianDen3.String = num2str(median(Dp3));
% textbox_minDen3.String = num2str(min(Dp3));
% textbox_maxDen3.String = num2str(max(Dp3));
visu3 = 3;

    leftrightcount3 = tmp.leftrightcount3;
    updowncount3 = tmp.updowncount3;
    zcount3 = tmp.zcount3; 
    yellow = eval(colch3.String);
    if ~isempty(leftrightcount3) | ~isempty(updowncount3) | ~isempty(zcount3)
        flagalign3 = 1;
    else
        flagalign3 = 0;
    end  

    if isempty(dataoutshift3)
        plot(dataout3(:,1),dataout3(:,2),'.g','Color',yellow,'Parent', ha);   
    else
        plot(dataoutshift3(:,1),dataoutshift3(:,2),'.g','Color',yellow,'Parent', ha);   
    end

disp('Loading finished')
    
end
end
%% re-threshold

s_rethr = s_loadprealign + [pbw+pbs 0 0 0];            
uicontrol('Style','pushbutton','String','Re-threshold',...
          'Position',s_rethr,...
           'Callback',@rethr_Callback); 
       %%
function rethr_Callback(~,~)

cla(ha,'reset')
set(ha,'NextPlot','add');%hold on;hold on;
    violet = eval(colch1.String);
    green = eval(colch2.String);
     yellow = eval(colch3.String);
if pm1.Value == 1
    photonTH1 = eval(textbox_minP1.String);  
    locprec1 = eval(textbox_minLP1.String);
    densitythr1 = eval(textbox_minD1.String); 
    try
    tmpch1 = load(strcat(pathreal,namech1));
    catch
    tmpch1 = load(strcat(namech1));
    end
    [dataout1,densitythr1,dim,Vp1,Dp1,avDp1,medDp1,minDp1,maxDp1] = ...
        voronoiData(tmpch1,photonTH1,locprec1,densitythr1,[],[],[]);
    textbox_minD1.String = num2str(densitythr1);
    textbox_meanDen1.String = num2str(avDp1);
    textbox_medianDen1.String = num2str(medDp1);
    textbox_minDen1.String = num2str(minDp1);
    textbox_maxDen1.String = num2str(maxDp1);
    if visu1 && flagalign
        dataoutshift1 = dataout1; 
         if ~isempty(leftrightcount)
        dataoutshift1(:,1) = dataoutshift1(:,1) - leftrightcount;
         end
         if ~isempty(updowncount)
        dataoutshift1(:,2) = dataoutshift1(:,2) - updowncount;
         end
        if dim == 3 & ~isempty(zcount)
         dataoutshift1(:,5) = dataoutshift1(:,5) - zcount;
        end
         plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    else
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    end
    disp('Visualization chanel 1 finished')
    try
    tmpch2 = load(strcat(pathreal,namech2));
    catch
    tmpch2 = load(strcat(namech2));  
    end
    photonTH2 = eval(textbox_minP2.String);  
    locprec2 = eval(textbox_minLP2.String);  
    densitythr2 = eval(textbox_minD2.String); 
    [dataout2,densitythr2,dim,Vp2,Dp2,avDp2,medDp2,minDp2,maxDp2] = ...
        voronoiData(tmpch2,photonTH2,locprec2,densitythr2,[],[],[]);
    textbox_minD2.String = num2str(densitythr2);
    plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', ha)
    textbox_meanDen2.String = num2str(avDp2);
    textbox_medianDen2.String = num2str(medDp2);
    textbox_minDen2.String = num2str(minDp2);
    textbox_maxDen2.String = num2str(maxDp2);
    visu2 = 1;
        disp('Visualization chanel 2 finished')
        
     elseif  pm1.Value == 2 
    photonTH1 = eval(textbox_minP1.String);  
    locprec1 = eval(textbox_minLP1.String);
    densitythr1 = eval(textbox_minD1.String); 
    try
    tmpch1 = load(strcat(pathreal,namech1));
    catch
    tmpch1 = load(strcat(namech1));
    end
    [dataout1,densitythr1,dim,Vp1,Dp1,avDp1,medDp1,minDp1,maxDp1] = ...
        voronoiData(tmpch1,photonTH1,locprec1,densitythr1,[],[],[]);
    textbox_minD1.String = num2str(densitythr1);
    textbox_meanDen1.String = num2str(avDp1);
    textbox_medianDen1.String = num2str(medDp1);
    textbox_minDen1.String = num2str(minDp1);
    textbox_maxDen1.String = num2str(maxDp1);
    if visu1 && flagalign
        dataoutshift1 = dataout1; 
         if ~isempty(leftrightcount)
        dataoutshift1(:,1) = dataoutshift1(:,1) - leftrightcount;
         end
         if ~isempty(updowncount)
        dataoutshift1(:,2) = dataoutshift1(:,2) - updowncount;
         end
        if dim == 3 & ~isempty(zcount)
         dataoutshift1(:,5) = dataoutshift1(:,5) - zcount;
        end
         plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    else
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    end
    disp('Visualization chanel 1 finished')
elseif pm1.Value == 3 
    try
    tmpch2 = load(strcat(pathreal,namech2));
    catch
    tmpch2 = load(strcat(namech2));  
    end
    photonTH2 = eval(textbox_minP2.String);  
    locprec2 = eval(textbox_minLP2.String);  
    densitythr2 = eval(textbox_minD2.String); 
    [dataout2,densitythr2,dim,Vp2,Dp2,avDp2,medDp2,minDp2,maxDp2] = ...
        voronoiData(tmpch2,photonTH2,locprec2,densitythr2,[],[],[]);
    textbox_minD2.String = num2str(densitythr2);
    plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', ha)
    textbox_meanDen2.String = num2str(avDp2);
    textbox_medianDen2.String = num2str(medDp2);
    textbox_minDen2.String = num2str(minDp2);
    textbox_maxDen2.String = num2str(maxDp2);
    
disp('Visualization chanel 2 finished')
elseif pm1.Value == 5
    photonTH1 = eval(textbox_minP1.String);  
    locprec1 = eval(textbox_minLP1.String);
    densitythr1 = eval(textbox_minD1.String); 
    try
    tmpch1 = load(strcat(pathreal,namech1));
    catch
    tmpch1 = load(strcat(namech1));
    end
    [dataout1,densitythr1,dim,Vp1,Dp1,avDp1,medDp1,minDp1,maxDp1] = ...
        voronoiData(tmpch1,photonTH1,locprec1,densitythr1,[],[],[]);
    textbox_minD1.String = num2str(densitythr1);
    textbox_meanDen1.String = num2str(avDp1);
    textbox_medianDen1.String = num2str(medDp1);
    textbox_minDen1.String = num2str(minDp1);
    textbox_maxDen1.String = num2str(maxDp1);
    if visu1 && flagalign
        dataoutshift1 = dataout1; 
         if ~isempty(leftrightcount)
        dataoutshift1(:,1) = dataoutshift1(:,1) - leftrightcount;
         end
         if ~isempty(updowncount)
        dataoutshift1(:,2) = dataoutshift1(:,2) - updowncount;
         end
        if dim == 3 & ~isempty(zcount)
         dataoutshift1(:,5) = dataoutshift1(:,5) - zcount;
        end
         plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    else
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    end
    disp('Visualization chanel 1 finished')
    try
    tmpch2 = load(strcat(pathreal,namech2));
    catch
    tmpch2 = load(strcat(namech2));  
    end
    photonTH2 = eval(textbox_minP2.String);  
    locprec2 = eval(textbox_minLP2.String);  
    densitythr2 = eval(textbox_minD2.String); 
    [dataout2,densitythr2,dim,Vp2,Dp2,avDp2,medDp2,minDp2,maxDp2] = ...
        voronoiData(tmpch2,photonTH2,locprec2,densitythr2,[],[],[]);
    textbox_minD2.String = num2str(densitythr2);
    plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', ha)
    textbox_meanDen2.String = num2str(avDp2);
    textbox_medianDen2.String = num2str(medDp2);
    textbox_minDen2.String = num2str(minDp2);
    textbox_maxDen2.String = num2str(maxDp2);
    visu2 = 1;
        disp('Visualization chanel 2 finished')
        
        
    try
    tmpch3 = load(strcat(pathreal,namech3));
    catch
    tmpch3 = load(strcat(namech2));  
    end
    photonTH3 = eval(textbox_minP2.String);  
    locprec3 = eval(textbox_minLP2.String);  
    densitythr3 = eval(textbox_minD2.String); 
    [dataout3,densitythr3,dim,Vp3,Dp3,avDp3,medDp3,minDp3,maxDp3] = ...
        voronoiData(tmpch3,photonTH3,locprec3,densitythr3,[],[],[]);
%     textbox_minD2.String = num2str(densitythr3);
%     textbox_meanDen2.String = num2str(avDp2);
%     textbox_medianDen2.String = num2str(medDp2);
%     textbox_minDen2.String = num2str(minDp2);
%     textbox_maxDen2.String = num2str(maxDp2);
    visu3 = 1;
    if visu3 && flagalign3
        dataoutshift3 = dataout3; 
         if ~isempty(leftrightcount3)
        dataoutshift3(:,1) = dataoutshift3(:,1) - leftrightcount3;
         end
         if ~isempty(updowncount3)
        dataoutshift3(:,2) = dataoutshift3(:,2) - updowncount3;
         end
        if dim == 3 & ~isempty(zcount3)
         dataoutshift3(:,5) = dataoutshift3(:,5) - zcount3;
        end
         plot(dataoutshift3(:,1),dataoutshift3(:,2),'.g','Color',yellow,'Parent', ha);   
    else
        plot(dataout3(:,1),dataout3(:,2),'.g','Color',yellow,'Parent', ha);   
    end
end
end
%% save all
s_saveall = s_rethr + [pbw+pbs 0 0 0];            
uicontrol('Style','pushbutton','String','Save',...
           'Tag','saveall','Position',s_saveall,...
           'Callback',@saveall_Callback);   
function saveall_Callback(~,~)
    if ~isempty(filenamepreal)
        filenamesavealign = strcat('Corralign_',filenamepreal(1:end-4),'.mat');
    else
        filenamesavealign = strcat('Corralign_',namech1(1:end-4),'.mat');
    end
    if pm1.Value == 1
        uisave({'dataoutshift1','dataout2','dataout1','leftrightcount','updowncount','zcount',...
        'densitythr1','densitythr2','namech2','namech1','Dp2','Dp1','dim',...
        'Vp1','Vp2','locprec2','photonTH2','locprec1','photonTH1'},filenamesavealign) 
    elseif pm1.Value == 5
        uisave({'dataoutshift1','dataout2','dataout1','leftrightcount','updowncount','zcount',...
        'densitythr1','densitythr2','namech2','namech1','Dp2','Dp1','dim',...
        'Vp1','Vp2','locprec2','photonTH2','locprec1','photonTH1',...
        'densitythr3','namech3','Dp3','Vp3','locprec3','photonTH3','zcount3',...
        'flagalign3','dataout3','updowncount3','leftrightcount3','dataoutshift3'},filenamesavealign) 
    else
        ch = chnl;
        if chnl == 1           
         uisave({'dataout1','densitythr1','Vp1','dim','namech1','Dp1',...
             'ch','locprec1','photonTH1'},filenamesavealign) 
        elseif chnl == 2
         uisave({'dataout2','densitythr2','Vp2','dim','namech2','Dp2',...
             'ch','locprec2','photonTH2'},filenamesavealign) 
        end
    end
end
%% zoom button
s_zoom = s_saveall + [pbw+pbs 0 0 0];            
uicontrol( ...
    'Style', 'togglebutton', ...
    'Position', s_zoom, ...
    'String', 'Toggle Zoom', ...
    'Callback', {@myzoombutton,ha} ... % Pass along the handle structure as well as the default source and eventdata values
    ); 
function myzoombutton(source, ~,ha)

togglestate = source.Value;

switch togglestate
    case 1
        % Toggle on, turn on zoom
        zoom(ha, 'on')
    case 0
        % Toggle off, turn off zoom
        zoom(ha, 'off')
end
end
%% close all but not gui
s_closeall = s_zoom + [pbw+pbs 0 0 0];            
uicontrol('Style','pushbutton','String','Close all',...
          'Position',s_closeall,...
           'Callback',@closeall_Callback); 
function closeall_Callback(~,~)
set(f, 'HandleVisibility', 'off');
close all;
set(f, 'HandleVisibility', 'on');
end

%% polygonal regions of interest
flagroi = 0; nodes = []; in1 = []; in2 = [];
s_polyroi  =  s_closeall + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Freehand roi',...
           'Tag','polyroi','Position',s_polyroi,...
           'Callback',@plotroi_Callback);
polyreg = [];
function plotroi_Callback(~,~)
if visu1 | visu2
    
% prompt = {'Enter 1 for freehand, 0 for polyroi:'};
% title = 'Input';
% dims = [1 35];
% definput = {'1'};
% answer = inputdlg(prompt,title,dims,definput);
polyreg = 1;%str2num(answer{1});
n=1;
N = eval(polyroisegedit.String);
if N
flag = 0;
clear nodes in1 in2 flagroi
flagroi = 0; nodes = []; 
else
    flag = numel(nodes);
end
    while n == 1
        n = userAction('Do you want to define more masks by hand?','Exit segmentation');
            if n == 1
%                 
                if polyreg
                   h = imfreehand(ha);
                else
                    h = impoly(ha);
                end
                flag = flag + 1;
                nodes{flag} = getPosition(h);
                if visu1 && visu2
                    if flagalign
                        in1{flag} = inpolygon(dataoutshift1(:,1),dataoutshift1(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                    else
                        in1{flag} = inpolygon(dataout1(:,1),dataout1(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                    end
                     in2{flag} = inpolygon(dataout2(:,1),dataout2(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                end
                if visu1 && ~visu2
                     in1{flag} = inpolygon(dataout1(:,1),dataout1(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                end
                
                if visu2 && ~visu1
                in2{flag} = inpolygon(dataout2(:,1),dataout2(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                end
            end
    end 
    flagroi = 1;
else
    msgbox('Load 2 color Voronoi file ...')
end
disp('Poly roi plot finished')
end
%%
s_evalpolyroi  =  s_polyroi + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Eval. freehand roi',...
           'Tag','polyroi','Position',s_evalpolyroi,...
           'Callback',@evalpolyroi_Callback);
inroicount1 = [];
inroicount2 = [];
inroicount1over2 = [];
flagroieval = 0;
function evalpolyroi_Callback(~,~)
    
    if flagroi && (visu1 | visu2)
      if ~isempty(nodes) & isempty(in1)
             for flag = 1:numel(nodes)
                if visu1 && visu2
                    if flagalign
                        in1{flag} = inpolygon(dataoutshift1(:,1),dataoutshift1(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                    else
                        in1{flag} = inpolygon(dataout1(:,1),dataout1(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                    end
                     in2{flag} = inpolygon(dataout2(:,1),dataout2(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                end
                if visu1 && ~visu2
                     in1{flag} = inpolygon(dataout1(:,1),dataout1(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                end
                
                if visu2 && ~visu1
                in2{flag} = inpolygon(dataout2(:,1),dataout2(:,2),nodes{flag}(:,1),nodes{flag}(:,2));
                end
             end
          
      end
        
        
    inroicount1 = zeros(numel(nodes),1);
    inroicount2 = zeros(numel(nodes),1);
    inroicount1over2 = zeros(numel(nodes),1);
    
        for flag = 1:numel(nodes)
            if visu1 && visu2
                inroicount1(flag) = sum(in1{flag});
                inroicount2(flag) = sum(in2{flag});
                inroicount1over2(flag) = inroicount1(flag)./inroicount2(flag);
            elseif visu1 && ~visu2
               inroicount1(flag) = sum(in1{flag}); 
               inroicount1over2(flag) = inroicount1(flag);
            elseif visu2 && ~visu1
                inroicount2(flag) = sum(in2{flag});
                inroicount1over2(flag) = inroicount2(flag);
            end

        end
        flagroieval = 1;
        disp('Poly roi evaluation finished')
    end
end

%%
s_savepolyroi  =  s_evalpolyroi + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Save eval roi',...
           'Tag','savepolyroi','Position',s_savepolyroi,...
           'Callback',@savepolyroi_Callback);

function savepolyroi_Callback(~,~)
    
    if flagroi && (visu1 | visu2) && flagroieval
        savename = strcat(pathreal,flagslash,'polyroi',filenamepreal(end-5:end));
   
            if visu1 && visu2
                 uisave({'inroicount1','inroicount2','inroicount1over2','in2','in1','nodes'},savename);
            elseif visu1 && ~visu2
                     uisave({'inroicount1','inroicount1over2','in1','nodes'},savename);
            elseif visu2 && ~visu1
                  uisave({'inroicount2','inroicount1over2','in2','nodes'},savename);

            end
     disp('Poly roi saved')
    end
end
%% save poly roi only
s_saveonlyroi  =  s_savepolyroi + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Save only roi',...
           'Tag','saveonlypolyroi','Position',s_saveonlyroi,...
           'Callback',@saveonlyroi_Callback);

function saveonlyroi_Callback(~,~)
    
    if flagroi && (visu1 | visu2)
        savename = strcat(pathreal,flagslash,'mask',filenamepreal(end-5:end));
     uisave({'nodes'},savename);
     disp('Poly roi mask saved')
    end
end
%% load poly roi only
s_loadonlyroi  =  s_saveonlyroi + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Load only roi',...
           'Tag','loadonlypolyroi','Position',s_loadonlyroi,...
           'Callback',@loadonlyroi_Callback);

function loadonlyroi_Callback(~,~)
     [filename,path] = uigetfile('*.*','Select file with poly roi mask...');
     tmp = load(strcat(path,filename),'nodes');
     nodes = tmp.nodes;
     disp('Poly roi mask loaded')
     flagroi = 1;
     polyreg = 1;%str2num(answer{1});
end

%% load poly roi only
s_plotonlyroi  =  s_loadonlyroi + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Plot poly roi',...
           'Tag','plotpolyroi','Position',s_plotonlyroi,...
           'Callback',@displyonlyroi_Callback);

function displyonlyroi_Callback(~,~)
     if flagroi
     set(ha,'NextPlot','add')
     nnodes = numel(nodes);
     for i =1:nnodes
         plot(nodes{i}(:,1),nodes{i}(:,2),'-k','parent',ha);
     end
      disp('Poly roi mask plot')
     end
end
%% polygonal regions of interest
flagroi = 0; nodes = []; in1 = []; in2 = [];
s_polyroiseg  =  s_plotonlyroi + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Open-segment roi',...
           'Tag','polyroi','Position',s_polyroiseg,...
           'Callback',@plotroiseg_Callback);
       
s_polyroisegedit  =  s_polyroiseg - [0 pbh+pbs 0 0];  
polyroisegedit = uicontrol('Style','edit','String','1',...
           'Tag','editseg','Position',s_polyroisegedit);

function plotroiseg_Callback(~,~)
if visu1 | visu2
n=1;
% prompt = {'Enter 1 to start new plot, 0 to continue with previous:'};
% dlg_title = 'Input';
% num_lines = 1;
% defaultans = {'1'};
% answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
% N = str2num(answer{1});
N = eval(polyroisegedit.String);
if N
flag = 0;
clear nodes in1 in2 flagroi
flagroi = 0; nodes = []; 
else
    flag = numel(nodes);
end
    while n == 1
        n = userAction('Do you want to define more masks by hand?','Exit segmentation');
            if n == 1
%                 h = impoly(ha);
                 h = impoly(ha,'Closed',false);
                flag = flag + 1;
                nodes{flag} = getPosition(h);
            end
    end 
    flagroi = 1;
else
    msgbox('Load 2 color Voronoi file ...')
end
disp('Poly roi plot finished')
end
%% remove segment roi
s_deleteroiseg  =  s_polyroiseg + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Delete segment roi',...
           'Tag','deleteroi','Position',s_deleteroiseg,...
           'Callback',@deleteroiseg_Callback);
       
s_polyroisegdelete  =  s_deleteroiseg - [0 pbh+pbs 0 0];  
polyroisegdelete = uicontrol('Style','edit','String','[1]',...
       'Tag','deleteseg','Position',s_polyroisegdelete);
   
function deleteroiseg_Callback(~,~)
%     prompt = {'Enter segment roi index to be removed:'};
% dlg_title = 'Input';
% num_lines = 1;
% defaultans = {'[1]'};
% answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
% N = str2num(answer{1});
N = eval(polyroisegdelete.String);
for ii = 1:numel(N)
if numel(nodes) >= N(ii)
nodes{N(ii)} = [];
Rnew = nodes(~cellfun(@isempty, nodes));
clear nodes
nodes = Rnew;
fprintf('Roi number %d deleted',ii)
end
end
end
%% load poly roi only
s_plotonlyroimidline  =  s_deleteroiseg + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Plot segment roi',...
           'Tag','plotpolyroi','Position',s_plotonlyroimidline,...
           'Callback',@displyonlyroimidlione_Callback);
uproi = [];downroi = [];

s_polyroisegplot  =  s_plotonlyroimidline - [0 pbh+pbs 0 0];  
polyroisegplot = uicontrol('Style','edit','String','1200',...
       'Tag','plotseg','Position',s_polyroisegplot);
   
function displyonlyroimidlione_Callback(~,~)
     if flagroi
         
N = eval(polyroisegplot.String);
     set(ha,'NextPlot','add')
     nnodes = numel(nodes);
     uproi = [];downroi = [];
     for kk =1:nnodes
         
    seg = nodes{kk};
        txt3 = num2str(kk);
    seg = nodes{kk};
t = text(seg(1,1),seg(1,2),txt3,'HorizontalAlignment','right');
t(1).Color = 'red';
t(1).FontSize = 20;
    np = numel(seg(:,1));
%     N = 1000;
  xy3 = size(seg);
  xy4 = size(seg);
    for i = 1:np
        if i < np
        xy1 = [seg(i,1),seg(i,2)];
        xy2 = [seg(i+1,1),seg(i+1,2)];
        [xy3(i,:),xy4(i,:)] = perCaps(xy1,xy2,N);
        else
           xy1 = [seg(i,1),seg(i,2)];
           xy2 = [seg(i-1,1),seg(i-1,2)];  
           [xy4(i,:),xy3(i,:)] = perCaps(xy1,xy2,N);
        end
    end

    uproi{kk} = [seg;flipud(xy3);seg(1,:)];
    downroi{kk} = [seg;flipud(xy4);seg(1,:)];

    plot(uproi{kk}(:,1),uproi{kk}(:,2),'.-b','LineWidth',2,'parent',ha)
    hold on;
    plot(downroi{kk}(:,1),downroi{kk}(:,2),'.--c','LineWidth',2,'parent',ha)
     end
      disp('Poly roi mask plot')
     end
end
%% save segment poly roi only
s_savesegmentroi  =  s_plotonlyroimidline + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Save segment roi',...
           'Tag','savesegroi','Position',s_savesegmentroi,...
           'Callback',@savesegmentroi_Callback);
ext1 = [];   inter1 = [];     ext2 = [];   inter2 = [];   
extTOint1 = [];
extTOint2 = [];
function savesegmentroi_Callback(~,~)
    
extTOint1 = zeros(numel(nodes),1);
extTOint2 = zeros(numel(nodes),1);
for kk = 1:numel(nodes)

% t(2:end).FontSize = 1;
    if visu1 && visu2
        if flagalign
            ext1{kk} = inpolygon(dataoutshift1(:,1),dataoutshift1(:,2),uproi{kk}(:,1),uproi{kk}(:,2));
            inter1{kk} = inpolygon(dataoutshift1(:,1),dataoutshift1(:,2),downroi{kk}(:,1),downroi{kk}(:,2));
        else
            ext1{kk} = inpolygon(dataout1(:,1),dataout1(:,2),uproi{kk}(:,1),uproi{kk}(:,2));
            inter1{kk} = inpolygon(dataout1(:,1),dataout1(:,2),downroi{kk}(:,1),downroi{kk}(:,2));
        end
         ext2{kk} = inpolygon(dataout2(:,1),dataout2(:,2),uproi{kk}(:,1),uproi{kk}(:,2));
         inter2{kk} = inpolygon(dataout2(:,1),dataout2(:,2),downroi{kk}(:,1),downroi{kk}(:,2));
         
         extTOint1(kk) = numel(find(ext1{kk}==1))/numel(find(inter1{kk}==1));
         extTOint2(kk) = numel(find(ext2{kk}==1))/numel(find(inter2{kk}==1));
         
    end

    if visu1 && ~visu2
     ext1{kk} = inpolygon(dataout1(:,1),dataout1(:,2),uproi{kk}(:,1),uproi{kk}(:,2));
     inter1{kk} = inpolygon(dataout1(:,1),dataout1(:,2),downroi{kk}(:,1),downroi{kk}(:,2));
      extTOint1(kk) = numel(find(ext1{kk}==1))/numel(find(inter1{kk}==1));
    end

    if visu2 && ~visu1
    ext2{kk} = inpolygon(dataout2(:,1),dataout2(:,2),uproi{kk}(:,1),uproi{kk}(:,2));
    inter2{kk} = inpolygon(dataout2(:,1),dataout2(:,2),downroi{kk}(:,1),downroi{kk}(:,2));
      extTOint2(kk) = numel(find(ext2{kk}==1))/numel(find(inter2{kk}==1));
    end
    
end
     savename = strcat(pathreal,flagslash,'ext2int',filenamepreal(end-5:end));
     uisave({'extTOint2','extTOint1','uproi','downroi','ext1','ext2','inter1','inter2','nodes'},savename);
     disp('Poly roi mask saved')
end
%% load list 2
s_overly  =  s_loadraw + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Scatter',...
           'Tag','overly','Position',s_overly,...
           'Callback',@overly_Callback);
function overly_Callback(~,~)
cla(ha,'reset')
violet = eval(colch1.String);
green = eval(colch2.String);
yellow = eval(colch3.String);
if pm1.Value == 1
      set(ha,'NextPlot','add');%hold on;
      plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha);  
    if flagalign
           plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha); 
    else
           plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    end
  
elseif pm1.Value == 2
     plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);  
     
elseif pm1.Value == 3
     plot(dataout2(:,1),dataout2(:,2),'.g','Color',green,'Parent', ha);  
elseif pm1.Value == 5
      set(ha,'NextPlot','add');%hold on;
      plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
    if flagalign
           plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha); 
    else
           plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    end
   
    
    
     if flagalign3
       plot(dataoutshift3(:,1),dataoutshift3(:,2),'.g','Color',yellow,'Parent', ha); 
     else

      plot(dataout3(:,1),dataout3(:,2),'.g','Color',yellow,'Parent', ha); 
    end
end
disp('scatter')
end
%% load list 2
NmaxY = 0;
s_overlyim  =  s_overly + [pbw+pbs 0 0 0];  
uicontrol('Style','pushbutton','String','Image',...
           'Tag','overlyim','Position',s_overlyim,...
           'Callback',@overlyim_Callback);
       
s_imscale = s_pm1 + [s_pm1(3)+pbs 0 7*pbs 0];              
imscale = uicontrol('Style','edit','String','[0 50 0 50 0 5 5 0 1]',...
'Tag','imscale','Position',s_imscale);
 imsc = [];imscaleflag = 0;
imvisu1 = 0;plotscatter = 0;
imvisu2 = 0;
function overlyim_Callback(~,~)
imsc = eval(imscale.String);
pix = eval(textbox_minPIX1.String);
Nmax = eval(textbox_minIM1.String)*pix;
NmaxY = eval(textbox_minIM1y.String)*pix;
plotscatter = imsc(8);
imscaleflag = imsc(9);

violet = eval(colch1.String);
green = eval(colch2.String);
if pm1.Value == 1
if imscaleflag
   z = 1;
else
   z=0;
end
cla(ha,'reset')

if flagalign
im1pw = scatt2im(dataoutshift1,pix,[Nmax,NmaxY],z);
else
im1pw = scatt2im(dataout1,pix,[Nmax,NmaxY],z);
end
im2pw = scatt2im(dataout2,pix,[Nmax,NmaxY],z);
% J = imadjust(im1pw,stretchlim(im1pw,[0.2,0.8]),[]);
clear imRGB

O11 = min(im1pw(:));
O21 = max(im1pw(:));
T11 = imsc(1);
T21 = imsc(2);

O12 = min(im2pw(:));
O22 = max(im2pw(:));
T12 = imsc(3);
T22 = imsc(4);

imRGB(:,:,1) = (((im1pw - O11) .* (T21 - T11)) ./ (O21 - O11));
imRGB(:,:,2) = (((im2pw - O12) .* (T22 - T12)) ./ (O22 - O12));
imRGB(:,:,3) = imRGB(:,:,1);

imshow(imRGB,[imsc(5),imsc(6)],'Parent', ha);

set(ha,'NextPlot','add');
set(ha, 'YDir', 'normal');
if plotscatter
if flagalign
    plot(dataoutshift1(:,1)/pix,dataoutshift1(:,2)/pix,'.b','Color',violet,'Parent', ha);   
    plot(dataout2(:,1)/pix,dataout2(:,2)/pix,'.r','Color',green,'Parent', ha);  
else 
    plot(dataout1(:,1)/pix,dataout1(:,2)/pix,'.b','Color',violet,'Parent', ha);    
    plot(dataout2(:,1)/pix,dataout2(:,2)/pix,'.r','Color',green,'Parent', ha);  
end
end
imvisu1 = 1;
imvisu2 = 1;
elseif pm1.Value == 2 
    clearaxis = clearax.Value;      
    if clearaxis
        cla(ha,'reset')
    end
if imscaleflag
   z = 1;
else
   z=0;
end

    if flagalign
        im1pw = scatt2im(dataoutshift1,pix,[Nmax,NmaxY],z);  
    else
        im1pw = scatt2im(dataout1,pix,[Nmax,NmaxY],z); 
    end
    O11 = min(im1pw(:));
    O21 = max(im1pw(:));
    T11 = imsc(1);
    T21 = imsc(2);
   clear imRGB
   imRGB = ((im1pw - O11) .* (T21 - T11)) ./ (O21 - O11);
   imshow(imRGB,[imsc(5),imsc(6)],'Parent', ha);
   set(ha,'NextPlot','add');
   set(ha, 'YDir', 'normal');
   if plotscatter
       if flagalign
            plot(dataoutshift1(:,1)/pix,dataoutshift1(:,2)/pix,'.b','Color',violet,'Parent', ha);   
       else
            plot(dataout1(:,1)/pix,dataout1(:,2)/pix,'.b','Color',violet,'Parent', ha);   
       end
   end
   imvisu1 = 1;
elseif pm1.Value == 3   
    clearaxis = clearax.Value;      
    if clearaxis
        cla(ha,'reset')
    end
if imscaleflag
   z = 1;
else
   z=0;
end
    im2pw = scatt2im(dataout2,pix,[Nmax,NmaxY],z);    
    O11 = min(im2pw(:));
    O21 = max(im2pw(:));
    T11 = imsc(3);
    T21 = imsc(4);
   clear imRGB
   imRGB = ((im2pw - O11) .* (T21 - T11)) ./ (O21 - O11);
   imshow(imRGB,[imsc(5),imsc(7)],'Parent', ha);
   set(ha,'NextPlot','add');
   set(ha, 'YDir', 'normal');
   if plotscatter
        plot(dataout2(:,1)/pix,dataout2(:,2)/pix,'.r','Color',green,'Parent', ha);  
   end
imvisu2 = 1;
end
end
%% creating mask
s_correctmaskpb = s_overlyim + [pbw+pbs 0 0 0];
uicontrol('Style','pushbutton','String','Draw mask',...
           'Tag','drawmask','Position',s_correctmaskpb,...
           'Callback',@drawmask_Callback);
function drawmask_Callback(~,~)
n=1;
N = eval(textbox_minIM1.String);
totalMask1 = zeros(N,N);
    while(n == 1)||(n == 2)
        n = userAction('Do you want to define more masks by hand?','Remove 1s','Exit segmentation');
            if n == 1
                h = imfreehand(ha);
                BW = createMask( h ); 
                 totalMask1 = totalMask1|BW;
                
            elseif n == 2
                h = imfreehand(ha);
                BW = createMask( h );
                totalMask1 = totalMask1.*(~BW);
               
            elseif n == 3
                return;
            end
    end 
    flagmask = 1;
end
%% chose color for chanel 1 and 2
s_cch1  =  [s_imscale(1)+s_imscale(3)+pbs s_imscale(2) pbw pbh]; 
uicontrol('Style','text',...
                'String','Color 1',...
                'Position',s_cch1);
s_ech1 = s_cch1 + [pbw+3*pbs 0 10*pbs 0];              
colch1 = uicontrol('Style','edit','String','[160,121,167]/255',...
'Tag','ech1','Position',s_ech1);
 % [23,183,105]/255   [160,121,167]/255
s_cch2  =  [s_ech1(1)+s_ech1(3)+2*pbs s_ech1(2) pbw pbh]; 
uicontrol('Style','text',...
                'String','Color 2',...
                'Position',s_cch2);
s_ech2 = s_cch2 + [pbw+3*pbs 0 10*pbs 0];             
colch2 = uicontrol('Style','edit','String','[23,183,105]/255',...
'Tag','ech2','Position',s_ech2);

s_cch3  =  [s_ech2(1)+s_ech2(3)+2*pbs s_ech2(2) pbw pbh]; 
uicontrol('Style','text',...
                'String','Color 3',...
                'Position',s_cch3);
s_ech3 = s_cch3 + [pbw+3*pbs 0 10*pbs 0];             
colch3 = uicontrol('Style','edit','String','[228,117,0]/255',...
'Tag','ech2','Position',s_ech3);
%% saveing mask
s_savemask = s_correctmaskpb + [pbw+pbs 0 0 0];
uicontrol('Style','pushbutton','String','Save mask',...
           'Tag','savemask','Position',s_savemask,...
           'Callback',@savemask_Callback);
    function savemask_Callback(~,~)
        if flagmask 
            filename = 'mask.mat';
            uisave('totalMask1',filename) 
            disp('Mask saved')
        end  
    end
%% load mask
s_loadmask = s_savemask + [pbw+pbs 0 0 0];
uicontrol('Style','pushbutton','String','Load mask',...
           'Tag','loadmask','Position',s_loadmask,...
           'Callback',@loadmask_Callback);
B = [];im1visu = 0;im2visu = 0;
function loadmask_Callback(~,~)
imsc = eval(imscale.String);
pix = eval(textbox_minPIX1.String);
Nmax = eval(textbox_minIM1.String)*pix;
NmaxY = eval(textbox_minIM1y.String)*pix;
scfac = imsc(8);
scfac2 = imsc(9);
plotscatter = imsc(8);
imscaleflag = imsc(9);

[filename,path] = uigetfile('*.*','Select file with mask...');
tmp = load(strcat(path,filename),'totalMask1');
totalMask1 = tmp.totalMask1;
violet = eval(colch1.String);
green = eval(colch2.String);

if pm1.Value == 1
cla(ha,'reset')
set(ha,'NextPlot','add');
set(ha, 'YDir', 'normal');
if imscaleflag
   z = 1;
else
   z=0;
end
if flagalign
im1pw = scatt2im(dataoutshift1,pix,[Nmax,NmaxY],z);
else
im1pw = scatt2im(dataout1,pix,[Nmax,NmaxY],z);
end
im2pw = scatt2im(dataout2,pix,[Nmax,NmaxY],z);
clear imRGB

O11 = min(im1pw(:));
O21 = max(im1pw(:));
T11 = imsc(1);
T21 = imsc(2);

O12 = min(im2pw(:));
O22 = max(im2pw(:));
T12 = imsc(3);
T22 = imsc(4);

imRGB(:,:,1) = (((im1pw - O11) .* (T21 - T11)) ./ (O21 - O11));
imRGB(:,:,2) = (((im2pw - O12) .* (T22 - T12)) ./ (O22 - O12));
imRGB(:,:,3) = imRGB(:,:,1);

imshow(imRGB,[imsc(5),imsc(6)],'Parent', ha);

set(ha,'NextPlot','add');
set(ha, 'YDir', 'normal');
if plotscatter
if flagalign
    plot(dataoutshift1(:,1)/pix,dataoutshift1(:,2)/pix,'.b','Color',violet,'Parent', ha);   
    plot(dataout2(:,1)/pix,dataout2(:,2)/pix,'.r','Color',green,'Parent', ha);  
else 
    plot(dataout1(:,1)/pix,dataout1(:,2)/pix,'.b','Color',violet,'Parent', ha);    
    plot(dataout2(:,1)/pix,dataout2(:,2)/pix,'.r','Color',green,'Parent', ha);  
end
end
imvisu1 = 1;
imvisu2 = 1;
elseif pm1.Value == 2
    
    clearaxis = clearax.Value;      
    if clearaxis
        cla(ha,'reset')
    end
    if imscaleflag
       z = 1;
    else
       z=0;
    end


    if flagalign
        im1pw = scatt2im(dataoutshift1,pix,[Nmax,NmaxY],z);  
    else
        im1pw = scatt2im(dataout1,pix,[Nmax,NmaxY],z); 
    end
    O11 = min(im1pw(:));
    O21 = max(im1pw(:));
    T11 = imsc(1);
    T21 = imsc(2);
   clear imRGB
   imRGB = ((im1pw - O11) .* (T21 - T11)) ./ (O21 - O11);
   imshow(imRGB,[imsc(5),imsc(6)],'Parent', ha);
   set(ha,'NextPlot','add');
   set(ha, 'YDir', 'normal');
   if plotscatter
       if flagalign
            plot(dataoutshift1(:,1)/pix,dataoutshift1(:,2)/pix,'.b','Color',violet,'Parent', ha);   
       else
            plot(dataout1(:,1)/pix,dataout1(:,2)/pix,'.b','Color',violet,'Parent', ha);   
       end
   end
   imvisu1 = 1;
elseif pm1.Value == 3
    
    clearaxis = clearax.Value;      
    if clearaxis
        cla(ha,'reset')
    end
    if imscaleflag
       z = 1;
    else
       z=0;
    end

    im2pw = scatt2im(dataout2,pix,[Nmax,NmaxY],z);   
    O11 = min(im2pw(:));
    O21 = max(im2pw(:));
    T11 = imsc(1);
    T21 = imsc(2);
   clear imRGB
   imRGB = ((im2pw - O11) .* (T21 - T11)) ./ (O21 - O11);
   imshow(imRGB,[imsc(5),imsc(7)],'Parent', ha);
   set(ha,'NextPlot','add');
   set(ha, 'YDir', 'normal');
   imvisu2 = 1;
end

B = bwboundaries(totalMask1);
for i = 1:numel(B)
   plot(B{i}(:,2),B{i}(:,1),'.r')   
end
end

%% cropped image
% croped axis
%cropped 1 axes
poshacrop1 = [left_ha+width_ha+1.3*pbw,bottom_ha + 1.45*floor(height_ha/3) - pbh,floor(width_ha/3),floor(height_ha/3)];
hacrop1 = axes('Units','pixels','Position',poshacrop1);
set(hacrop1,'YTick',[]);
set(hacrop1,'XTick',[]);

s_irec = [s_loadmask(1)+s_loadmask(3)+pbs s_loadmask(2) pbw pbh];             
uicontrol('Style','pushbutton','String','rect roi',...
'Tag','imrec','Position',s_irec,...
'Callback',@imrect_Callback);

s_txtbox_roi = s_irec + [pbw+pbs 0 0+pbw 0]+[0 0 8*pbs 0];             
iroi   = uicontrol('Style','edit','String','[10000 10000 1000 1000]',...
'Tag','roisize','Position',s_txtbox_roi);


s_figsize = s_txtbox_roi + [s_txtbox_roi(3)+pbs 0 -12*pbs 0];             
ifig   = uicontrol('Style','edit','String','[500 500]',...
'Position',s_figsize);
s_saveim = [s_figsize(1)+s_figsize(3)+pbs s_figsize(2) pbw pbh];             
uicontrol('Style','pushbutton','String','Save image',...
'Tag','saveimage','Position',s_saveim,...
'Callback',@saveimage_Callback);
%%
function saveimage_Callback(~,~)
    if pm1.Value == 1 & imvisu1 & imvisu2
        uisave({'imRGB','im1pw','im2pw','imsc'},'imageC12.mat')
    elseif pm1.Value == 2 & imvisu1
        uisave({'imRGB','im1pw','imsc'},'imageCh1.mat')
    elseif pm1.Value == 3 & imvisu2
          uisave({'imRGB','im2pw','imsc'},'imageCh2.mat')
    end  
end
%%
s_savexlsx = s_saveim + [pbw+pbs 0 0 0];             
uicontrol('Style','pushbutton','String','Export',...
'Tag','saveimage','Position',s_savexlsx,...
'Callback',@savetxt_Callback);
function savetxt_Callback(~,~)
prompt = {'Enter the variable name to export',...
'Enter 1 to load a variable, 0 is the variable already exist in the memory'};
dlg_title = 'Export files';
num_lines = 1;
defaultans = {'dataout1','0'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
var{1} = answer{1};
logfl = str2num(answer{2});
varname = var{1};
clear var
if logfl
    [FileName,PathName,FilterIndex] = uigetfile('*.mat','Get a file with the variable you want to save');
    if ~ismac
        flagslash = '\'; 
    else
        flagslash = '/';
    end
    
    tmp = load(strcat(PathName,flagslash,FileName),varname);
    T = table(eval(strcat('tmp.',varname)));
    writetable(T,varname,'WriteVariableNames',false,'Delimiter','\t'); %,'Range','D1'
else
    T = table(eval(varname));
    writetable(T,varname,'WriteVariableNames',false,'Delimiter','\t'); %,'Range','D1'
end
end
%%
function imrect_Callback(~,~)
    pos0 = eval(iroi.String);
    hrect = imrect(ha,pos0);
    set(hrect,'tag','roim');
    api = iptgetapi(hrect);
    fcn = makeConstrainToRectFcn('imrect',get(ha,'XLim'),get(ha,'YLim'));
    api.setPositionConstraintFcn(fcn);
    
    pos = getPosition(hrect);
    pos = round(pos);
    cla(hacrop1,'reset')
    violet = eval(colch1.String);
    green = eval(colch2.String);
     violet = eval(colch1.String);
    yellow = eval(colch3.String);
    if pm1.Value == 1
    if flagalign
       plot(dataoutshift1(:,1),dataoutshift1(:,2),'.','Color',violet,'Parent', hacrop1);    
    else 
       plot(dataout1(:,1),dataout1(:,2),'.','Color',violet,'Parent', hacrop1);    
    end
     set(hacrop1,'NextPlot','add');
     plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', hacrop1); 
     
    elseif pm1.Value == 5
    if flagalign
       plot(dataoutshift1(:,1),dataoutshift1(:,2),'.','Color',violet,'Parent', hacrop1);    
    else 
       plot(dataout1(:,1),dataout1(:,2),'.','Color',violet,'Parent', hacrop1);    
    end
    
     set(hacrop1,'NextPlot','add');
     plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', hacrop1);  
     if flagalign3
       plot(dataoutshift3(:,1),dataoutshift3(:,2),'.','Color',yellow,'Parent', hacrop1);    
    else 
       plot(dataout3(:,1),dataout3(:,2),'.','Color',yellow,'Parent', hacrop1);    
    end
     
    elseif pm1.Value == 2
        if flagalign
           plot(dataoutshift1(:,1),dataoutshift1(:,2),'.','Color',violet,'Parent', hacrop1);    
        else
        plot(dataout1(:,1),dataout1(:,2),'.','Color',violet,'Parent', hacrop1);  
        end
        set(hacrop1,'NextPlot','add');
    elseif pm1.Value == 3

        plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', hacrop1);  
        set(hacrop1,'NextPlot','add');
    end
    addNewPositionCallback(hrect,@(pos) title(mat2str(pos,3)));
    set(hacrop1,'xlim',[pos(1),pos(1)+pos(3)])
    set(hacrop1,'ylim',[pos(2),pos(2)+pos(4)])
    set(hacrop1,'YTick',[]);
    set(hacrop1,'XTick',[]);
    api.addNewPositionCallback(@newpos);
end
function newpos(pos)
    cla(hacrop1,'reset')
    violet = eval(colch1.String);
    green = eval(colch2.String);
    if pm1.Value == 1
        if flagalign
           plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', hacrop1);    
        else 
           plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', hacrop1);    
        end
     set(hacrop1,'NextPlot','add');%  hold on;
     plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', hacrop1); 
         elseif pm1.Value == 5
    if flagalign
       plot(dataoutshift1(:,1),dataoutshift1(:,2),'.','Color',violet,'Parent', hacrop1);    
    else 
       plot(dataout1(:,1),dataout1(:,2),'.','Color',violet,'Parent', hacrop1);    
    end
    
     set(hacrop1,'NextPlot','add');
     plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', hacrop1);  
     if flagalign3
       plot(dataoutshift3(:,1),dataoutshift3(:,2),'.','Color',yellow,'Parent', hacrop1);    
    else 
       plot(dataout3(:,1),dataout3(:,2),'.','Color',yellow,'Parent', hacrop1);    
    end
    elseif pm1.Value == 2
        if flagalign
           plot(dataoutshift1(:,1),dataoutshift1(:,2),'.','Color',violet,'Parent', hacrop1);    
        else
        plot(dataout1(:,1),dataout1(:,2),'.','Color',violet,'Parent', hacrop1);  
        end
    set(hacrop1,'NextPlot','add');
    elseif pm1.Value == 3
        plot(dataout2(:,1),dataout2(:,2),'.','Color',green,'Parent', hacrop1);  
        set(hacrop1,'NextPlot','add');
    end
     set(hacrop1,'xlim',[pos(1),pos(1)+pos(3)])
    set(hacrop1,'ylim',[pos(2),pos(2)+pos(4)])
    set(hacrop1,'YTick',[]);
    set(hacrop1,'XTick',[]);
end
% 
% function ClearLinesFromAxes(ha)
% axesHandlesToChildObjects = findobj(ha,'tag','roim');
%     if ~isempty(axesHandlesToChildObjects)
%         delete(axesHandlesToChildObjects);
%     end	
% end
%% 3d voronoi

s_roi3dscatter = s_applyalign - [0 pbh+pbs 0 0];            
uicontrol('Style','pushbutton','String','3d scatter',...
           'Tag','roi3dvoronoi','Position',s_roi3dscatter,...
           'Callback',@roi3dscatter_Callback);
       
Zsel3dscatter = uicontrol('Style','edit','String','[]',...
'Tag','Zsel3dscatter','Position',s_roi3dscatter + [pbw+pbs 0 pbw/2 0]);
%% 
function roi3dscatter_Callback(~,~)
if ~isempty(pos0)

pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
fig = figure;
ms = 10;
ax = axes;
set(ax,'NextPlot','add');%hold on;hold on;
violet = eval(colch1.String);
green = eval(colch2.String);
yellow =  eval(colch3.String);
Zval = eval(Zsel3dscatter.String);
zfilterval = zfilter.Value;
zmapval = zmap.Value;
nodeyesval = nodeyes.Value;
if pm1.Value == 1
  
    if flagalign
        dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    if sum(dat2(:,3)) & Zval & zfilterval
      dat1 = dat1(dat1(:,3)>Zval(1) & dat1(:,3)<Zval(2),:);  
      dat2 = dat2(dat2(:,3)>Zval(1) & dat2(:,3)<Zval(2),:);     
    end
    if ~isempty(polyreg) & nodeyesval
        [inpo1,onpo1] = inpolygon(dat1(:,1),dat1(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat1 = dat1(inpo1 | onpo1,:);
        [inpo2,onpo2] = inpolygon(dat2(:,1),dat2(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat2 = dat2(inpo2 | onpo2,:);
    end
    if zmapval
        % orange map
%        chigh = [255,161,21]/255;
%        clow = [102,64,8]/255;
%        mapUP = colormapCust( clow,chigh,256);     
         % violet map     
%        clow = [186,158,0]/255;
       chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
%        clow = [228,117,0]/255;
%        chigh = [164,0,232]/255;
       cmap = colormapCust( clow,chigh,256);
%        green  = [1,142,91]/255;
 green  = [0,63,42]/255;
%         cmap = AdvancedColormap('al');
     
        plot3dZmap(dat1,cmap,ax,'.',8)
          plot3(dat2(:,1),dat2(:,2),dat2(:,3),'.','MarkerSize',ms,'Color',green)  

%         cmap = AdvancedColormap('rb');
%         plot3dZmap(dat2,cmap,ax,'.',8);
    else
    
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),ms,violet,'filled') %,'markertype','.'
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),ms,green,'filled')
   
    end
    elseif pm1.Value == 5
  
    if flagalign
        dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    
    if flagalign3
        dat3 = dataoutshift3(dataoutshift3(:,1) <= xmax & dataoutshift3(:,1) >= xmin &...
        dataoutshift3(:,2) <= ymax & dataoutshift3(:,2) >= ymin,[1,2,5]);
    else
        dat3 = dataout3(dataout3(:,1) <= xmax & dataout3(:,1) >= xmin &...
        dataout3(:,2) <= ymax & dataout3(:,2) >= ymin,[1,2,5]);
    end

    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    if ~isempty(polyreg)  & nodeyesval
        [inpo1,onpo1] = inpolygon(dat1(:,1),dat1(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat1 = dat1(inpo1 | onpo1,:);
        [inpo2,onpo2] = inpolygon(dat2(:,1),dat2(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat2 = dat2(inpo2 | onpo2,:);
        [inpo3,onpo3] = inpolygon(dat3(:,1),dat3(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat3 = dat3(inpo3 | onpo3,:);
    end
    if sum(dat2(:,3)) & Zval & zfilterval
      dat1 = dat1(dat1(:,3)>Zval(1) & dat1(:,3)<Zval(2),:);  
      dat2 = dat2(dat2(:,3)>Zval(1) & dat2(:,3)<Zval(2),:);  
      dat3 = dat3(dat3(:,3)>Zval(1) & dat3(:,3)<Zval(2),:);  
    end
    if zmapval
           chigh = [186,158,255]/255;
       clow = [186,158,0]/255;
       
               chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
       cmap = colormapCust( clow,chigh,256);  
%         cmap = AdvancedColormap('al');
       plot3dZmap(dat1,cmap,ax,'.',8)
       green  = [1,142,91];
       plot3(dat2(:,1),dat2(:,2),dat2(:,3),'.','MarkerSize',ms,'Color',green)  
       plot3(dat3(:,1),dat3(:,2),dat3(:,3),'.','MarkerSize',ms,'Color','b')  
    else
        scatter3(dat1(:,1),dat1(:,2),dat1(:,3),ms,violet,'filled') %,'markertype','.'
        scatter3(dat2(:,1),dat2(:,2),dat2(:,3),ms,green,'filled')
        scatter3(dat3(:,1),dat3(:,2),dat3(:,3),ms,yellow,'filled')
    end

elseif pm1.Value == 2
    if flagalign
%     Vp1filt = Vp1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
%     dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);

    dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
    dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
%     Vp1filt = Vp1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
%     dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);

    dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
    dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
        if ~isempty(polyreg) & nodeyesval
        [inpo1,onpo1] = inpolygon(dat1(:,1),dat1(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat1 = dat1(inpo1 | onpo1,:);
        end
     if sum(sum(dat1(:,3)) & Zval & zfilterval)
      dat1 = dat1(dat1(:,3)>Zval(1) & dat1(:,3)<Zval(2),:);  
     end
    if zmapval
%         cmap = AdvancedColormap('rb');
        chigh = [186,158,255]/255;
        clow = [186,158,0]/255;
        
                chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
        cmap = colormapCust( clow,chigh,256);
        plot3dZmap(dat1,cmap,ax,'.',8);
    else
     scatter3(dat1(:,1),dat1(:,2),dat1(:,3),ms,violet,'filled') %,'markertype','.'
    end
elseif pm1.Value == 3
    
    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    if ~isempty(polyreg) & nodeyesval
        [inpo2,onpo2] = inpolygon(dat2(:,1),dat2(:,2),nodes{1}(:,1),nodes{1}(:,2));
        dat2 = dat2(inpo2 | onpo2,:);
    end
    if sum(dat2(:,3)) & Zval & zfilterval
      dat2 = dat2(dat2(:,3)>Zval(1) & dat2(:,3)<Zval(2),:);    
    end
    if zmapval
%         cmap = AdvancedColormap('rb');
       chigh = [186,158,255]/255;
       clow = [186,158,0]/255;
       
               chigh = [186,158,255]/255;
       clow = [226,151,34]/255;
        cmap = colormapCust( clow,chigh,256);
        plot3dZmap(dat2,cmap,ax,'.',8);
    else
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),ms,green,'filled')
    end
end
if Zval
    zlim([Zval(1),Zval(2)])
end
alw = 1;    % AxesLineWidth
fsz = 10;      % Fontsize
set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax,'xtick',[],'ytick',[],'ztick',[]);
set(ax, 'FontSize', fsz, 'LineWidth', alw);
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');
axis equal
end
end
%%
s_roi3dvoronoi = s_roi3dscatter - [0 pbh+pbs 0 0];            
uicontrol('Style','pushbutton','String','3d voronoi',...
           'Tag','roi3dvoronoi','Position',s_roi3dvoronoi,...
           'Callback',@roi3dvoronoi_Callback);
% include node plot in 3d scatter
s_nodeyes = s_roi3dvoronoi + [pbw+pbs 0 0 0];      
nodeyes = uicontrol('Style','checkbox',...
                'String','node',...
                'Value',0,'Position',s_nodeyes);
% filers out badly fitted Z points
s_zfiltyes = s_nodeyes + [pbw+pbs 0 0 0];      
zfilter = uicontrol('Style','checkbox',...
                'String','Zfilter',...
                'Value',0,'Position',s_zfiltyes);
% iz colormap for 3d scatter
s_zmap = s_zfiltyes + [pbw+pbs 0 0 0];      
zmap = uicontrol('Style','checkbox',...
                'String','Zmap',...
                'Value',0,'Position',s_zmap);
       %%
function roi3dvoronoi_Callback(~,~)
if ~isempty(pos0)
violet = eval(colch1.String);
green = eval(colch2.String);
pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
fig = figure;
ax = axes;
set(ax,'NextPlot','add');%hold on;hold on;
if pm1.Value == 1
  
if flagalign
Vp1filt = Vp1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);

else
Vp1filt = Vp1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);
end

Vp2filt = Vp2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);

for k=1:length(Vp2filt)
VertCell = Vp2filt{k};
    alp2 = 0.1;
    alp1 = 0.5;
        patch('XData',VertCell(:,1),'YData',VertCell(:,2),'ZData',VertCell(:,3),'FaceColor',green,'EdgeColor',...
        green,'FaceAlpha', alp1,'EdgeAlpha', alp2,'Parent',ax)
end
for k=1:length(Vp1filt)
    VertCell = Vp1filt{k};
    if ~isempty(leftrightcount)
    VertCell(:,1) = VertCell(:,1) - leftrightcount;
    end
    if ~isempty(updowncount)
    VertCell(:,2) = VertCell(:,2) - updowncount;
    end
     if ~isempty(zcount)
    VertCell(:,3) = VertCell(:,3) - zcount;
     end
    alp2 = 0.1;
    alp1 = 0.5;
        patch('XData',VertCell(:,1),'YData',VertCell(:,2),'ZData',VertCell(:,3),'FaceColor',violet,'EdgeColor',...
        violet,'FaceAlpha', alp1,'EdgeAlpha', alp2,'Parent',ax)
end 

elseif pm1.Value == 2
  
if flagalign
Vp1filt = Vp1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);

else
Vp1filt = Vp1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);

end

for k=1:length(Vp1filt)
    VertCell = Vp1filt{k};
    if ~isempty(leftrightcount)
    VertCell(:,1) = VertCell(:,1) - leftrightcount;
    end
    if ~isempty(updowncount)
    VertCell(:,2) = VertCell(:,2) - updowncount;
    end
     if ~isempty(zcount)
    VertCell(:,3) = VertCell(:,3) - zcount;
     end
    alp2 = 0.1;
    alp1 = 0.5;
        patch('XData',VertCell(:,1),'YData',VertCell(:,2),'ZData',VertCell(:,3),'FaceColor',violet,'EdgeColor',...
        violet,'FaceAlpha', alp1,'EdgeAlpha', alp2,'Parent',ax)
end
elseif pm1.Value == 3
    
    Vp2filt = Vp2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);

for k=1:length(Vp2filt)
VertCell = Vp2filt{k};
    alp2 = 0.1;
    alp1 = 0.5;
        patch('XData',VertCell(:,1),'YData',VertCell(:,2),'ZData',VertCell(:,3),'FaceColor',green,'EdgeColor',...
        green,'FaceAlpha', alp1,'EdgeAlpha', alp2,'Parent',ax)
end
end
alw = 1;    % AxesLineWidth
fsz = 10;      % Fontsize
set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax,'xtick',[],'ytick',[],'ztick',[]);
set(ax, 'FontSize', fsz, 'LineWidth', alw);
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');
end
end
%%
s_roi2dvoronoi = s_roi3dvoronoi - [0 pbh+pbs 0 0];            
uicontrol('Style','pushbutton','String','2d voronoi',...
           'Tag','roi2dvoronoi','Position',s_roi2dvoronoi,...
           'Callback',@roi2dvoronoi_Callback);
 
s_2dvoronoithr1 = s_roi2dvoronoi + [pbw+pbs 0 0+pbw+10*pbs 0];             
voronoithr1 = uicontrol('Style','edit','String','[2048 1e-6 0.001 1e-5 0]',...
'Tag','2dvoronoithr1','Position',s_2dvoronoithr1);

s_2dvoronoithr2 = s_2dvoronoithr1 - [0 pbh+pbs 0 0];             
voronoithr2 = uicontrol('Style','edit','String','[2048 1e-6 0.001 1e-5 0]',...
'Tag','2dvoronoithr2','Position',s_2dvoronoithr2);

function roi2dvoronoi_Callback(~,~)
vhr1 = eval(voronoithr1.String);
vhr2 = eval(voronoithr2.String);
violet = eval(colch1.String);
green = eval(colch2.String);
fn1 = vhr1(1);
vorothr1 = vhr1(2);
vorothrup1 = vhr1(3);
vorothrstep1 = vhr1(4);
scattag1 = vhr1(5);

fn2 = vhr2(1);
vorothr2 = vhr2(2);
vorothrup2 = vhr2(3);
vorothrstep2 = vhr2(4);
scattag2 = vhr2(5);
    
if ~isempty(pos0)

pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
if pm1.Value == 1
    if flagroi
    end
    if flagalign
    ind1 = find(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
    dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);
    else
    ind1 = find(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
    dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);
    end
    ind2 = find(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);
    Vp1filt = Vp1(ind1);
    Vp2filt = Vp2(ind2);
    den1 = Dp1(ind1);
    den2 = Dp2(ind2);
    dennorm1 = den1/max(den1);
    dennorm2 = den2/max(den2);
    fig = figure;
    ax = axes;
    if flagalign
         datafiltered1 = dataoutshift1(ind1,:);
    else
         datafiltered1 = dataout1(ind1,:);
    end
    datafiltered2 = dataout2(ind2,:);
    
    for k=1:length(Vp1filt)
     if den1(k) >= vorothr1
        VertCell = Vp1filt{k}(:,1:2);
        if flagalign
            if ~isempty(leftrightcount)
            VertCell(:,1) = VertCell(:,1) - leftrightcount;
            end
            if ~isempty(updowncount)
            VertCell(:,2) = VertCell(:,2) - updowncount;
            end
        end

     alp1(k)  = dennorm1(k)*10;
     if alp1(k) <= 0.05
         alp1(k)  = 0.05;
     elseif alp1(k) >= 0.85
         alp1(k)  = 0.85;
     end
        patch('XData',VertCell(:,1),'YData',VertCell(:,2),'FaceColor',violet,...
            'EdgeColor',violet,'FaceAlpha', alp1(k),'EdgeAlpha', alp1(k),'Parent',ax)
        if scattag1
            hold on;
            x2 = datafiltered1(k,1);
            y2 = datafiltered1(k,2);
             plot(x2,y2,'.','Color',violet,'Parent', ax);  
        end


     end
    end 
    set(ax,'NextPlot','add');%hold on;hold on;

    for k=1:length(Vp2filt)
     if den2(k) >= vorothr2
     VertCell = Vp2filt{k}(:,1:2);
     alp2(k)  = dennorm2(k)*10;
     if alp2(k) <= 0.05
         alp2(k)  = 0.05;
     elseif alp2(k) >=  0.85
         alp2(k)  = 0.85;
     end
    patch('XData',VertCell(:,1),'YData',VertCell(:,2),'FaceColor',green,...
    'EdgeColor',green,'FaceAlpha', alp2(k),'EdgeAlpha', alp2(k),'Parent',ax)
        if scattag2
            hold on;
            x2 = datafiltered2(k,1);
            y2 = datafiltered2(k,2);
             plot(x2,y2,'.','Color',green,'Parent', ax);  
        end
     end
    end

elseif pm1.Value == 2

    map = jet(fn1);
    if flagalign
        ind1 = find(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);
    else

        ind1 = find(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);
    end
   if flagalign
         datafiltered1 = dataoutshift1(ind1,:);
    else
         datafiltered1 = dataout1(ind1,:);
   end
    
    Vp1filt = Vp1(ind1);
    den = Dp1(ind1);
    denorm = den/max(den);
    denscale = vorothr1:vorothrstep1:vorothrup1;
    denscalenorm = denscale/max(denscale);
    denscalenorm = log(denscalenorm);
    fig = figure;
    ax = axes;

    Are1 = log(denorm);
    map(1,:) = [1 1 1];
    Y = discretize(Are1,min(denscalenorm):(max(denscalenorm)-...
        min(denscalenorm))/(fn1-1):max(denscalenorm));
for k=1:length(Vp1filt)
    VertCell = Vp1filt{k}(:,1:2);
    if flagalign
        if ~isempty(leftrightcount)
        VertCell(:,1) = VertCell(:,1) - leftrightcount;
        end
        if ~isempty(updowncount)
        VertCell(:,2) = VertCell(:,2) - updowncount;
        end
    end
%  A = polyarea(VertCell(:,1),VertCell(:,2));% %  Are1(k) =  abs(Are(k).* 10^(-dig+1));
     if  den(k) >= vorothr1
         if isfinite(Y(k))
            col(k,:) = map(Y(k),:);
            patch(VertCell(:,1),VertCell(:,2),col(k,:),...
            'EdgeColor','none','Parent',ax)
            if scattag1
                hold on;
                x2 = datafiltered1(k,1);
                y2 = datafiltered1(k,2);
                 plot(x2,y2,'.','Color','r','Parent', ax);  
            end
         end
     end
    end

elseif pm1.Value == 3
    
    map = jet(fn2); 
    ind2 = find(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);
    Vp2filt = Vp2(ind2);
    den = Dp2(ind2);
    denorm = den/max(den);
    datafiltered2 = dataout2(ind2,:);
    denscale = vorothr2:vorothrstep2:vorothrup2;
    denscalenorm = denscale/max(denscale);
    denscalenorm = log(denscalenorm);
    fig = figure;
    ax = axes;
    Are2 = log(denorm);
    map(1,:) = [1 1 1];
    Y = discretize(Are2,min(denscalenorm):(max(denscalenorm)-min(denscalenorm))/(fn2-1):max(denscalenorm));
    for k=2:length(Vp2filt)
        VertCell = Vp2filt{k}(:,1:2);
    %  A = polyarea(VertCell(:,2),VertCell(:,2));% %  Are2(k) =  abs(Are(k).* 20^(-dig+2));
     if  den(k) >= vorothr2
          if isfinite(Y(k))
            col(k,:) = map(Y(k),:);
            patch(VertCell(:,1),VertCell(:,2),col(k,:),...
            'EdgeColor','none','Parent',ax)
            if scattag2
                hold on;
                x2 = datafiltered2(k,1);
                y2 = datafiltered2(k,2);
                 plot(x2,y2,'.','Color','r','Parent', ax);  
            end

          end
     end
    end
end
axis equal
box on;
set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax,'xtick',[],'ytick',[]);

figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
pos1 = get(fig, 'Position');
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');
% xlabel('X')
% ylabel('Y')
end 
end
%%
s_roi2dgraph = s_roi2dvoronoi - [0 pbh+pbs 0 0];            
uicontrol('Style','pushbutton','String','2d Graph',...
           'Tag','roi2dgraph','Position',s_roi2dgraph,...
           'Callback',@roi2dgraph_Callback);
 %s_roi2dgraph      

function roi2dgraph_Callback(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);
if ~isempty(pos0)

pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
fig = figure;
ax = axes;
set(ax,'NextPlot','add');
if pm1.Value == 1

ind1 = find(Cen1(:,1) <= xmax & Cen1(:,1) >= xmin &...
Cen1(:,2) <= ymax & Cen1(:,2) >= ymin);
GrapsSu1 = Gsub1(ind1);
XY1 = XYZnodes1(ind1);

ind2 = find(Cen2(:,1) <= xmax & Cen2(:,1) >= xmin &...
Cen2(:,2) <= ymax & Cen2(:,2) >= ymin);
GrapsSu2 = Gsub2(ind2);
XY2 = XYZnodes2(ind2);

ns1 = numel(XY1);
ns2 = numel(XY2);
ms = 0.1;
pathcol = [242,187,22]/255;
pathcol2= [127,21,26]/255;

for ii = 1:ns1
p1 = plot(GrapsSu1{ii},'XData',XY1{ii}(:,1),'YData',XY1{ii}(:,2),'EdgeColor',violet,...
    'NodeColor',violet,'MarkerSize',ms,'Parent',ax);
p1.NodeLabel = {};
p1.Marker = '.';

end
for ii = 1:ns2
p2 = plot(GrapsSu2{ii},'XData',XY2{ii}(:,1),'YData',XY2{ii}(:,2),'EdgeColor',green, ...
    'NodeColor',green,'MarkerSize',ms,'Parent',ax);
p2.NodeLabel = {};
p2.Marker = '.';

end
elseif pm1.Value == 2
    
    ind1 = find(Cen1(:,1) <= xmax & Cen1(:,1) >= xmin &...
    Cen1(:,2) <= ymax & Cen1(:,2) >= ymin);
    GrapsSu1 = Gsub1(ind1);
    XY1 = XYZnodes1(ind1); % ,1:2
    ns1 = numel(XY1);
    for ii = 1:ns1
    p1 = plot(GrapsSu1{ii},'XData',XY1{ii}(:,1),'YData',XY1{ii}(:,2),...
        'EdgeColor',violet, 'NodeColor',violet,'Parent',ax);
    p1.NodeLabel = {};
    p1.Marker = '.';
    end

elseif pm1.Value == 3
    ind2 = find(Cen2(:,1) <= xmax & Cen2(:,1) >= xmin &...
    Cen2(:,2) <= ymax & Cen2(:,2) >= ymin);
    GrapsSu2 = Gsub2(ind2);
    XY2 = XYZnodes2(ind2);
    ns2 = numel(XY2);
    ms = 0.1;
    for ii = 1:ns2
        p2 = plot(GrapsSu2{ii},'XData',XY2{ii}(:,1),'YData',XY2{ii}(:,2),'EdgeColor',green, ...
            'NodeColor',green,'MarkerSize',ms,'Parent',ax);
        p2.NodeLabel = {};
        p2.Marker = '.';
    end
end
alw = 0.5;
figs = eval(ifig.String); 
axis equal
box on;
set(ax,'xtick',[],'ytick',[]);
set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
set(ax, 'LineWidth', alw);
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');
end 
end
%%
s_scattplot = s_roi2dgraph - [0 pbh+pbs 0 0];            
uicontrol('Style','pushbutton','String','2d scatter',...
           'Tag','roi3dvoronoi','Position',s_scattplot,...
           'Callback',@scattplot_Callback);
       
s_imcrop = s_scattplot + [pbw+pbs 0 0 0];            
uicontrol('Style','pushbutton','String','crop image',...
           'Tag','roi3dvoronoi','Position',s_imcrop,...
           'Callback',@cropimage_Callback);
       %%
function cropimage_Callback(~,~)
pos = getPosition(hrect);
pix = eval(textbox_minPIX1.String);
pos = round(pos);
    if ~isempty(pos)

    fig1 = figure;
    ax1 = axes;
    set(ax1,'NextPlot','add')
    
    X2 = imcrop(imRGB,pos/pix);

        if pm1.Value == 1 & imvisu1 & imvisu2
           imshow(X2,[imsc(5),imsc(6)],'Parent', ax1); 
        elseif pm1.Value == 2 & imvisu1
            imshow(X2,[imsc(5),imsc(6)],'Parent', ax1);    
        elseif pm1.Value == 3 & imvisu2
            imshow(X2,[imsc(5),imsc(6)],'Parent', ax1);
        end
        set(ha, 'YDir', 'normal');
        axis equal
        set(ax1,'xtick',[],'ytick',[]);

    end
end
%%
function scattplot_Callback(~,~)
    pos = getPosition(hrect);
    pix = eval(textbox_minPIX1.String);
    violet = eval(colch1.String);
green = eval(colch2.String);
pos = round(pos);
if ~isempty(pos)
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);

fig1 = figure;
ax1 = axes;
set(ax1,'NextPlot','add')
if pm1.Value == 1
    if flagalign
    ind1 = find(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
    dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);
    x1 = dataoutshift1(ind1,1);
    y1 = dataoutshift1(ind1,2);
    else
    ind1 = find(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
    dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);
    x1 = dataout1(ind1,1);
    y1 = dataout1(ind1,2);
    end
    ind2 = find(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);
    x2 = dataout2(ind2,1);
    y2 = dataout2(ind2,2);
    plot(x1,y1,'.','Color',violet,'Parent', ax1);    
    plot(x2,y2,'.','Color',green,'Parent', ax1);  
elseif pm1.Value == 2
    
    if flagalign
        ind1 = find(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin);
        x1 = dataoutshift1(ind1,1);
        y1 = dataoutshift1(ind1,2);
    else
        ind1 = find(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin);
        x1 = dataout1(ind1,1);
        y1 = dataout1(ind1,2);
    end
    plot(x1,y1,'.','Color',violet,'Parent', ax1);    
elseif pm1.Value == 3
    ind2 = find(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin);
    x2 = dataout2(ind2,1);
    y2 = dataout2(ind2,2);
    plot(x2,y2,'.','Color',green,'Parent', ax1);  
end
axis equal
box on;
set(ax1,'xlim',[pos(1),pos(1)+pos(3)])
set(ax1,'ylim',[pos(2),pos(2)+pos(4)])
set(ax1,'xtick',[],'ytick',[]);
pos1 = get(fig1, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig1, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig1,'color','w')
set(fig1,'InvertHardcopy','on');
end
end
%%
s_pushzup = s_scattplot - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','z up',...
           'Tag','pushzup','Position',s_pushzup,...
           'Callback',@pushzup_Callback);
%%
function pushzup_Callback(~,~)
    violet = eval(colch1.String);
    green = eval(colch2.String);
    step = -eval(textbox_minSTEP1.String);
    if ~flagalign
       dataoutshift1 = dataout1;  
        dataoutshift1(:,5) = dataoutshift1(:,5) - step;
       flagalign = 1;
    end  
       dataoutshift1(:,5) = dataoutshift1(:,5) - step;
       zcount = zcount + step;
if ~isempty(pos0)

pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);
fig = figure;
ax = axes;
set(ax,'NextPlot','add');
if pm1.Value == 1
    if flagalign
        dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end

    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),30,violet,'filled','Parent', ax) %,'markertype','.'
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),30,green,'filled','Parent', ax)
elseif pm1.Value == 2
    if flagalign
        dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),30,violet,'filled','Parent', ax) %,'markertype','.'
elseif pm1.Value ==3
    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),30,green,'filled','Parent', ax)
end

    az = 188;
    el = 20;
    view(az, el);
    axis square
    alw = 1;    % AxesLineWidth
    fsz = 10;      % Fontsize
    set(ax,'xlim',[pos(1),pos(1)+pos(3)])
    set(ax,'ylim',[pos(2),pos(2)+pos(4)])
    fontname = 'Helvetica';
    set(ax, 'FontSize', fsz, 'LineWidth', alw);
    zl = zlabel(ax, 'Z [nm]');
    set(zl,'Fontname',fontname, 'Fontsize', fsz)   
    box on;
    pos1 = get(fig, 'Position');
    figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
    set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
    set(fig,'color','w')
    set(fig,'InvertHardcopy','on');

end
     
end
%%
s_pushzdown = s_pushzup - [0 pbh + pbs 0 0];                 
uicontrol('Style','pushbutton','String','Z down',...
           'Tag','pushzdown','Position',s_pushzdown,...
           'Callback',@pushzdown_Callback); 
%%
function pushzdown_Callback(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);
step = eval(textbox_minSTEP1.String);
if ~flagalign
   dataoutshift1 = dataout1;  
   flagalign = 1;
   dataoutshift1(:,5) = dataoutshift1(:,5) - step;
end  
       dataoutshift1(:,5) = dataoutshift1(:,5) - step;
       zcount = zcount + step;
       
if ~isempty(pos0)

pos = getPosition(hrect);
pos = round(pos);
xmin = pos(1);
xmax = pos(1)+pos(3);
ymin = pos(2);
ymax = pos(2)+pos(4);

fig = figure;
ax = axes;
set(ax,'NextPlot','add');
if pm1.Value == 1
    if flagalign
        dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end

    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),30,violet,'filled','Parent', ax) %,'markertype','.'
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),30,green,'filled','Parent', ax)
elseif pm1.Value == 2
    if flagalign
        dat1 = dataoutshift1(dataoutshift1(:,1) <= xmax & dataoutshift1(:,1) >= xmin &...
        dataoutshift1(:,2) <= ymax & dataoutshift1(:,2) >= ymin,[1,2,5]);
    else
        dat1 = dataout1(dataout1(:,1) <= xmax & dataout1(:,1) >= xmin &...
        dataout1(:,2) <= ymax & dataout1(:,2) >= ymin,[1,2,5]);
    end
    scatter3(dat1(:,1),dat1(:,2),dat1(:,3),30,violet,'filled','Parent', ax) %,'markertype','.'
elseif pm1.Value ==3
    dat2 = dataout2(dataout2(:,1) <= xmax & dataout2(:,1) >= xmin &...
    dataout2(:,2) <= ymax & dataout2(:,2) >= ymin,[1,2,5]);
    scatter3(dat2(:,1),dat2(:,2),dat2(:,3),30,green,'filled','Parent', ax)
end
az = 188;
el = 20;
view(az, el);
axis square
alw = 1;    % AxesLineWidth
fsz = 10;      % Fontsize
set(ax,'xlim',[pos(1),pos(1)+pos(3)])
set(ax,'ylim',[pos(2),pos(2)+pos(4)])
fontname = 'Helvetica';
set(ax, 'FontSize', fsz, 'LineWidth', alw);
zl = zlabel(ax, 'Z [nm]');
set(zl,'Fontname',fontname, 'Fontsize', fsz)   
box on;
pos1 = get(fig, 'Position');
figs = eval(ifig.String); fwd = figs(1); fhg = figs(2);
set(fig, 'Position', [pos1(1)-50 pos1(2)-50 fwd, fhg]); %<- Set size
set(fig,'color','w')
set(fig,'InvertHardcopy','on');   
end
end
%%
s_loadgraph = s_pushzdown - [0 pbh + pbs 0 0];                 
uicontrol('Style','pushbutton','String','Load graph',...
           'Tag','loadgraph','Position',s_loadgraph,...
           'Callback',@loadgraph_Callback); 
%% load graph-based colocalization or object analysis file
Gsub1 = [];WC1 = [];XYZnodes1 = [];Gsub2 = [];WC2 = [];
XYZnodes2 = [];Cen1 = []; Cen2 = [];

function loadgraph_Callback(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);
 cla(ha,'reset')
 [filenamepreal,pathreal] = uigetfile('*.mat','Get a file with graph data');
 flagalign =0;
if pm1.Value == 1

tmp = load(strcat(pathreal,filenamepreal),'dim','dataoutshift1','dataout2',...
    'Dp1','Vp1','Dp2','Vp2','Cen1','Cen2',...
    'Gsub2','Gsub1','XYZnodes1','XYZnodes2','leftrightcount','updowncount',...
    'WC1','WC2','zcount','XYZcell1','XYZcell2'); %
disp('Loading graph data...')
elseif pm1.Value == 2
   tmp = load(strcat(pathreal,filenamepreal),'dim',...
    'Dp1','G1','Vp1','Cen1','WC1',...
    'Gsub1','XYZnodes1','dataout1','XYZcell1'); % 
elseif pm1.Value == 3
   tmp = load(strcat(pathreal,filenamepreal),'dim',...
    'Dp2','G2','Vp2','Cen2','WC2',...
    'Gsub2','XYZnodes2','dataout2','XYZcell2'); % 
end
if pm1.Value == 1 
    dim = tmp.dim;
    dataoutshift1 = tmp.dataoutshift1;
    Vp1 = tmp.Vp1;
    Dp1 = tmp.Dp1;
    dataout2 = tmp.dataout2;    
    Vp2 = tmp.Vp2;
    Dp2 = tmp.Dp2;
    Cen1 = tmp.Cen1;
    Cen2 = tmp.Cen2;
    WC1 = tmp.WC1;
    WC2 = tmp.WC2;
    Gsub1 = tmp.Gsub1;
    Gsub2 = tmp.Gsub2;
    try
        XYZnodes1 = tmp.XYZnodes1; 
        XYZnodes2 = tmp.XYZnodes2;
    catch
         XYZnodes1 = tmp.XYZcell1; 
         XYZnodes2 = tmp.XYZcell2;
    end
    visu1 = 1;
    visu2 = 1;
elseif pm1.Value == 2
    dim = tmp.dim;
    dataout1 = tmp.dataout1;
    Vp1 = tmp.Vp1;
    Dp1 = tmp.Dp1;
    Cen1 = tmp.Cen1;
    Gsub1 = tmp.Gsub1;
    XYZnodes1 = tmp.XYZnodes1; 
    visu1 = 1;
    WC1 = tmp.WC1;
    try
        XYZnodes1 = tmp.XYZnodes1; 
    catch
         XYZnodes1 = tmp.XYZcell1; 
    end
    plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha); 
elseif pm1.Value == 3
    dim = tmp.dim;
    dataout2 = tmp.dataout2;
    Vp2 = tmp.Vp2;
    Dp2 = tmp.Dp2;
    Cen2 = tmp.Cen2;
    Gsub2 = tmp.Gsub2;
    try
        XYZnodes2 = tmp.XYZnodes2;
    catch 
         XYZnodes2 = tmp.XYZcell2;
    end
    XYZnodes2 = tmp.XYZnodes2; 
    WC2 = tmp.WC2;
    visu2 = 1;
plot(dataout2(:,1),dataout2(:,2),'.g','Color',green,'Parent', ha); 
end

if pm1.Value == 1

    plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    set(ha,'NextPlot','add');%hold on;
    plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
    try
        leftrightcount = tmp.leftrightcount;
        updowncount = tmp.updowncount;
        try
         zcount = tmp.zcount;
        catch
            zcount = 0;
        end
    catch
         [filenamepreal1,pathreal1] = uigetfile('*.mat','Get a file with alignment data');
         tmp1 = load(strcat(pathreal1,filenamepreal1),'leftrightcount','updowncount',...
         'zcount'); %
        leftrightcount = tmp1.leftrightcount;
        updowncount = tmp1.updowncount;
        try
         zcount = tmp1.zcount;
        catch
            zcount = 0;
        end
    end
    if isempty(zcount)
        dim = 2;
    else
        dim = 3;
    end
     flagalign = 1;
     disp('Loading align finished')
     dataout1 = dataoutshift1; 
     if ~isempty(leftrightcount)
        dataout1(:,1) = dataout1(:,1) + leftrightcount;
     end
     if ~isempty(updowncount)
        dataout1(:,2) = dataout1(:,2) + updowncount;
     end
    if dim == 3 & ~isempty(zcount)
     dataout1(:,5) = dataout1(:,5) + zcount;
    end
    flagalign = 1;  
end
end

%%
s_panelnnd = [s_loadgraph(1)- 0.5*pbs,...
             s_loadgraph(2)-13.75*(pbh + pbs),...
             3*(pbw + pbs)+ 0.5*pbs,...
             13*(pbh + pbs)];
         
p1 = uipanel(f,'units','pixels','Title','Nearest neighbour distance filtering',...
             'Position',s_panelnnd,'FontSize',9,'FontWeight','bold');
%          
s_dimt = s_loadgraph - 3*[0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','nnd dim',...
           'Position',s_dimt); % 'Parent',p1,

s_editdim = s_dimt + [pbw + pbs 0 0 0];                 
editdim = uicontrol('Style','edit','String','3',...
'Position',s_editdim); 

s_im1 = s_editdim + [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','Channel 1',...
           'Position',s_im1);
       
s_im2 = s_im1 + [pbw + pbs 0 0 0];                 
uicontrol('Style','text','String','Channel 2',...
           'Position',s_im2);

s_numnnd = s_dimt - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','#nn(1-2,2-1)',...
           'Position',s_numnnd); 
       
s_editnnd12 = s_numnnd + [pbw + pbs 0 0 0];                 
editnnd12 = uicontrol('Style','edit','String','10',...
'Position',s_editnnd12); 

s_editnnd21 = s_editnnd12 + [pbw + pbs 0 0 0];                 
editnnd21 = uicontrol('Style','edit','String','10',...
'Position',s_editnnd21); 

s_numnnd11 = s_numnnd - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','#nn(1-1,2-2)',...
           'Position',s_numnnd11); 

s_editnnd11 = s_numnnd11 + [pbw + pbs 0 0 0];                 
editnnd11 = uicontrol('Style','edit','String','40',...
'Position',s_editnnd11); 

s_editnnd22 = s_editnnd11 + [pbw + pbs 0 0 0];                 
editnnd22 = uicontrol('Style','edit','String','40',...
'Position',s_editnnd22); 

s_step = s_numnnd11 - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','Histc step',...
           'Position',s_step);
 
s_editstep1 = s_step + [pbw + pbs 0 0 0];                 
editstep1 = uicontrol('Style','edit','String','5',...
'Position',s_editstep1);        
             
s_editstep2 = s_editstep1 + [pbw + pbs 0 0 0];                 
editstep2 = uicontrol('Style','edit','String','5',...
'Position',s_editstep2); 

s_filt = s_step - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','Dist(1-2,2-1)',...
           'Position',s_filt);

s_editfilt1 = s_filt + [pbw + pbs 0 0 0];                 
editfilt1 = uicontrol('Style','edit','String','150',...
'Position',s_editfilt1); 
       
s_editfilt2 = s_editfilt1 + [pbw + pbs 0 0 0];                 
editfilt2 = uicontrol('Style','edit','String','150',...
'Position',s_editfilt2); 

s_filt11 = s_filt - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','Dist(1-1,2-2)',...
           'Position',s_filt11);

s_editfilt11 = s_filt11 + [pbw + pbs 0 0 0];                 
editfilt11 = uicontrol('Style','edit','String','150',...
'Position',s_editfilt11);       
       
s_editfilt22 = s_editfilt11 + [pbw + pbs 0 0 0];                 
editfilt22 = uicontrol('Style','edit','String','150',...
'Position',s_editfilt22); 
 

s_filtnnd = s_filt11 - [0 pbh + pbs 0 0];                 
uicontrol('Style','pushbutton','String','Filter nnd',...
'Position',s_filtnnd,...
           'Callback',@filtnnd_Callback);
 s_chboxfilt = s_filtnnd + [pbw + pbs 0 0 0];      
checkboxfilt = uicontrol('Style','checkbox',...
                'String','Check for bivariate filt',...
                'Value',1,'Position',s_chboxfilt);
%%
Dav21 = [];
Dav12 = [];
Dav22 = [];
Dav11 = [];
filtval2 = [];
filtval1 = [];
filtval21 = [];
filtval12 = [];
numn12 = 0;
numn21 = 0;
numn11 = 0;
numn22 = 0;
dimn = 0;
indf21 = [];
indf12 = [];
function filtnnd_Callback(~,~)
widthf = 2.5;     % Width in inches
heightf = 2.5;    % Height in inches
alw = 1;    % AxesLineWidth
fsz = 10;      % Fontsize
lw = 1.5;      % LineWidth
msz = 1;       % MarkerSize
fszl = 8; % Fontsize legend
fontname = 'Helvetica';
violet = eval(colch1.String);
green = eval(colch2.String);
step2 = eval(editstep2.String); 
step1 = eval(editstep1.String); 
dimn = eval(editdim.String); 
numn12 = eval(editnnd12.String); 
numn21 = eval(editnnd21.String); 
numn11 = eval(editnnd11.String); 
numn22 = eval(editnnd22.String); 
cla(ha,'reset')
filtval2 = eval(editfilt22.String); 
filtval21 = eval(editfilt2.String); 
filtval1 = eval(editfilt11.String); 
filtval12 = eval(editfilt1.String); 

if pm1.Value == 1
if dimn == 3
    if flagalign 
    x = dataoutshift1(:,[1,2,5]);
    y = dataout2(:,[1,2,5]);
    else
    dataoutshift1 = dataout1;
    x = dataoutshift1(:,[1,2,5]);
    y = dataout2(:,[1,2,5]);
    end
elseif dimn == 2
    if flagalign 
    x = dataoutshift1(:,[1,2]);
    y = dataout2(:,[1,2]);
    else
    dataoutshift1 = dataout1;
    x = dataoutshift1(:,[1,2]);
    y = dataout2(:,[1,2]);
    end
end
elseif pm1.Value == 2
  if dimn == 3
          x = dataout1(:,[1,2,5]);
  elseif dimn == 2
          x = dataout1(:,[1,2]);
  end
elseif pm1.Value == 3
    if dimn == 3
        y = dataout2(:,[1,2,5]);
    elseif dimn == 2
        y = dataout2(:,[1,2]);
    end
end

if pm1.Value == 1
    
Dav21= knnsearchThr(x,y,numn21,'mean');
binranges21 = 0:step2:max(Dav21);
bincounts21 = histc(Dav21,binranges21);
figure;
subplot(2,2,1)
ha1 = gca;
bar(binranges21,bincounts21,'FaceColor',green,'EdgeColor',green,'LineWidth',1.5);
axis([0,3000,0,max(bincounts21)])
tl = title(sprintf('Mean nnd to %d neighbours\n from point set 2 to 1',numn21));
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
ha1.TickDir = 'out';
ha1.TickLength =  [0.02 0.025];
axis square
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');   
yl = ylabel(gca, 'Counts');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
xl =xlabel(gca, 'Distance');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties

Dav12= knnsearchThr(y,x,numn12,'mean');
binranges12 = 0:step1:max(Dav12);
bincounts12 = histc(Dav12,binranges12);
subplot(2,2,2)
ha1 = gca;
bar(binranges12,bincounts12,'FaceColor',violet,'EdgeColor',violet,'LineWidth',1.5);
axis([0,3000,0,max(bincounts12)])
tl = title(sprintf('Mean nnd to %d neighbours\n from point set 1 to 2',numn12));
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
ha1.TickDir = 'out';
ha1.TickLength =  [0.02 0.025];
axis square
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');   
yl = ylabel(gca, 'Counts');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
xl =xlabel(gca, 'Distance');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties

Dav11= knnsearchThr(x,x,numn11,'mean');
binranges11 = 0:step1:max(Dav11);
bincounts11 = histc(Dav11,binranges11);
subplot(2,2,3)
ha1 = gca;
bar(binranges11,bincounts11,'FaceColor',violet,'EdgeColor',violet,'LineWidth',1.5);
axis([0,3000,0,max(bincounts11)])
tl = title(sprintf('Mean nnd to %d neighbours\n from point set 1 to 1',numn11));
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
ha1.TickDir = 'out';
ha1.TickLength =  [0.02 0.025];
axis square
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');   
yl = ylabel(gca, 'Counts');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
xl =xlabel(gca, 'Distance');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties

Dav22= knnsearchThr(y,y,numn22,'mean');
binranges22 = 0:step2: max(Dav22);
bincounts22 = histc(Dav22,binranges22);
subplot(2,2,4)
ha1 = gca;
bar(binranges22,bincounts22,'FaceColor',green,'EdgeColor',green,'LineWidth',1.5);
axis([0,3000,0,max(bincounts22)])
tl = title(sprintf('Mean nnd to %d neighbours\n from point set 2 to 2',numn22));
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
ha1.TickDir = 'out';
ha1.TickLength =  [0.02 0.025];
axis square
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');   
yl = ylabel(gca, 'Counts');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
xl =xlabel(gca, 'Distance');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
set(gca, 'FontSize', fsz, 'LineWidth', alw); 


if (get(checkboxfilt,'Value') == get(checkboxfilt,'Max'))
    indf21 = find((Dav21 <= filtval21) | (Dav22 <= filtval2));
    indf12 = find((Dav12 <= filtval12) | (Dav11 <= filtval1));
else
    indf21 = find((Dav21 <= filtval21));
    indf12 = find((Dav12 <= filtval12));
end

set(ha,'NextPlot','add');%hold on;

if flagalign
plot(dataoutshift1(indf12,1),dataoutshift1(indf12,2),'.g','Color',violet,'Parent', ha); 
else
plot(dataout1(indf12,1),dataout1(indf12,2),'.g','Color',violet,'Parent', ha);   
end
plot(dataout2(indf21,1),dataout2(indf21,2),'.m','Color',green,'Parent', ha);   
disp('Display filtered nnd')  

elseif  pm1.Value == 2
figure
ha1 = axes;
Dav11= knnsearchThr(x,x,numn11,'mean');
binranges11 = 0:step1:max(Dav11);
bincounts11 = histc(Dav11,binranges11);
figure
bar(binranges11,bincounts11,'FaceColor',violet,'EdgeColor',violet,'LineWidth',1.5);
axis([0,3000,0,max(bincounts11)])
tl = title(sprintf('Mean nnd to %d neighbours\n from point set 1 to 1',numn11));
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
ha1.TickDir = 'out';
ha1.TickLength =  [0.02 0.025];
axis square
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');   
yl = ylabel(gca, 'Counts');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
xl =xlabel(gca, 'Distance');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
indf12 = find(Dav11 <= filtval1);

plot(dataout1(indf12,1),dataout1(indf12,2),'.g','Color',violet,'Parent', ha);   

elseif  pm1.Value == 3
figure
ha1 = axes;
Dav22= knnsearchThr(y,y,numn11,'mean');
binranges22 = 0:step1:max(Dav22);
bincounts22 = histc(Dav22,binranges22);
bar(binranges22,bincounts22,'FaceColor',green,'EdgeColor',green,'LineWidth',1.5);
axis([0,3000,0,max(bincounts22)])
tl = title(sprintf('Mean nnd to %d neighbours\n from point set 2 to 2',numn22));
set(tl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
ha1.TickDir = 'out';
ha1.TickLength =  [0.02 0.025];
axis square
set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');   
yl = ylabel(gca, 'Counts');
set(yl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
xl =xlabel(gca, 'Distance');
set(xl,'Fontname',fontname, 'Fontsize', fsz,'color','k')  
set(gca, 'FontSize', fsz, 'LineWidth', alw); 
indf12 = find(Dav22 <= filtval2);
plot(dataout2(indf12,1),dataout2(indf12,2),'.m','Color',green,'Parent', ha);   
end
disp('Disply filter')
end

%%
s_applyfilt = s_filtnnd - [0 pbh + pbs 0 0];                 
uicontrol('Style','pushbutton','String','Apply filter',...
'Position',s_applyfilt,...
           'Callback',@applyfilt_Callback);
dataoutshift1NF = [];
dataout1NF = [];
dataout2NF = [];
Dp1NF = [];
Vp1NF = [];
Dp2NF = [];
Vp2NF = [];
%%
function applyfilt_Callback(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);


if pm1.Value == 1
dataout1NF = dataout1;
Dp1NF = Dp1;
Vp1NF = Vp1;
Dp1 = Dp1(indf12);
Vp1 = Vp1(indf12);
dataout1 = dataout1(indf12,:);
    if flagalign
        dataoutshift1NF = dataoutshift1;
        dataoutshift1 = dataoutshift1(indf12,:);
    else
        dataoutshift1NF = dataout1NF;
        dataoutshift1 = dataout1NF(indf12,:);
    end
    Dp2NF = Dp2;
    Vp2NF = Vp2;
    dataout2NF = dataout2;
    dataout2 = dataout2(indf21,:);
    Dp2 = Dp2(indf21);
    Vp2 = Vp2(indf21);
elseif pm1.Value == 2
    dataout1NF = dataout1;
    Dp1NF = Dp1;
    Vp1NF = Vp1;
    Dp1 = Dp1(indf12);
    Vp1 = Vp1(indf12);
    dataout1 = dataout1(indf12,:);
elseif pm1.Value == 3
    Dp2NF = Dp2;
    Vp2NF = Vp2;
    dataout2NF = dataout2;
    dataout2 = dataout2(indf21,:);
    Dp2 = Dp2(indf21);
    Vp2 = Vp2(indf21);
end
disp('Apply filter ')
end
%%
s_batchfilt = s_applyfilt + [pbw + pbs 0 pbw 0];                 
uicontrol('Style','pushbutton','String','Batch filtering 2 Color',...
'Position',s_batchfilt,...
           'Callback',@batchfilt_Callback);
       
function batchfilt_Callback(~,~)

dimn = eval(editdim.String); 
numn12 = eval(editnnd12.String); 
numn21 = eval(editnnd21.String); 
numn11 = eval(editnnd11.String); 
numn22 = eval(editnnd22.String); 
filtval2 = eval(editfilt22.String); 
filtval21 = eval(editfilt2.String); 
filtval1 = eval(editfilt11.String); 
filtval12 = eval(editfilt1.String); 
folder = uigetdir('Get a root folder for batch filtering');
runbatchprocessing(folder,11,dimn);
end

s_batchfilt1C = s_batchfilt - [0 pbh + pbs 0 0];                 
uicontrol('Style','pushbutton','String','Batch filtering 1 Color',...
'Position',s_batchfilt1C,...
           'Callback',@batchfilt1C_Callback);
       
function batchfilt1C_Callback(~,~)

dimn = eval(editdim.String); 
numn11 = eval(editnnd11.String); 
numn22 = eval(editnnd22.String); 
filtval2 = eval(editfilt22.String); 
filtval1 = eval(editfilt11.String); 

folder = uigetdir('Get a root folder for batch filtering');
runbatchprocessing(folder,12,dimn);
end
%% save all
s_savefilt = s_applyfilt - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','Save filter',...
'Position',s_savefilt,...
           'Callback',@savefilt_Callback);   
function savefilt_Callback(~,~)
locprec2 = eval(textbox_minLP2.String);
densitythr2 = eval(textbox_minD2.String); 
locprec1 = eval(textbox_minLP1.String);
densitythr1 = eval(textbox_minD1.String); 
photonTH1 = eval(textbox_minP1.String);  
photonTH2 = eval(textbox_minP2.String);  
if ~isempty(filenamepreal)
    filenamesavealign = strcat('Filtalgn_',filenamepreal(1:end-4),'.mat');
else
    filenamesavealign = strcat('Filtalgn_',namech1(1:end-4),'.mat');
end
if pm1.Value == 1
    uisave({'dataoutshift1','dataout2','dataout1','leftrightcount',...
    'updowncount','densitythr1','densitythr2','zcount',...
    'namech2','namech1','Dp2','Dp1','Vp1','Vp2',...
    'filtval21','filtval12','numn12','numn21','numn11','numn22',...
    'filtval2','filtval1','Dav12','Dav21','Dav11','Dav22',...
    'dataoutshift1NF','dataout2NF','dataout1NF','dim','dimn',...
    'Dp1NF','Dp2NF','Vp1NF','Vp2NF','photonTH1','photonTH2','locprec1',...
    'locprec2'},filenamesavealign) 
elseif pm1.Value == 2
    uisave({'dataout1','densitythr1','namech1','Dp1',...
    'Vp1','numn11',...
    'dimn','filtval1','Dav11',...
    'dataout1NF','dim',...
    'Dp1NF','Vp1NF','photonTH1','locprec1'},filenamesavealign) 
elseif pm1.Value == 3
    uisave({'dataout2','densitythr2','namech2','Dp2',...
    'Vp2','numn22',...
    'dimn','filtval2','Dav22',...
    'dataout2NF','dim',...
    'Dp2NF','Vp2NF','photonTH2','locprec2'},filenamesavealign) 
end
 disp('Saved filter')
end
%% reset filtered
s_resetfilt = s_savefilt - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','Undo filter',...
'Position',s_resetfilt,'Callback',@resetfilt_Callback);
%% load filtered       
s_loadfilt = s_resetfilt - [0 pbh + pbs 0 0];            
uicontrol('Style','pushbutton','String','Load filter',...
'Position',s_loadfilt,'Callback',@loadfilt_Callback);    
       %%
function loadfilt_Callback(~,~)
[filenamepreal,pathreal] = uigetfile('*.mat','Get a file with filtered data');

cla(ha,'reset')
if pm1.Value == 1
    tmp = load(strcat(pathreal,filenamepreal),'dataoutshift1',...
    'dataout1','dataout2','leftrightcount','updowncount','zcount',...
    'densitythr1','namech1','namech2','Dp1','Dp2',...
    'densitythr2','Vp1','Vp2','filtval21','filtval12','numn12',...
    'numn21','numn11','numn22',...
    'dimn','filtval2','filtval1','Dav12','Dav21','Dav11','Dav22',...
    'dataoutshift1NF','dataout1NF','dataout2NF','dim','dimn',...
    'Dp1NF','Vp1NF','photonTH1','locprec1',...
    'Dp2NF','Vp2NF','photonTH2','locprec2');
    locprec2 = tmp.locprec2;  
    photonTH2 = tmp.photonTH2;   
    dataout2 = tmp.dataout2;    
    dataoutshift1 = tmp.dataoutshift1;    
    dataout2NF = tmp.dataout2NF;
    dataoutshift1NF = tmp.dataoutshift1NF;
    leftrightcount = tmp.leftrightcount;
    updowncount = tmp.updowncount;
    zcount = tmp.zcount;    
    densitythr2 = tmp.densitythr2;   
    namech2 = tmp.namech2;   
    filtval21 = tmp.filtval21;
    filtval12 = tmp.filtval12;
    filtval2 = tmp.filtval2;    
    numn12 = tmp.numn12;
    numn21 = tmp.numn21;   
    numn22 = tmp.numn22;   
    Dav12 = tmp.Dav12;
    Dav21 = tmp.Dav21;
    Dav22 = tmp.Dav22;
    Vp2 = tmp.Vp2;
    Dp2 = tmp.Dp2;
    Vp2NF = tmp.Vp2NF;
    Dp2NF = tmp.Dp2NF;
    visu1 = 1;
    visu2 = 1;
    flagalign = 1;          
    textbox_minD2.String = num2str(densitythr2); 
    editnnd12.String = num2str(numn12); 
    editnnd21.String = num2str(numn21);     
    editnnd22.String = num2str(numn22); 
    editfilt22.String = num2str(filtval2); 
    editfilt2.String = num2str(filtval21); 
    editfilt1.String = num2str(filtval12);       
    locprec1 = tmp.locprec1;
    photonTH1 = tmp.photonTH1;
    dataout1 = tmp.dataout1;
    dataout1NF = tmp.dataout1NF;
    densitythr1 = tmp.densitythr1;    
    namech1 = tmp.namech1;
    filtval1 = tmp.filtval1;
    numn11 = tmp.numn11;
    dimn = tmp.dimn;
    Dav11 = tmp.Dav11;
    Vp1 = tmp.Vp1;
    Dp1 = tmp.Dp1;
    Vp1NF = tmp.Vp1NF;
    Dp1NF = tmp.Dp1NF;
    textbox_minD1.String = num2str(densitythr1);
    editfilt11.String = num2str(filtval1); 
    editnnd11.String = num2str(numn11);
    editdim.String = num2str(dimn);
    disp('Loaded filter')
    violet = eval(colch1.String);
    green = eval(colch2.String);
    textbox_meanDen1.String = num2str(mean(Dp1));
    textbox_medianDen1.String = num2str(median(Dp1));
    textbox_minDen1.String = num2str(min(Dp1));
    textbox_maxDen1.String = num2str(max(Dp1));
    textbox_meanDen2.String = num2str(mean(Dp2));
    textbox_medianDen2.String = num2str(median(Dp2));
    textbox_minDen2.String = num2str(min(Dp2));
    textbox_maxDen2.String = num2str(max(Dp2));
    textbox_minP2.String = photonTH2;  
    textbox_minLP2.String = locprec2;
    textbox_minP1.String = photonTH1;  
    textbox_minLP1.String = locprec1;
    if flagalign
        plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
        set(ha,'NextPlot','add');%hold on;
    else
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    end
     plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
elseif pm1.Value == 2
    tmp = load(strcat(pathreal,filenamepreal),...
    'dataout1',...
    'densitythr1','namech1','Dp1',...
    'Vp1','numn11',...
    'dimn','filtval1',...
    'dataout1NF','dim','dimn',...
    'Dp1NF','Vp1NF','Dav11');

    dataout1 = tmp.dataout1;
    dataout1NF = tmp.dataout1NF;
    densitythr1 = tmp.densitythr1;    
    namech1 = tmp.namech1;
    filtval1 = tmp.filtval1;
    numn11 = tmp.numn11;
    dimn = tmp.dimn;
    Dav11 = tmp.Dav11;
    Vp1 = tmp.Vp1;
    Dp1 = tmp.Dp1;
    Vp1NF = tmp.Vp1NF;
    Dp1NF = tmp.Dp1NF;
    textbox_minD1.String = num2str(densitythr1);
    editfilt11.String = num2str(filtval1); 
    editnnd11.String = num2str(numn11);
    editdim.String = num2str(dimn);
    disp('Loaded filter')
    plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha); 
    textbox_meanDen1.String = num2str(mean(Dp1));
    textbox_medianDen1.String = num2str(median(Dp1));
    textbox_minDen1.String = num2str(min(Dp1));
    textbox_maxDen1.String = num2str(max(Dp1));
    textbox_minP1.String = photonTH1;  
    textbox_minLP1.String = locprec1;
    visu1 = 1;
elseif pm1.Value == 3
    tmp = load(strcat(pathreal,filenamepreal),...
    'dataout2',...
    'densitythr2','namech2','Dp2',...
    'Vp2','numn22',...
    'dimn','filtval2',...
    'dataout2NF','dim','dimn',...
    'Dp2NF','Vp2NF','Dav21');

    dataout2 = tmp.dataout2;
    dataout2NF = tmp.dataout2NF;
    densitythr2 = tmp.densitythr2;    
    namech2 = tmp.namech2;
    filtval2 = tmp.filtval2;
    numn22 = tmp.numn22;
    dimn = tmp.dimn;
    Dav22 = tmp.Dav22;
    Vp2 = tmp.Vp2;
    Dp2 = tmp.Dp2;
    Vp2NF = tmp.Vp2NF;
    Dp2NF = tmp.Dp2NF;
    textbox_minD2.String = num2str(densitythr2);
    editfilt22.String = num2str(filtval2); 
    editnnd22.String = num2str(numn22);
    editdim.String = num2str(dimn);
    disp('Loaded filter')
    plot(dataout2(:,1),dataout2(:,2),'.g','Color',green,'Parent', ha); 
    textbox_minP2.String = photonTH2;  
    textbox_minLP2.String = locprec2;
    textbox_meanDen2.String = num2str(mean(Dp2));
    textbox_medianDen2.String = num2str(median(Dp2));
    textbox_minDen2.String = num2str(min(Dp2));
    textbox_maxDen2.String = num2str(max(Dp2));
    visu2 = 1;
end
end
%%
function resetfilt_Callback(~,~)

if pm1.Value == 1
    dataout1 = dataout1NF;
    Dp1 = Dp1NF;
    Vp1 = Vp1NF;
    if flagalign
    dataoutshift1 = dataoutshift1NF;
    end
    Dp2 = Dp2NF;
    Vp2 = Vp2NF;
    dataout2 = dataout2NF;
elseif pm1.Value == 2
    dataout1 = dataout1NF;
    Dp1 = Dp1NF;
    Vp1 = Vp1NF;
elseif pm1.Value == 3
    Dp2 = Dp2NF;
    Vp2 = Vp2NF;
    dataout2 = dataout2NF;
end
    disp('Reset filter')       
end
%% optimisation
global tol_value
global TolX
global MaxFunEvals
global MaxIter
global StepTol
global optix0

s_panelfitpar = [s_panelnnd(1)+s_panelnnd(3), s_panelnnd(2),0.66*s_panelnnd(3),s_panelnnd(4)];
pfirpar = uipanel(f,'units','pixels','Title','Fit parameters',...
             'Position',s_panelfitpar,'FontSize',9,'FontWeight','bold');
         
 s_TolFun = s_dimt + 3.05*[pbw + pbs 0 0 0];                 
uicontrol('Style','text','String','TolFun',...
           'Position',s_TolFun); 

s_TolFunE = s_TolFun + [pbw + pbs 0 0 0];                 
tol_valueE = uicontrol('Style','edit','String','10^-6',...
'Position',s_TolFunE); 

s_TolX = s_TolFun - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','TolX',...
           'Position',s_TolX); 

s_TolXE = s_TolX + [pbw + pbs 0 0 0];                 
TolXE = uicontrol('Style','edit','String','10^-6',...
'Position',s_TolXE); 

s_MaxFunEvals = s_TolX - [0 pbh + pbs 0 0 ];                 
uicontrol('Style','text','String','MaxFunEvals',...
           'Position',s_MaxFunEvals); 

s_MaxFunEvalsE = s_MaxFunEvals + [pbw + pbs 0 0 0];                 
MaxFunEvalsE = uicontrol('Style','edit','String','200',...
'Position',s_MaxFunEvalsE);

s_MaxIter = s_MaxFunEvals - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','MaxIter',...
           'Position',s_MaxIter); 

s_MaxIterE = s_MaxIter + [pbw + pbs 0 0 0];                 
MaxIterE = uicontrol('Style','edit','String','200',...
'Position',s_MaxIterE); 


s_steptol = s_MaxIter - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','StepTol',...
           'Position',s_steptol);
       
s_steptolE = s_steptol + [pbw + pbs 0 0 0];                 
steptolE = uicontrol('Style','edit','String','10^-6',...
'Position',s_steptolE); 

s_x0 = s_steptol - [0 pbh + pbs 0 0];                 
uicontrol('Style','text','String','X0',...
           'Position',s_x0);
       
s_x0E = s_x0 + [pbw + pbs 0 0 0];                 
x0E = uicontrol('Style','edit','String','[500 500 100]',...
'Position',s_x0E); 
%% menu
s_file = 1;
mh = uimenu(f,'Label','File','Position',s_file);
mhf1 = uimenu(mh,'Label','Set path ...','Callback',@setpath_Callback);  

function setpath_Callback(~,~)
    currentFolder = pwd;
    folder_name = uigetdir(currentFolder,'Chose working folder...');
    cd(folder_name)
end
eh2d = uimenu(mh,'Label','2D');  %,'Callback',@voronoi2d_Callback
eh2ds = uimenu(eh2d,'Label','single file'); 
uimenu(eh2ds,'Label','Import single Nikon txt molecular list','Callback',@singlegetlist2d_Callback);  
uimenu(eh2ds,'Label','Import single Nikon multicolor txt molecular list','Callback',@singlegetlist2dMulticolor_Callback);  
uimenu(eh2ds,'Label','Import single Zeiss txt molecular list','Callback',@singlegetlist2dZeiss_Callback);  
eh3d = uimenu(mh,'Label','3D');%,'Checked','on');
eh3ds = uimenu(eh3d,'Label','single file');  
uimenu(eh3ds,'Label','Import single Nikon txt molecular list','Callback',@singlegetlist3d_Callback);
uimenu(eh3ds,'Label','Import single Nikon multicolor txt molecular list','Callback',@singlegetlist3dMulticolor_Callback);  
uimenu(eh3ds,'Label','Import single Zeiss txt molecular list','Callback',@singlegetlist3dZeiss_Callback); 
eh3db = uimenu(eh3d,'Label','batch processing');  
uimenu(eh3db,'Label','Import Nikon txt molecular lists','Callback',@batchgetlist3d_Callback); 
uimenu(eh3db,'Label','Import Zeiss txt molecular lists','Callback',@batchgetlist3dZeiss_Callback); 
eh2db = uimenu(eh2d,'Label','batch processing');  
uimenu(eh2db,'Label','Import Nikon txt molecular lists','Callback',@batchgetlist2d_Callback);
uimenu(eh2db,'Label','Import Zeiss txt molecular lists','Callback',@batchgetlist2dZeiss_Callback); 
%%
s_voronoi = 2;
mh = uimenu(f,'Label','2 color Voronoi','Position',s_voronoi);
eh2d = uimenu(mh,'Label','2D');  %,'Callback',@voronoi2d_Callback
eh2ds = uimenu(eh2d,'Label','single file'); 
% uimenu(eh2ds,'Label','Import single Nikon molecular list','Callback',@singlegetlist2d_Callback);  
% uimenu(eh2ds,'Label','Import single Zeiss molecular list','Callback',@singlegetlist2dZeiss_Callback);  
uimenu(eh2ds,'Label','Threshold voronoi data','Callback',@singlevoronoi2d_Callback); 
uimenu(eh2ds,'Label','Re-threshold voronoi data','Callback',@singlerethrvoronoi2d_Callback); 
uimenu(eh2ds,'Label','Align two chanels','Callback',@singlealign2d_Callback); 
%% single file Nikon Import molecular list 2D
function singlegetlist2d_Callback(~,~)
singlegetlistNikon(2)
end 

%% single file Nikon Import molecular list
function singlegetlistNikon(dimension)
        [selecfiles,subsubdir] = uigetfile('*.txt','Get a  molecular list file');
     prompt = {'Enter the number of columuns in the molecular list file:',...
    'X coordinate column: ','Y coordinate column: ','Photon number column: ',...
    'Loc. prec. column: ','Frame index column: ', 'Channel tag column',...
    'Trace lenght colum: ',...
    'Z coordinate column: ','Z Rejected tag',...
    'Enter 1 to exlude Z Rejected, 0 to keep all localizations',...
    'Enter mininimum photon and maximum localization precision',...
    'Enter number of header lines in molecular list file:',...
    'Enter space delimeter in molecular list file'};
    dlg_title = 'Importing Nikon ML';
    num_lines = 1; % {24,23,24,19,20,13,1,14,18}
    def = {'24','23','24','19','20','13','1','14','18','Z Rejected','0',...
    '[300,25]','1','\t'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    MLindices = cellstr(answer(1:9));
    MLindices = cellfun(@str2double,MLindices, 'UniformOutput', false);
    idtag = answer{10};
    idfilt = str2double(answer{11});
    tmp = str2num(answer{12});
    minPC = tmp(1);
    maxLP = tmp(2);
    id = {idtag,idfilt};
    nH = str2double(answer{13});
    spaceDelim = answer{14};
    saveMultiMLfunc3d(selecfiles,subsubdir(1:end-1),MLindices,id,minPC,maxLP,dimension,nH,spaceDelim);
end

%% Nikon multicolor list import

%% single file Nikon Import molecular list 2D and 3D

function singlegetlist2dMulticolor_Callback(~,~)
singlegetlistNikonMC(2)
end 

function singlegetlist3dMulticolor_Callback(~,~)
singlegetlistNikonMC(3)
end 
function singlegetlistNikonMC(dimension)
        [selecfiles,subsubdir] = uigetfile('*.txt','Get a  molecular list file');
        %%
     prompt = {'Enter the number of columuns in the molecular list file:',...
    'X coordinate column:',...
    'Y coordinate column: ',...
    'Photon number column:',...
    'Loc. prec. column: ',...
    'Frame index column: ', ...
    'Channel tag column',...
    'Trace lenght colum: ',...
    'Z coordinate column: ',...
    'Z Rejected tag',...
    'Enter 1 to exlude Z Rejected, 0 to keep all localizations',...
    'Enter mininimum photon count and maximum localization precision',...
    'Enter number of header lines in molecular list file:',...
    'Enter space delimeter in molecular list file'};
    dlg_title = 'Importing Nikon ML';
    num_lines = 1; % {24,23,24,19,20,13,1,14,18}
    def = {'26','23','24','19','20','13','1','14','26','Z Rejected','0',...
    '[500,50]','1','\t'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
   
    MLindices = cellstr(answer(1:9));
    MLindices = cellfun(@str2double,MLindices, 'UniformOutput', false);
    idtag = answer{10};
    idfilt = str2double(answer{11});
    tmp = str2num(answer{12});
    minPC = tmp(1);
    maxLP = tmp(2);
    nH = str2double(answer{13});
    spaceDelim = answer{14}; 
    %%
 prompt = {'Number of chanels',...
     'First chanel tag',...
    'Second chanel  tag (in order of aquisition)','Thrird chanel tag (if applicable'};
    dlg_title = 'chanel order Nikon Multicolor list';
    num_lines = 1; % {24,23,24,19,20,13,1,14,18}
    def = {'3','647','488','555'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    chnum = str2double(answer{1});
    ch1 = answer{2};
    ch2 = answer{3};
    ch3 = answer{4};
    if chnum ==  3
    id = {idtag,idfilt,{ch1,ch2,ch3}};
    elseif chnum ==  2
        id = {idtag,idfilt,{ch1,ch2}};
    end
    saveMultiMLfunc3dMulticolor(selecfiles,subsubdir(1:end-1),MLindices,id,minPC,maxLP,dimension,nH,spaceDelim);
end
%% Import single 2D zeiss file
function singlegetlist2dZeiss_Callback(~,~)
singlegetlistZeiss(2)
end
%% 
function singlegetlistZeiss(dimension)
        [selecfiles,subsubdir] = uigetfile('*.txt','Enter a  molecular list file:');
       prompt = {'Enter the number of columuns in the molecular list file:',...
    'X coordinate column: ','Y coordinate column: ','Photon number column: ',...
    'Loc. prec. column: ','Frame index column: ', 'String tag column:',...
    'Enter trace lenght colum: ',...
    'Z coordinate column:',...
    'Enter Z Rejected tag:',...
    'Enter 1 to exlude Z Rejected, 0 to keep all localizations:',...
    'Enter mininimum photon count','Enter maximum localization precision:',...
    'Enter number of header lines in molecular list file:',...
    'Enter space delimeter in molecular list file:'};
    dlg_title = 'Importing Zeiss ML';
    num_lines = 1; % {24,23,24,19,20,13,1,14,18}
    def = {'14','5','6','10','8','2','12','3','7','0','1',...
    '0','2500','1','\t'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    MLindices = cellstr(answer(1:9));
    MLindices = cellfun(@str2double,MLindices, 'UniformOutput', false);
    idtag = str2double(answer{10});
    idfilt = str2double(answer{11});
    minPC = str2double(answer{12});
    maxLP = str2double(answer{13});
    id = {idtag,idfilt};
    nH = str2double(answer{14});
    spaceDelim = answer{15};
    saveMultiMLfunc3d(selecfiles,subsubdir(1:end-1),MLindices,id,minPC,maxLP,dimension,nH,spaceDelim);
end
%%
function singlevoronoi2d_Callback(~,~)
    tol_value = eval(tol_valueE.String); 
    TolX = eval(TolXE.String); 
    MaxFunEvals = eval(MaxFunEvalsE.String); 
    MaxIter = eval(MaxIterE.String); 
    StepTol = eval(steptolE.String); 
    optix0 = eval(x0E.String);
    [selecfiles1,subsubdir]  = uigetfile('*.mat','Get a a file for chanel 1');
    [selecfiles2,~]  = uigetfile('*.mat','Get a a file for chanel 2');
    prompt = {'Enter delimiter:',...
    'Enter a flag for chanel 1:',...
    'Enter a flag for chanel 2:',...
    'Enter 1 for mean density, 0 for median density:',...
    'Enter multiplication factor for mean/median density:',...
    'Enter 1 to use arbitrary density threshold:',...
    'Enter 1 if you want to align two chanels:',...
    'Enter name flag for 2 color file:'};
    dlg_title = 'Threshold 2D Voronoi and align two channels';
    num_lines = 1;
    def = {'_','647','568','[1,1]','[1,1]','0','0','Aligned_'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    delim = answer{1};
    flagch1 = answer{2};
    flagch2 = answer{3};  
    flag = str2num(answer{4}); 
    fac = str2num(answer{5}); 
    densityflag = str2num(answer{6}); 
    alignflag = str2num(answer{7}); 
    savename = answer{8}; 
    photonTH1 = eval(textbox_minP1.String);  
    locprec1 = eval(textbox_minLP1.String);
    photonTH2 = eval(textbox_minP2.String);  
    locprec2 = eval(textbox_minLP2.String);  
    if densityflag
    densitythr1 = eval(textbox_minD1.String); 
    densitythr2 = eval(textbox_minD2.String); 
    else
    densitythr1 = 0;
    densitythr2 = 0;
    end
    Csusu = {selecfiles1,selecfiles2};
%     batchProcessVoronoi(Csusu,subsubdir(1:end-1),delim,flagch1,flagch2,flag,fac,...
%     pix,Nmax,photonTH1,photonTH2,locprec1,locprec2,alignflag,...
%     densitythr1,densitythr2,2) 
dim = 2;
    SingleProcessVoronoi(selecfiles1,selecfiles2,subsubdir,flagch1,flagch2,...
    flag,fac,photonTH1,photonTH2,locprec1,locprec2,alignflag,densitythr1,...
    densitythr2,savename,dim)
end

%%
function singlerethrvoronoi2d_Callback(~,~)
prompt = {...
        'Enter 1 for mean density, 0 for median density:',...
        'Enter multiplication factor for mean/median density:',...
        'Enter 1 to use arbitrary density threshold:',...
        'Enter file name tag for re-thresholding:',...
        'Enter name flag for 2 color file saving:'};
    dlg_title = 'Re-threshold 2D Voronoi and align two channels';
    num_lines = 1;
    def = {'[1,1]','[1,1]','0','Aligned_','ReThr_'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    flag = str2num(answer{1}); 
    fac = str2num(answer{2}); 
    densityflag = str2num(answer{3}); 
    searchstring = answer{4};
    savename = answer{5};
     photonTH1 = eval(textbox_minP1.String);  
     locprec1 = eval(textbox_minLP1.String);
     photonTH2 = eval(textbox_minP2.String);  
     locprec2 = eval(textbox_minLP2.String);  
     if densityflag
    densitythr1 = eval(textbox_minD1.String); 
    densitythr2 = eval(textbox_minD2.String); 
    else
    densitythr1 = 0;
    densitythr2 = 0;
     end
     dim1 = 2;
     [selecfiles1,subsubdir]  = uigetfile(pwd,'Get a two chanel file to re-threshold voronoi diagram');
    Csusu = {selecfiles1};
    batchVoronoiReThrAlign(Csusu,subsubdir,flag,...
    fac,photonTH1,photonTH2,locprec1,locprec2,densitythr1,...
    densitythr2,searchstring,savename,dim1)
end

%%
function singlealign2d_Callback(~,~)
    tol_value = eval(tol_valueE.String); 
    TolX = eval(TolXE.String); 
    MaxFunEvals = eval(MaxFunEvalsE.String); 
    MaxIter = eval(MaxIterE.String); 
    StepTol = eval(steptolE.String); 
    optix0 = eval(x0E.String);
     prompt = {'Enter a file name to align:', ...
            'Enter name flag for 2 color file to save:'};
        dlg_title = '2C data alignment';
        num_lines = 1;
        def = {'Aligned_','Realigned_'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        flagch = answer{1};
        savename = answer{2};
[selecfiles1,subsubdir]  = uigetfile(pwd,'Get a 2 chanel file for alignment');
batchalign({selecfiles1},subsubdir,flagch,savename,2)
end

%% 3d data
eh3d = uimenu(mh,'Label','3D');%,'Checked','on');
eh3ds = uimenu(eh3d,'Label','single file');  
% uimenu(eh3ds,'Label','Import single Nikon molecular list','Callback',@singlegetlist3d_Callback);  
% uimenu(eh3ds,'Label','Import single Zeiss molecular list','Callback',@singlegetlist3dZeiss_Callback); 
uimenu(eh3ds,'Label','Threshold voronoi data','Callback',@singlevoronoi3d_Callback); 
uimenu(eh3ds,'Label','Re-threshold voronoi data','Callback',@singlerethrvoronoi3d_Callback); 
uimenu(eh3ds,'Label','Align two chanels','Callback',@singlealign3d_Callback); 
%% Import single 32D zeiss file
function singlegetlist3dZeiss_Callback(~,~)
singlegetlistZeiss(3)
end
%% single file Nikon Import molecular list 3D
function singlegetlist3d_Callback(~,~)
singlegetlistNikon(3)
end 
%%
function singlealign3d_Callback(~,~)
    tol_value = eval(tol_valueE.String); 
    TolX = eval(TolXE.String); 
    MaxFunEvals = eval(MaxFunEvalsE.String); 
    MaxIter = eval(MaxIterE.String); 
    StepTol = eval(steptolE.String); 
    optix0 = eval(x0E.String);
            prompt = {'Enter a file name to align:', ...
            'Enter name flag for 2 color file to save:'};
       dlg_title = '2C data alignment';
        num_lines = 1;
        def = {'Aligned_','Realigned_'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        flagch = answer{1};
        savename = answer{2};
[selecfiles1,subsubdir]  = uigetfile(pwd,'Get a 2 chanel file for alignment');
batchalign({selecfiles1},subsubdir,flagch,savename,3)
end

%%
function singlevoronoi3d_Callback(~,~)
    tol_value = eval(tol_valueE.String); 
    TolX = eval(TolXE.String); 
    MaxFunEvals = eval(MaxFunEvalsE.String); 
    MaxIter = eval(MaxIterE.String); 
    StepTol = eval(steptolE.String); 
    optix0 = eval(x0E.String);
[selecfiles1,subsubdir]  = uigetfile(pwd,'Get a file for chanel 1');
[selecfiles2,~]  = uigetfile('*.mat','Get a file for chanel 2');
    prompt = {'Enter delimiter:',...
    'Enter a flag for chanel 1:',...
    'Enter a flag for chanel 2:',...
    'Enter 1 for mean density, 0 for median density:',...
    'Enter multiplication factor for mean/median density:',...
    'Enter 1 to use arbitrary density threshold:',...
    'Enter 1 if you want to align two chanels:',...
    'Enter name flag for 2 color 3D file saving:'};
    dlg_title = 'Threshold 3D Voronoi and align two channels:';
    num_lines = 1;
    def = {'_','647','568','[1,1]','[1,1]','0','0','Aligned_'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    delim = answer{1};
    flagch1 = answer{2};
    flagch2 = answer{3};  
    flag = str2num(answer{4}); 
    fac = str2num(answer{5}); 
    densityflag = str2num(answer{6}); 
    alignflag = str2num(answer{7}); 
    savename = answer{8};
    photonTH1 = eval(textbox_minP1.String);  
    locprec1 = eval(textbox_minLP1.String);
    photonTH2 = eval(textbox_minP2.String);  
    locprec2 = eval(textbox_minLP2.String);  
    if densityflag
    densitythr1 = eval(textbox_minD1.String); 
    densitythr2 = eval(textbox_minD2.String); 
    else
    densitythr1 = 0;
    densitythr2 = 0;
    end
    Csusu = {selecfiles1,selecfiles2};
%     batchProcessVoronoi(Csusu,subsubdir(1:end-1),delim,flagch1,flagch2,flag,fac,...
%     pix,Nmax,photonTH1,photonTH2,locprec1,locprec2,alignflag,...
%     densitythr1,densitythr2,3)   
dim = 3;
    SingleProcessVoronoi(selecfiles1,selecfiles2,subsubdir,flagch1,flagch2,...
    flag,fac,photonTH1,photonTH2,locprec1,locprec2,alignflag,densitythr1,...
    densitythr2,savename,dim)
end

%%
function singlerethrvoronoi3d_Callback(~,~)
prompt = {...
        'Enter 1 for mean density, 0 for median density:',...
        'Enter multiplication factor for mean/median density:',...
        'Enter 1 to use arbitrary density threshold:',...
        'Enter file name tag for re-thresholding :',...
        'Enter name flag for 2 color 3D file saving:'};
    dlg_title = 'Re-threshold 3D Voronoi and align two channels:';
    num_lines = 1;
    def = {'[1,1]','[1,1]','0','Aligned_','ReThr_'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    flag = str2num(answer{1}); 
    fac = str2num(answer{2}); 
    densityflag = str2num(answer{3}); 
    searchstring = answer{4};
    savename = answer{5};
     photonTH1 = eval(textbox_minP1.String);  
     locprec1 = eval(textbox_minLP1.String);
     photonTH2 = eval(textbox_minP2.String);  
     locprec2 = eval(textbox_minLP2.String);  
     if densityflag
    densitythr1 = eval(textbox_minD1.String); 
    densitythr2 = eval(textbox_minD2.String); 
    else
    densitythr1 = 0;
    densitythr2 = 0;
     end
     dim1 = 3;
     [selecfiles1,subsubdir]  = uigetfile(pwd,'Get a two chanel file to re-threshold voronoi diagram');
    Csusu = {selecfiles1};
    batchVoronoiReThrAlign(Csusu,subsubdir,flag,...
    fac,photonTH1,photonTH2,locprec1,locprec2,densitythr1,...
    densitythr2,searchstring,savename,dim1)
end
%% 2 color 3d
eh3db = uimenu(eh3d,'Label','batch processing');  
% uimenu(eh3db,'Label','Import Nikon molecular lists','Callback',@batchgetlist3d_Callback); 
% uimenu(eh3db,'Label','Import Zeiss molecular lists','Callback',@batchgetlist3dZeiss_Callback); 
uimenu(eh3db,'Label','Threshold voronoi data','Callback',@batchvoronoi3d_Callback);
uimenu(eh3db,'Label','Align two chanels','Callback',@batchalign_Callback);
uimenu(eh3db,'Label','Re-threshold voronoi data','Callback',@batchrethrvoronoi3d_Callback);

function batchgetlist3d_Callback(~,~)
folder = uigetdir(pwd,'Get a folder with Nikon molecular list data');
runbatchprocessing(folder, 2,3);
end
function batchgetlist3dZeiss_Callback(~,~)
folder = uigetdir(pwd,'Get a folder with Zeiss molecular list data');
runbatchprocessing(folder, 14,3);
end
function batchvoronoi3d_Callback(~,~)
folder = uigetdir(pwd,'Get a folder with data for voronoi processing');
runbatchprocessing(folder, 3,3);
end

function batchrethrvoronoi3d_Callback(~,~)
folder = uigetdir(pwd,'Get a folder with data for voronoi processing');
runbatchprocessing(folder,6,3);
end
function batchalign_Callback(~,~)
folder = uigetdir(pwd,'Get folder with molecular list to align');
runbatchprocessing(folder, 8,3);
end
%% 2 color 2d
eh2db = uimenu(eh2d,'Label','batch processing');  
% uimenu(eh2db,'Label','Import Nikon molecular lists','Callback',@batchgetlist2d_Callback);
% uimenu(eh2db,'Label','Import Zeiss molecular lists','Callback',@batchgetlist2dZeiss_Callback); 
uimenu(eh2db,'Label','Threshold voronoi data','Callback',@batchvoronoi2d_Callback);
uimenu(eh2db,'Label','Align two chanels','Callback',@batchalign2d_Callback);
uimenu(eh2db,'Label','Re-threshold voronoi data','Callback',@batchrethrvoronoi2d_Callback);

function batchgetlist2d_Callback(~,~)
folder = uigetdir(pwd,'Get a folder whith molecular list data');
runbatchprocessing(folder, 2, 2);
end
function batchgetlist2dZeiss_Callback(~,~)
folder = uigetdir(pwd,'Get a folder whith molecular list data');
runbatchprocessing(folder, 14, 2);
end
function batchvoronoi2d_Callback(~,~)
folder = uigetdir(pwd,'Get a folder whith data for voronoi processing');
runbatchprocessing(folder, 3, 2);
end

function batchrethrvoronoi2d_Callback(~,~)
folder = uigetdir(pwd,'Get a folder whith data for voronoi processing');
runbatchprocessing(folder,6, 2);
end
function batchalign2d_Callback(~,~)
folder = uigetdir(pwd,'Get folder whith molecular list to align');
runbatchprocessing(folder,8,2);
end
%%
uimenu(mh,'Label','batch delete files','Callback',@deletefiles_Callback);%,'Checked','on');
function deletefiles_Callback(~,~)
folder = uigetdir(pwd,'Get root folder for file deletion');
runbatchprocessing(folder,9);  
end
%%
function runbatchprocessing(folder, process,varargin)
    tol_value = eval(tol_valueE.String); 
    TolX = eval(TolXE.String); 
    MaxFunEvals = eval(MaxFunEvalsE.String); 
    MaxIter = eval(MaxIterE.String); 
    StepTol = eval(steptolE.String); 
    optix0 = eval(x0E.String); 
if nargin == 3
    dim1 = varargin{1};
else
    dim1 = 0;
end
% system('powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c');
if process == 3  
     prompt = {'Enter a delimiter:',...
        'Enter a flag for chanel 1:',...
        'Enter a flag for chanel 2:',...
        'Enter 1 for mean density, 0 for median density:',...
        'Enter multiplication factor for mean/median density:',...
        'Enter 1 to use arbitrary density threshold:',...
        'Enter 1 if you want to align two channels:',...
        'Enter name flag for 2 color file saving:'};
    dlg_title = 'Input';
    num_lines = 1;
    def = {'_','647','568','[1,1]','[1,1]','0','0','Aligned_'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    delim = answer{1};
    flagch1 = answer{2};
    flagch2 = answer{3};  
    flag = str2num(answer{4}); 
    fac = str2num(answer{5}); 
    densityflag = str2num(answer{6}); 
    alignflag = str2num(answer{7}); 
    savename = answer{8};
    photonTH1 = eval(textbox_minP1.String);  
    locprec1 = eval(textbox_minLP1.String);
    photonTH2 = eval(textbox_minP2.String);  
    locprec2 = eval(textbox_minLP2.String);  
    if densityflag
    densitythr1 = eval(textbox_minD1.String); 
    densitythr2 = eval(textbox_minD2.String); 
    else
    densitythr1 = 0;
    densitythr2 = 0;
    end
elseif (process == 1)|(process == 2) 
%  [selecfiles,subsubdir] = uigetfile('*.txt','Get a  molecular list file');
       prompt = {'Number of columuns in molecular list file:',...
    'X coordinate column: ','Y coordinate column: ','Photon number column: ',...
    'Loc. prec. column: ','Frame index column: ', 'String tag column:',...
    'Enter trace lenght colum: ',...
    'Z coordinate column: ','Enter Z Rejected tag:',...
    'Enter 1 to exlude Z Rejected:',...
    'Enter min photon count:','Enter max localization precision:',...
    'Enter number of Header lines in molecular list file:',...
    'Enter space delimeter in molecular list file:'};
    dlg_title = 'Importing Nikon ML';
    num_lines = 1; % {24,23,24,19,20,13,1,14,18}
    def = {'24','23','24','19','20','13','1','14','18','Z Rejected','0',...
    '300','25','1','\t'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    MLindices = cellstr(answer(1:9));
    MLindices = cellfun(@str2double,MLindices, 'UniformOutput', false);
    idtag = answer{10};
    idfilt = str2double(answer{11});
    minPC = str2double(answer{12});
    maxLP = str2double(answer{13});
    id = {idtag,idfilt};
    nH = str2double(answer{14});
    spaceDelim = answer{15};
elseif process == 4
    prompt = {...
    'Enter name flag for file to analyse:',...
    'Enter minimum area for cluster 1 and 2:',...
    'Enter maximum Delaunay edge length for cluster 1 and 2:',...
    'Enter graph node degree for cluster 1 and 2:',...
    'Enter dimension for Delaunay triangulation: 2 or 3',...
    'Enter maximum colocalization distance:',...
    'Enter mean or median to report cluster''s density:',...
    'Enter number of nearest neigbours for nearest neigbour distance estimation:',...
    'Enter pixel size for mask file, if applies:',...
    'Enter minimum region size for mask file, if applies:'};
    dlg_title = 'Graph-based colocalization';
    num_lines = 1;
    def = {'Filtalgn_','[3,3]','[25,25]','[2,2]','2','200','median','1',...
        '10','1000'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    flagname = answer{1};
    minarea = str2num(answer{2});
    maxedge = str2num(answer{3}); 
    noddeg = str2num(answer{4}); 
    dimdeluney = str2num(answer{5}); 
    distcoloc = str2num(answer{6}); 
    flag = answer{7};
    numnn = str2num(answer{8}); 
    pixmask = str2num(answer{9}); 
    minregmask = str2num(answer{10}); 
elseif process == 6    
prompt = {...
        'Enter 1 for mean density, 0 for median density:',...
        'Enter multiplication factor for mean/median density:',...
        'Enter 1 to use arbitrary density threshold:',...
        'Enter file name tag for re-thresholding :',...
        'Enter name flag for 2 color 3D file saving:'};
    dlg_title = 'Re-threshold 3D Voronoi and align two channels:';
    num_lines = 1;
    def = {'[1,1]','[1,1]','0','Aligned_','ReThr_'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    flag = str2num(answer{1}); 
    fac = str2num(answer{2}); 
    densityflag = str2num(answer{3}); 
    searchstring = answer{4};
    savename = answer{5};

     photonTH1 = eval(textbox_minP1.String);  
     locprec1 = eval(textbox_minLP1.String);
     photonTH2 = eval(textbox_minP2.String);  
     locprec2 = eval(textbox_minLP2.String);  
     if densityflag
    densitythr1 = eval(textbox_minD1.String); 
    densitythr2 = eval(textbox_minD2.String); 
    else
    densitythr1 = 0;
    densitythr2 = 0;
    end
elseif process == 7  
prompt = {...
    'Enter a channel flag:',...
    'Enter 1 for mean density, 0 for median density:',...
    'Enter multiplication factor for mean/median density:',...
    'Enter 1 to use an arbitrary density threshold:',...
    'Enter channel number: 1 or 2 ',...
    'Enter name flag for 1 color file saving',...
    'Enter dimension for voronoi diagram'};
    dlg_title = '1 color single voronoi tessellation';
    num_lines = 1;
    def = {'647','1','1','0','1','Single_','0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);

    flagch = answer{1};
    flag = str2num(answer{2}); 
    fac = str2num(answer{3}); 
    densityflag = str2num(answer{4}); 
    ch = str2num(answer{5}); 
    savename = answer{6};
    dim1 = str2num(answer{7}); 
    
    photonTH = eval(textbox_minP1.String);  
    locprec = eval(textbox_minLP1.String); 
    if densityflag
    densitythr = eval(textbox_minD1.String); 
    else
    densitythr = 0;
    end
elseif process == 8
        prompt = {'Enter a file name to align:', ...
            'Enter name flag for 2 color file to save:'};
        dlg_title = '2C data alignment';
        num_lines = 1;
        def = {'Aligned_','Realigned_'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        flagch = answer{1};
        savename = answer{2};
%     batchalign(Csusu,subsubdir,flagch,dim)
elseif process == 9
 prompt = {'Enter file name tag to delete:',...
           'Enter file name tag to keep:'};
        dlg_title = 'Delete files';
        num_lines = 1;
        def = {'ReThr_','Filtalgn'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        stringdelete = answer{1};
        stringtokeep = answer{2};
elseif process == 10
    prompt = {...
        'Enter chanel flag:',...
        'Enter 1 for mean density, 0 for median density:',...
        'Enter multiplication factor for mean/median density:',...
        'Enter 1 to use arbitrary density threshold:',...
        'Enter chanel flag: ',...
        'Enter dimension for Voronoi diagram:',...
        'Enter name flag for 1 color file saving:'};
        dlg_title = '1 color voronoi re-thresholding';
        num_lines = 1;
        def = {'Single_647','1','1','0','1','[]','ReThr1C647_'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        searchstring = answer{1};
        flag = str2num(answer{2}); 
        fac = str2num(answer{3}); 
        densityflag = str2num(answer{4}); 
        ch = str2num(answer{5});
        dim1 = str2num(answer{6}); 
        savename = answer{7};
        photonTH = eval(textbox_minP1.String);  
        locprec = eval(textbox_minLP1.String); 
        if densityflag
        densitythr = eval(textbox_minD1.String); 
        else
        densitythr = 0;
        end
elseif process == 11
     prompt = {'Enter file tag name to filter:',...
          'Enter name flag for 2 color filtered file saving:'};
        dlg_title = 'Input';
        num_lines = 1;
        def = {'Aligned_','Filtalgn_'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        searchstring = answer{1};
        savename = answer{2};
elseif process == 12
prompt = {'Enter file tag name to filter','Enter a chanel flag:',...
    'Enter name flag for 1 color filtered file saving:'};
        dlg_title = 'Input';
        num_lines = 1;
        def = {'Single_647','1','Filtalgn1C'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        searchstring = answer{1};
        chl = str2num(answer{2});
        savename = answer{3};
        if chl == 1
            numn = numn11;
            filtval = filtval1;
        elseif chl == 2
            numn = numn22;
            filtval = filtval2;
        end
elseif process == 13
    prompt = {...
    'Enter name flag for file to analyse:',...
    'Enter minimum area for channel 1 or 2:',...
    'Enter maximum Delaunay edge length for chanel 1 or 2:',...
    'Enter graph node degree for channel 1 or 2:',...
    'Enter dimension for Delaunay triangulation: 2 or 3',...
    'Enter mean or median to report cluster''s density:',...
    'Enter chanel name tag:',...
    'Enter chanel number: 1 or 2',...
    'Enter pixel size for mask file, if applies:',...
    'Enter minimum region size for mask file, if applies:'};
    dlg_title = 'Graph-based object analysis';
    num_lines = 1;
    def = {'Filtalgn_','[3,3]','[30,30]','[2,2]','2','median','647','1',...
        '10','1000'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    flagname = answer{1};
    minarea = str2num(answer{2});
    maxedge = str2num(answer{3}); 
    noddeg = str2num(answer{4}); 
    dimdeluney = str2num(answer{5}); 
    flag = answer{6};
    chaneltagname = answer{7}; 
    chaneltag = str2num(answer{8}); 
    pixmask = str2num(answer{9}); 
    minregmask = str2num(answer{10}); 
elseif process == 14
       prompt = {'Enter the number of columuns in the molecular list file:',...
    'X coordinate column: ','Y coordinate column: ','Photon number column: ',...
    'Loc. prec. column: ','Frame index column: ', 'String tag column:',...
    'Enter trace lenght colum: ',...
    'Z coordinate column:',...
    'Enter Z Rejected tag:',...
    'Enter 1 to exlude Z Rejected, 0 to keep all localizations:',...
    'Enter mininimum photon count','Enter maximum localization precision:',...
    'Enter number of header lines in molecular list file:',...
    'Enter space delimeter in molecular list file:'};
    dlg_title = 'Batch importing Zeiss ML';
    num_lines = 1; % {24,23,24,19,20,13,1,14,18}
    def = {'13','5','6','8','7','2','12','3','13','2','1',...
    '300','25','1','\t'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    MLindices = cellstr(answer(1:9));
    MLindices = cellfun(@str2double,MLindices, 'UniformOutput', false);
    idtag = str2double(answer{10});
    idfilt = str2double(answer{11});
    minPC = str2double(answer{12});
    maxLP = str2double(answer{13});
    id = {idtag,idfilt};
    nH = str2double(answer{14});
    spaceDelim = answer{15};
end
clc
rootdir = folder;
cellfind = @(string)(@(cell_contents)(strcmp(string,cell_contents)));
files = dir(folder);
C = {files.name};
IndexC = cellfun(cellfind('.'),C);
files = files(~IndexC); 
C = {files.name};
IndexC = cellfun(cellfind('..'),C);
files = files(~IndexC); 
% Get a logical vector that tells which is a directory.
dirFlags = [files.isdir];
% Extract only those that are directories.
subFolders = files(dirFlags);
% Print folder names to command window.
if isempty(subFolders)
    subFolders = files(~dirFlags);
    for k = 1 : length(subFolders)
	fprintf('File #%d = %s\n', k, subFolders(k).name);
    end
     Csusu = {files.name};
     Index = cellfun(cellfind('.'),Csusu);
     Csusu = Csusu(~Index); 
     Index = cellfun(cellfind('..'),Csusu);
     Csusu = Csusu(~Index); 
    if (process == 1)|(process == 2)|(process == 14)
        if dim1
            saveMultiMLfunc3d(Csusu,folder,MLindices,id,minPC,maxLP,dim1,nH,spaceDelim);
        else
            saveMultiMLfunc3d(Csusu,folder,MLindices,id,minPC,maxLP,[],nH,spaceDelim);
        end
    elseif process == 3
         if dim1
             batchProcessVoronoi(Csusu,folder,delim,flagch1,flagch2,flag,fac,...
             photonTH1,photonTH2,locprec1,locprec2,alignflag,...
             densitythr1,densitythr2,savename,dim1)
         else
              batchProcessVoronoi(Csusu,folder,delim,flagch1,flagch2,flag,fac,...
             photonTH1,photonTH2,locprec1,locprec2,alignflag,...
             densitythr1,densitythr2,savename)
         end
    elseif process == 4
        BatchGraphColoc2C(Csusu,folder,flagname,minarea,maxedge,noddeg,...
        dimdeluney,distcoloc,numnn,pixmask,flag,minregmask);
    elseif process == 5
        nndFilterBatch(Csusu,folder)
    elseif process == 6
        batchVoronoiReThrAlign(Csusu,folder,flag,...
        fac,photonTH1,photonTH2,locprec1,locprec2,densitythr1,...
        densitythr2,searchstring,savename)
    elseif process == 7
        batchProcessVoronoi1color(Csusu,folder,flagch,flag,...
        fac,photonTH,locprec,densitythr,ch,savename,dim1)  
    elseif process == 8
        batchalign(Csusu,folder,flagch,savename,dim1)
    elseif process == 9
        batchdeletefiles(Csusu,folder,stringdelete,stringtokeep)
    elseif process == 10
        batchVoronoiReThrAlign1C(Csusu,folder,flag,...
        fac,photonTH,locprec,densitythr,searchstring,ch,savename,dim1)
    elseif process == 11
            BatchFilterAnalyse(Csusu,folder,searchstring,...
    numn11,filtval1,numn22,filtval2,numn12,filtval12,numn21,filtval21,dimn,savename)
    elseif process == 12
         BatchFilterAnalyse1C(Csusu,folder,searchstring,...
         numn,filtval,chl,dimn,savename)
    elseif process == 13
        BatchGraph1C(Csusu,folder,flagname,chaneltag,minarea,maxedge,noddeg,...
        dimdeluney,chaneltagname,pixmask,flag,minregmask)
    end
else
for k = 1 : length(subFolders)
	fprintf('Sub folder #%d = %s\n', k, subFolders(k).name);
end
%%
for fi = 1:length(subFolders)
  subdir = strcat(rootdir,flagslash,subFolders(fi).name);
  filesSu = dir(subdir);  
  Csu = {filesSu.name};
  IndexC = strcmp(Csu, '.');
  Index = find(IndexC == 0);
  filesSu = filesSu(Index); 
  IndexC = strcmp({filesSu.name}, '..');
  Index = find(IndexC == 0);
  filesSu = filesSu(Index); 
  SubdirFlags = [filesSu.isdir];
  % Get a logical vector that tells which is a directory.
if sum(SubdirFlags) == 0
    subsubFolders = filesSu;
    fprintf('No Sub folder #%d = %s\n', fi, subFolders(fi).name);
    subsubdir = subdir;
    filesSuSu = filesSu;
    Csusu = {filesSuSu.name};
    Index = cellfun(cellfind('.'),Csusu);
    Csusu = Csusu(~Index); 
    Index = cellfun(cellfind('..'),Csusu);
    Csusu = Csusu(~Index); 
    if (process == 1)|(process == 2)|(process == 14)
        if dim1
            saveMultiMLfunc3d(Csusu,subsubdir,MLindices,id,minPC,maxLP,...
                dim1,nH,spaceDelim);
        else
            saveMultiMLfunc3d(Csusu,subsubdir,MLindices,id,minPC,maxLP,...
                [],nH,spaceDelim);
        end
    elseif process == 3
         if dim1
             batchProcessVoronoi(Csusu,subsubdir,delim,flagch1,flagch2,flag,fac,...
             photonTH1,photonTH2,locprec1,locprec2,alignflag,...
             densitythr1,densitythr2,savename,dim1)
         else
              batchProcessVoronoi(Csusu,subsubdir,delim,flagch1,flagch2,flag,fac,...
             photonTH1,photonTH2,locprec1,locprec2,alignflag,...
             densitythr1,densitythr2,savename)
         end
    elseif process == 4
        BatchGraphColoc2C(Csusu,subsubdir,flagname,minarea,maxedge,noddeg,...
        dimdeluney,distcoloc,numnn,pixmask,flag,minregmask);
    elseif process == 5
        nndFilterBatch(Csusu,subsubdir)
    elseif process == 6
         batchVoronoiReThrAlign(Csusu,subsubdir,flag,...
        fac,photonTH1,photonTH2,locprec1,locprec2,densitythr1,...
        densitythr2,searchstring,savename)
    elseif process == 7
        batchProcessVoronoi1color(Csusu,subsubdir,flagch,flag,...
        fac,photonTH,locprec,densitythr,ch,savename,dim1)  
    elseif process == 8
        batchalign(Csusu,subsubdir,flagch,savename,dim1)
    elseif process == 9
        batchdeletefiles(Csusu,subsubdir,stringdelete,stringtokeep)
    elseif process == 10
        batchVoronoiReThrAlign1C(Csusu,subsubdir,flag,...
        fac,photonTH,locprec,densitythr,searchstring,ch,savename,dim1)
    elseif process == 11
            BatchFilterAnalyse(Csusu,subsubdir,searchstring,...
    numn11,filtval1,numn22,filtval2,numn12,filtval12,numn21,filtval21,dimn,savename)
    elseif process == 12
         BatchFilterAnalyse1C(Csusu,subsubdir,searchstring,...
         numn,filtval,chl,dimn,savename)
    elseif process == 13
        BatchGraph1C(Csusu,subsubdir,flagname,chaneltag,minarea,maxedge,noddeg,...
        dimdeluney,chaneltagname,pixmask,flag,minregmask)
    
    end
else
% Extract only those that are directories.
  subsubFolders = filesSu(SubdirFlags);
   fprintf('Sub folder #%d = %s\n', fi, subFolders(fi).name);
   
  for k = 1 : length(subsubFolders)    
    fprintf('Sub Sub folder #%d = %s\n', k, subsubFolders(k).name);
    subsubdir = strcat(subdir,flagslash,subsubFolders(k).name);
    filesSuSu = dir(subsubdir);
    SubsubdirFlags = [filesSuSu.isdir];
    filesSuSu = filesSuSu(~SubsubdirFlags);
    Csusu = {filesSuSu.name};
    Index = cellfun(cellfind('.'),Csusu);
    Csusu = Csusu(~Index); 
    Index = cellfun(cellfind('..'),Csusu);
    Csusu = Csusu(~Index); 
    if (process == 1)|(process == 2)|(process == 14)
        if dim1
            saveMultiMLfunc3d(Csusu,subsubdir,MLindices,id,minPC,maxLP,...
                dim1,nH,spaceDelim);
        else
            saveMultiMLfunc3d(Csusu,subsubdir,MLindices,id,minPC,maxLP,[],...
                nH,spaceDelim);
        end
    elseif process == 3
         if dim1
             batchProcessVoronoi(Csusu,subsubdir,delim,flagch1,flagch2,flag,fac,...
            photonTH1,photonTH2,locprec1,locprec2,alignflag,...
             densitythr1,densitythr2,savename,dim1)
         else
              batchProcessVoronoi(Csusu,subsubdir,delim,flagch1,flagch2,flag,fac,...
             photonTH1,photonTH2,locprec1,locprec2,alignflag,...
             densitythr1,densitythr2,savename)
         end
    elseif process == 4
        BatchGraphColoc2C(Csusu,subsubdir,flagname,minarea,maxedge,noddeg,...
        dimdeluney,distcoloc,numnn,pixmask,flag,minregmask);
    elseif process == 5
        nndFilterBatch(Csusu,subsubdir)
    elseif process == 6
         batchVoronoiReThrAlign(Csusu,subsubdir,flag,...
        fac,photonTH1,photonTH2,locprec1,locprec2,densitythr1,...
        densitythr2,searchstring,savename)
    elseif process == 7
        batchProcessVoronoi1color(Csusu,subsubdir,flagch,flag,...
        fac,photonTH,locprec,densitythr,ch,savename,dim1)  
    elseif process == 8
         batchalign(Csusu,subsubdir,flagch,savename,dim1)
    elseif process == 9
         batchdeletefiles(Csusu,subsubdir,stringdelete,stringtokeep)
    elseif process == 10
        batchVoronoiReThrAlign1C(Csusu,subsubdir,flag,...
        fac,photonTH,locprec,densitythr,searchstring,ch,savename,dim1)
    elseif process == 11
            BatchFilterAnalyse(Csusu,subsubdir,searchstring,...
       numn11,filtval1,numn22,filtval2,numn12,filtval12,numn21,filtval21,dimn,savename)
    elseif process == 12
         BatchFilterAnalyse1C(Csusu,subsubdir,searchstring,...
         numn,filtval,chl,dimn,savename)
   elseif process == 13
        BatchGraph1C(Csusu,subsubdir,flagname,chaneltag,minarea,maxedge,noddeg,...
        dimdeluney,chaneltagname,pixmask,flag,minregmask)
    end
  end
end 
end
end
% system('powercfg -setactive a1841308-3541-4fab-bc81-f71556f20b4a');
end
%% 1 color
s_single = 3;
sh = uimenu(f,'Label','1 color Voronoi','Position',s_single);
shs = uimenu(sh,'Label','single file'); 
uimenu(shs,'Label','Threshold voronoi data','Callback',@singlevoronoi3d1color_Callback); 

shb = uimenu(sh,'Label','batch processing');  
uimenu(shb,'Label','Threshold voronoi','Callback',@batchvoronoi1C_Callback);
uimenu(shb,'Label','Re-threshold voronoi','Callback',@batchReTrvoronoi1C_Callback);
  
function batchvoronoi1C_Callback(~,~)
folder = uigetdir(pwd,'Get a folder whith data for voronoi processing');
runbatchprocessing(folder, 7);
end

function batchReTrvoronoi1C_Callback(~,~)
folder = uigetdir(pwd,'Get a folder whith data for voronoi processing');
runbatchprocessing(folder, 10);
end
%% 1 color single file analysis
function singlevoronoi3d1color_Callback(~,~)
[selecfiles1,subsubdir]  = uigetfile(pwd,'Get a a file for chanel 1');

    prompt = {...
    'Enter a channel flag:',...
    'Enter 1 for mean density, 0 for median density:',...
    'Enter multiplication factor for mean/median density:',...
    'Enter 1 to use an arbitrary density threshold:',...
    'Enter channel number: 1 or 2 ',...
    'Enter name flag for 1 color file saving',...
    'Enter dimension for voronoi diagram'};
    dlg_title = '1 color single file analysis';
    num_lines = 1;
    def = {'647','1','1','0','1','Single_','0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);

    flagch = answer{1};
    flag = str2num(answer{2}); 
    fac = str2num(answer{3}); 
    densityflag = str2num(answer{4}); 
    ch = str2num(answer{5}); 
    savename = answer{6};
    dim1 = str2num(answer{7}); 
    
    photonTH = eval(textbox_minP1.String);  
    locprec = eval(textbox_minLP1.String); 
    if densityflag
    densitythr = eval(textbox_minD1.String); 
    else
    densitythr = 0;
    end
    Csusu = selecfiles1;
    batchProcessVoronoi1color(Csusu,subsubdir,flagch,flag,...
    fac,photonTH,locprec,densitythr,ch,savename,dim1)  
end
%% Re-calculate Voronoi
s_recalculatevoronoi = 4;
srv = uimenu(f,'Label','Re-calculate Voronoi','Position',s_recalculatevoronoi);
shs = uimenu(srv,'Label','single file'); 
shs2C = uimenu(shs,'Label','2 Color'); 
uimenu(shs2C,'Label','3D->2D Voronoi','Callback',@recalculatevoronoi3Dto2Dsingle); 
VOLp1 = [];
c1 = []; v1 = [];
VOLp2 = [];
c2 = []; v2 = [];
function recalculatevoronoi3Dto2Dsingle(~,~)
violet = eval(colch1.String);
green = eval(colch2.String);
if visu1 & visu2
if dim == 3
    if flagalign 
          [Vp1,VOLp1,v1,c1,dataout1] = voronoicustom(dataout1,2);
        dataoutshift1 = dataout1; 
        if ~isempty(leftrightcount)
        dataoutshift1(:,1) = dataoutshift1(:,1) - leftrightcount;
        end
        if ~isempty(updowncount)
        dataoutshift1(:,2) = dataoutshift1(:,2) - updowncount;
        end
        if dim == 3
            if ~isempty(zcount)
                dataoutshift1(:,5) = dataoutshift1(:,5) - zcount;
            end
        end
    else
          [Vp1,VOLp1,v1,c1,dataout1] = voronoicustom(dataout1,2);
          dataoutshift1 = [];
    end
    [Vp2,VOLp2,v2,c2,dataout2] = voronoicustom(dataout2,2);
    Dp1 = 1./VOLp1;
    Dp2 = 1./VOLp2;
    dim = 2;
    photonTH1 = eval(textbox_minP1.String);  
    locprec1 = eval(textbox_minLP1.String);
    photonTH2 = eval(textbox_minP2.String);  
    locprec2 = eval(textbox_minLP2.String);  
    densitythr1 = eval(textbox_minD1.String); 
    densitythr2 = eval(textbox_minD2.String); 
    textbox_meanDen1.String = num2str(mean(Dp1));
    textbox_medianDen1.String = num2str(median(Dp1));
    textbox_minDen1.String = num2str(min(Dp1));
    textbox_maxDen1.String = num2str(max(Dp1));
    textbox_meanDen2.String = num2str(mean(Dp2));
    textbox_medianDen2.String = num2str(median(Dp2));
    textbox_minDen2.String = num2str(min(Dp2));
    textbox_maxDen2.String = num2str(max(Dp2));

    savename = strcat(pathreal,flagslash,filenamepreal(1:end-14),'-2d',filenamepreal(end-13:end));
    uisave({'dataout1','dataout2',...
            'densitythr1','densitythr2','Vp1','Vp2','dataoutshift1',...
            'leftrightcount','updowncount','zcount',...
            'dim','namech1','namech2','Dp1','Dp2','photonTH1','photonTH2',...
            'locprec1','locprec2'},savename)
        
    cla(ha,'reset')
    if isempty(dataoutshift1)
        plot(dataout1(:,1),dataout1(:,2),'.g','Color',violet,'Parent', ha);   
    else
        plot(dataoutshift1(:,1),dataoutshift1(:,2),'.g','Color',violet,'Parent', ha);   
    end
    set(ha,'NextPlot','add');%hold on;
    plot(dataout2(:,1),dataout2(:,2),'.m','Color',green,'Parent', ha); 
    disp('Voronoi re-calculation finished')
else
   
 msgbox('File must be 3D Voronoi processed file ...')
end
else
   msgbox('Load 2 color 3D Voronoi processed file ...')
end
end
%% Colocalization
s_colocalization = 5;
sc = uimenu(f,'Label','Object analysis & colocalization','Position',s_colocalization); % object analysis
scs = uimenu(sc,'Label','Single file'); % single file
scs2C = uimenu(scs,'Label','2 Color'); % 2 color
uimenu(scs2C,'Label','Graph-based colocalization','Callback',@singlegraph2C); % graph coloc

%% single 2C file graph coloc
function singlegraph2C(~,~)
   [Csusu,subsubdir]  = uigetfile(pwd,'Get a 2 color file for graph based cluster analysis');
   prompt = {...
    'Enter name flag for file to analyse:',...
    'Enter minimum area for cluster 1 and 2:',...
    'Enter maximum Delaunay edge length for cluster 1 and 2:',...
    'Enter graph node degree for cluster 1 and 2:',...
    'Enter dimension for Delaunay triangulation: 2 or 3',...
    'Enter maximum colocalization distance:',...
    'Enter mean or median to report cluster''s density:',...
    'Enter number of nearest neigbours for nearest neigbour distance estimation:',...
    'Enter pixel size for mask file, if applies:',...
    'Enter minimum region size for mask file, if applies:'};
    dlg_title = 'Graph-based colocalization';
    num_lines = 1;
    def = {'Filtalgn_','[3,3]','[25,25]','[2,2]','2','200','median','1',...
        '10','1000'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    flagname = answer{1};
    minarea = str2num(answer{2});
    maxedge = str2num(answer{3}); 
    noddeg = str2num(answer{4}); 
    dimdeluney = str2num(answer{5}); 
    distcoloc = str2num(answer{6}); 
    flag = answer{7};
    numnn = str2num(answer{8}); 
    pixmask = str2num(answer{9}); 
    minregmask = str2num(answer{10}); 
% varargin: [minA1,minA2], [fac1,fac2],[noddeg1,noddeg2],dimdeluney ,distcoloc
% numn, pix, flag, minregmask

BatchGraphColoc2C(Csusu,subsubdir,flagname,minarea,maxedge,noddeg,...
dimdeluney,distcoloc,numnn,pixmask,flag,minregmask);
end
%% 1 color graph analysis
scs1C = uimenu(scs,'Label','1 Color'); % 2 color
uimenu(scs1C,'Label','Graph-based object analysis','Callback',@singlegraph1C); % graph coloc
%% single 1C file graph coloc
function singlegraph1C(~,~)
   [Csusu,subsubdir]  = uigetfile(pwd,'Get a 1 color file for graph based cluster analysis');
    prompt = {...
    'Enter name flag for file to analyse:',...
    'Enter minimum area for channel 1 or 2:',...
    'Enter maximum Delaunay edge length for chanel 1 or 2:',...
    'Enter graph node degree for channel 1 or 2:',...
    'Enter dimension for Delaunay triangulation: 2 or 3',...
    'Enter mean or median to report cluster''s density:',...
    'Enter chanel name tag:',...
    'Enter chanel number: 1 or 2',...
    'Enter pixel size for mask file, if applies:',...
    'Enter minimum region size for mask file, if applies:'};
    dlg_title = 'Graph-based object analysis';
    num_lines = 1;
    def = {'Filtalgn_','[3,3]','[25,25]','[2,2]','2','median','647','1',...
        '10','1000'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    flagname = answer{1};
    minarea = str2num(answer{2});
    maxedge = str2num(answer{3}); 
    noddeg = str2num(answer{4}); 
    dimdeluney = str2num(answer{5}); 
    flag = answer{6};
    chaneltagname = answer{7}; 
    chaneltag = str2num(answer{8}); 
    pixmask = str2num(answer{9}); 
    minregmask = str2num(answer{10}); 
BatchGraph1C(Csusu,subsubdir,flagname,chaneltag,minarea,maxedge,noddeg,...
dimdeluney,chaneltagname,pixmask,flag,minregmask)
% varargin: [minA1,minA2], [fac1,fac2],[noddeg1,noddeg2],dimdeluney 
% chanel tag, pix, flag, minregmask
end
%% batch 2C file graph coloc
scb = uimenu(sc,'Label','Batch analysis'); % single file
scb2C = uimenu(scb,'Label','2 Color'); % 2 color
uimenu(scb2C,'Label','Graph-based colocalization','Callback',@batchgraph2C); % batch graph coloc
function batchgraph2C(~,~)
folder = uigetdir(pwd,'Get folder with subfolders/files for batch 2C graph analysis');
runbatchprocessing(folder,4);
end
%% batch 1C file graph coloc
scb1C = uimenu(scb,'Label','1 Color'); % 2 color
uimenu(scb1C,'Label','Graph-based object analysis','Callback',@batchgraph1C); % batch graph coloc
function batchgraph1C(~,~)
folder = uigetdir(pwd,'Get folder with subfolders/files for batch 1C graph analysis');
runbatchprocessing(folder,13);
end
%% Colocalization
s_ripleyscluster = 6;
sripleyclust = uimenu(f,'Label','Ripley''s analysis','Position',s_ripleyscluster); % object analysis
sripleyclusts = uimenu(sripleyclust,'Label','Single file'); % single file
sripleyclusts2C = uimenu(sripleyclusts,'Label','2 Color'); % 2 color
% sripleyclustb = uimenu(sripleyclust,'Label','Single file'); % batch file
% sripleyclustb2C = uimenu(sripleyclustb,'Label','2 Color'); % 2 color
% uimenu(sripleyclustb2C,'Label','Run batch randomization','Callback',@batchripleygraph2C); % graph coloc
uimenu(sripleyclusts2C,'Label','Run randomization','Callback',@singleripleygraph2C); % graph coloc
uimenu(sripleyclust,'Label','Plot randomized','Callback',@plotsingleripleygraph2C); % graph coloc
uimenu(sripleyclust,'Label','Load randomized','Callback',@loadsingleripleygraph2C); % graph coloc

sripleyclusts1C = uimenu(sripleyclusts,'Label','1 Color'); % 1 color
uimenu(sripleyclusts1C,'Label','Chanel 1','Callback',@singleripley1Cch1); % chanel 1
uimenu(sripleyclusts1C,'Label','Chanel 2','Callback',@singleripley1Cch2); % chanel 1
%% batch ripleys 2 color
% 
% function batchripleygraph2C(~,~)
%     folder = uigetdir(pwd,'Get a folder whith data for Ripley''s function calculation');
%     runbatchprocessing(folder, 15);
% end
%% plot randomized
function plotsingleripleygraph2C(~,~)
    if runripleyflag
    choice = menu('chose variable to plot','Ksim12','Ksim21','Lsim12','Lsim21','Ksim1',...
    'Ksim2','Lsim1','Lsim2','KdMs','LdMs');

 prompt = {...
    'Enterx label:',...
    'Enter y ticks',...
    'Enter x ticks',...
    'Enter 1 to scale x axes, 0 otherwise',...
    'Enter 1 to scale y axes, 0 otherwise'};
    dlg_title = 'Input';
    num_lines = 1;
    def = {'Distance (nm)','[0,5,10]','[0,500,1000]','1','0'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    xlab = answer{1};
    ytick = str2num(answer{2});
    xtick = str2num(answer{3}); 
    scalex = str2num(answer{4}); 
    scaley = str2num(answer{5}); 
    switch choice
        case 1
             ylab = 'K_{1-2}';
             var = Ksim12;
             obs = K12;
        case 2
             ylab = 'K_{2-1}';
             var = Ksim21;
             obs = K21;
        case 3
             ylab = 'L_{1-2}';
             var = Lsim12;
             obs = L12;
        case 4
             ylab = 'L_{2-1}';
             var = Lsim21;
             obs = L21;
        case 5
             ylab = 'K_{1}';
             var = Ksim1;
             obs = Khat1;
        case 6
             ylab = 'K_{2}';
             var = Ksim2;
             obs = Khat2;
        case 7
             ylab = 'L_{1}';
             var = Lsim1;
             obs = Lhat1;
        case 8
             ylab = 'L_{2}';
             var = Lsim2;
             obs = Lhat2;
        case 9
             ylab = 'K_{1-2,2-1}';
             var = KdMs;
             obs = KdM;
        case 10
             ylab = 'L_{1-2,2-1}';
             var = LdMs;
             obs  = LdM;
    end
width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 1;    % AxesLineWidth
fsz = 10;      % Fontsize
lw = 1.5;      % LineWidth
msz = 8;       % MarkerSize
fszl = 8; % Fontsize legend 
fontname = 'Helvetica';
colfill = [66,103,176]/255;
mc = [106,37,58]/255;
xtick = xtick*unitfactor;
for i = 1:numel(ytick)
yticklab{i} = num2str(ytick(i));
end
for i = 1:numel(xtick)
xticklab{i} = num2str(xtick(i));
end
legendlab = {'Observed', 'rnd: 95% CI','rnd: mean'};
% legendlab = {'Observed', 'Randomized: 95 % CF','Randomized: avereage'};
%%
avvar = squeeze(mean(var,2));
UCIvar =  squeeze(prctile(var,95,2));% max(K');
LCIvar =  squeeze(prctile(var,5,2));%min(K');

for numcell = 1:size(obs,2)
f1 = figure;
hold on;
plt = plot(D*unitfactor,obs(:,numcell),'-k','Color',violet);
fillplot(D*unitfactor,avvar(:,numcell),UCIvar(:,numcell),LCIvar(:,numcell),0.5,0.5,colfill, colfill,colfill)


plt.LineWidth = lw;

set(gca,'Fontname',fontname,'FontSize',fsz)    
set(gca,'box','off');
if scalex
set(gca,'XTick',xtick) 
set(gca,'XTickLabel',xticklab)
xlim(gca,[min(xtick),max(xtick)])
end
if scaley
    set(gca,'YTick',ytick) 
    set(gca,'YTickLabel',yticklab)
    ylim(gca,[min(ytick),max(ytick)]);
end
yl = ylabel(gca, ylab);
set(yl,'Fontname',fontname, 'Fontsize', fsz)  

set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
l = legend(legendlab,'Location','northeast'); % southeast northwest
set(l, 'Interpreter', 'none','FontSize', fszl,'color','w');
set(l,'Fontname',fontname) 
tl = title(sprintf('Cell number: %d ',numcell));
set(tl,'Fontname',fontname, 'Fontsize', fsz)  
set(gca,'box','off');
xl = xlabel(gca, xlab);
set(xl,'Fontname',fontname, 'Fontsize', fsz)    
pos = get(f1, 'Position');
set(f1, 'Position', [pos(1)-100 pos(2)-100 width*80, height*80]); %<- Set size
set(f1,'color','w')
set(f1,'InvertHardcopy','on');
set(f1,'PaperUnits', 'inches');
end


    else
        msgbox('Run or load Ripley''s randomization function')
    end

end
%% initialize Ripley
Ksim12 = [];Ksim21 = [];K21 = [];K12 = [];Lsim12 = [];Lsim21 = [];L12  = [];
L21  = [];Ksim1 = [];Ksim2  = [];Lsim1  = [];Lsim2  = [];Khat1  = [];Khat2  = [];
Lhat1 = [];Lhat2  = [];KdMs  = [];LdMs  = [];KdM  = [];LdM  = [];C1r  = [];
C2r  = [];inPoint1  = [];inPoint2 = [];
D = []; runripleyflag = 0; unitfactor = 1;
lam11= [];lam22= [];lam12= [];lam21= [];vol= [];
inPoint1r= [];inPoint2r= [];
cen1= [];cen2= [];Nsimul= [];mask= [];boundarycorrection= [];
 minregmask= [];zrange= [];multfac= [];plotflag= [];
%% load randomized
function loadsingleripleygraph2C(~,~)
[Csusu,subsubdir]  = ...
uigetfile(pwd,'Get a file with randomized Ripley''s analysis');
tmp = load(strcat(subsubdir,flagslash,Csusu));
Ksim12 = tmp.Ksim12;Ksim21 = tmp.Ksim21;K21 = tmp.K21;K12 = tmp.K12;
Lsim12 = tmp.Lsim12;Lsim21 = tmp.Lsim21;L12  = tmp.L12;
L21  = tmp.L21;Ksim1 = tmp.Ksim1;Ksim2  = tmp.Ksim2;Lsim1  = tmp.Ksim2;
Lsim2  = tmp.Lsim2;Khat1  = tmp.Khat1;Khat2  = tmp.Khat2;
Lhat1 = tmp.Lhat1;Lhat2  = tmp.Lhat2;KdMs  = tmp.KdMs;LdMs  = tmp.LdMs;
KdM  = tmp.KdM;LdM  = tmp.LdM;C1r  = tmp.C1r;
C2r  = tmp.C2r;lam11  = tmp.lam11;lam22  = tmp.lam22;
inPoint1  = tmp.inPoint1;inPoint2 = tmp.inPoint2;
lam12  = tmp.lam12;lam21 = tmp.lam21;vol = tmp.vol;
D = tmp.D; unitfactor = tmp.unitfactor;
inPoint1r = tmp.inPoint1r; inPoint2r = tmp.inPoint2r;
runripleyflag = 1;
disp('Loading finished')
end
%% single 2C file graph coloc

function singleripleygraph2C(~,~)
 runripleys(0)
uisave({'Ksim12','Ksim21','K21','K12','Lsim12','Lsim21','L12','L21','Ksim1',...
'Ksim2','Lsim1','Lsim2','Khat1','Khat2','Lhat1',...
 'Lhat2','KdMs','LdMs','KdM','LdM','C1r','C2r',...
 'inPoint1','inPoint2','Nsimul','pix','dim','boundarycorrection',...
 'minregmask','zrange','multfac','plotflag','unitfactor','cen1','cen2','D',...
'lam11','lam22','lam12','lam21','vol','inPoint1r','inPoint2r'},savefileripley);
runripleyflag = 1;
end
%% 1 color chanel 1 Ripley
savefileripley = '';
function singleripley1Cch1(~,~)
    runripleys(1)
    Ksim12 = [];Ksim21 = [];K21 = [];K12 = [];Lsim12 = [];Lsim21 = [];L12  = [];
    L21  = [];Ksim2  = [];Lsim2  = [];Khat2  = [];lam21= [];lam12= [];
    Lhat2 = [];C2r  = [];inPoint2  = [];lam22= [];vol= [];inPoint2r= [];
    KdMs  = [];LdMs  = [];KdM  = [];LdM  = [];
    uisave({'Ksim12','Ksim21','K21','K12','Lsim12','Lsim21','L12','L21','Ksim1',...
    'Ksim2','Lsim1','Lsim2','Khat1','Khat2','Lhat1',...
    'Lhat2','KdMs','LdMs','KdM','LdM','C1r','C2r',...
    'inPoint1','inPoint2','Nsimul','pix','dim','boundarycorrection',...
    'minregmask','zrange','multfac','plotflag','unitfactor','cen1','cen2','D',...
    'lam11','lam22','lam12','lam21','vol','inPoint1r','inPoint2r'},savefileripley);
    runripleyflag = 1;
end
function singleripley1Cch2(~,~)
    runripleys(2)
    Ksim12 = [];Ksim21 = [];K21 = [];K12 = [];Lsim12 = [];Lsim21 = [];L12  = [];
    L21  = [];Ksim1  = [];Lsim1  = [];Khat1  = [];lam21= [];lam12= [];
    Lhat1 = [];C1r  = [];inPoint1  = [];lam11= [];vol= [];inPoint1r= [];
    KdMs  = [];LdMs  = [];KdM  = [];LdM  = [];
    uisave({'Ksim12','Ksim21','K21','K12','Lsim12','Lsim21','L12','L21','Ksim1',...
    'Ksim2','Lsim1','Lsim2','Khat1','Khat2','Lhat1',...
    'Lhat2','KdMs','LdMs','KdM','LdM','C1r','C2r',...
    'inPoint1','inPoint2','Nsimul','pix','dim','boundarycorrection',...
    'minregmask','zrange','multfac','plotflag','unitfactor','cen1','cen2','D',...
    'lam11','lam22','lam12','lam21','vol','inPoint1r','inPoint2r'},savefileripley);
    runripleyflag = 1;
end
%% run ripleys analysis with randomization
function runripleys(colflag)
if ~ismac
    flagslash = '\'; %'\'
else
    flagslash = '/';
end

    prompt = {...
    'Enter the number of randomization steps:',...
    'Enter the distance vector for a Ripley''s function calculation (default in nm):',...
    'Enter a pixel size (only if using image mask, default in nm):',...
    'Enter a dimension for Ripley''s function calculation: 2 or 3',...
    'Enter 1 to apply boundary correction, 0 otherwise:',...
    'Enter minimum region size for a mask (default in nm^2):',...
    'Enter z range (only for 3D Ripley''s function, default in nm):',...
    'Enter fold change in the number of elements in a randomized vector to draw positions from:',...
    'Enter 1 to plot results at each iteration step, 0 otherwise:',...
    'Enter unit factor for Ripley''s L function calculation: e.g. distance D in nm -> L in um, enter 1e-3',...
    'Enter 1 if poly roi mask is open, 2 if image mask is open, 0 to load a mask from a file:',...
    'Enter 1 to run Ripley''s analysis on localization:',...
    'Enter 1 to load a graph-based file, 0 to use an open file:'};
    dlg_title = 'Input';
    num_lines = 1;
    def = {'100','0:10:1000','10','2','0','1000','[-400,400]','5','0','1',...
     '1','0','1'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    Nsimul = str2num(answer{1});
    D = str2num(answer{2});
    pix = str2num(answer{3}); 
    dim = str2num(answer{4}); 
    boundarycorrection = str2num(answer{5}); 
    minregmask = str2num(answer{6}); 
    zrange = str2num(answer{7});
    multfac = str2num(answer{8}); 
    plotflag = str2num(answer{9}); 
    unitfactor = str2num(answer{10}); 
    plolyroimaskflag = str2num(answer{11}); 
    ripleyonlocalization = str2num(answer{12}); 
    loadfiletoripley = str2num(answer{13}); 
  
if ripleyonlocalization
    if dim == 2
        ind = [1,2];
    elseif dim == 3
        ind = [1,2,5];
    end
    if loadfiletoripley     
       [Csusu,subsubdir]  = ...
        uigetfile(pwd,'Get a 2 color file for localization-based Ripley''s analysis');
        tmp = load(strcat(subsubdir,flagslash,Csusu),'dataoutshift1','dataout2','dataout1');
        if ~colflag
            dat1 = tmp.dataoutshift1;
            dat2 = tmp.dataout2;
            cen1 = dat1(:,ind);
            cen2 = dat2(:,ind);
            savefileripley = strcat(subsubdir,flagslash,'RipleysLOC_',Csusu(end-4:end));
        elseif colflag == 2
            dat1 = tmp.dataout2;
            cen1 = dat1(:,ind);
            cen2 = cen1;
            savefileripley = strcat(subsubdir,flagslash,'RipleysLOCCH2_',Csusu(end-4:end));
        elseif colflag == 1
            try
                dat1 = tmp.dataoutshift1;
            catch
                dat1 = tmp.dataout1;
            end
            cen1 = dat1(:,ind);
            cen2 = cen1;
            savefileripley = strcat(subsubdir,flagslash,'RipleysLOCCH1_',Csusu(end-4:end));
        end
        
    else
         if ~colflag
            cen1 = dataoutshift1(:,ind);
            cen2 = dataout2(:,ind);
             savefileripley = strcat(pathreal,flagslash,'Ripleys_',filenamepreal(end-4:end));
         elseif colflag == 1
             try
                cen1 = dataoutshift1(:,ind);
             catch
                cen1 = dataout1(:,ind);
             end
             cen2 = cen1;
             savefileripley = strcat(pathreal,flagslash,'RipleysLOCCH1_',filenamepreal(end-4:end));
         elseif colflag == 2
             cen1 = dataout2(:,ind);
             cen2 = cen1;
             savefileripley = strcat(pathreal,flagslash,'RipleysLOCCH2_',filenamepreal(end-4:end));
         end
    end
else
    
        if loadfiletoripley
           [Csusu,subsubdir]  = ...
            uigetfile(pwd,'Get a 2 color file with segmented graphs for cluster-based Ripley''s analysis');
            tmp = load(strcat(subsubdir,flagslash,Csusu),'WC1','WC2');
            if ~colflag
            cen1 = tmp.WC1;
            cen2 = tmp.WC2;
            savefileripley = strcat(subsubdir,flagslash,'Ripleys_',Csusu(end-4:end));
            elseif colflag == 1
                cen1 = tmp.WC1;
                cen2 = cen1;
                savefileripley = strcat(subsubdir,flagslash,'RipleysCH1_',Csusu(end-4:end));
             elseif colflag == 2
                cen1 = tmp.WC2;
                cen2 = cen1;
                savefileripley = strcat(subsubdir,flagslash,'RipleysCH2_',Csusu(end-4:end));
            end
        else
             if ~colflag
                cen1 = WC1;
                cen2 = WC2;
                savefileripley = strcat(pathreal,flagslash,'Ripleys_',filenamepreal(end-4:end));
             elseif colflag == 1
                cen1 = WC1;
                cen2 = cen1;
                savefileripley = strcat(pathreal,flagslash,'RipleysCH1_',filenamepreal(end-4:end));
             elseif colflag == 2
                cen1 = WC2;
                cen2 = cen1;
                savefileripley = strcat(pathreal,flagslash,'RipleysCH2_',filenamepreal(end-4:end));
             end
        end

end

if plolyroimaskflag
    if ~flagroi
        return;
    elseif flagroi == 1 
        mask = nodes;
    elseif flagroi == 2 
        mask = totalMask1;
    end
else
 [maskfile,maskdir]  = ...
uigetfile(pwd,'Get a file with mask');
tmp = load(strcat(maskdir,flagslash,maskfile));
try
    mask = tmp.totalMask1;
catch
    mask = tmp.nodes;
end
end
[Ksim12,Ksim21,K12,K21,Lsim12,Lsim21,L12,L21,Ksim1,Ksim2,Lsim1,Lsim2,Khat1,Khat2,Lhat1,...
 Lhat2,KdMs,LdMs,KdM,LdM,C1r,C2r,inPoint1,inPoint2,lam11,lam22,lam12,lam21,vol,inPoint1r,inPoint2r] = ...
 randomizationRiplays2col3D(cen1,cen2,Nsimul,D,mask,pix,dim,boundarycorrection,...
 minregmask,zrange,multfac,plotflag,unitfactor);
end
%'Style','edit'
aa = findall( f, 'Style', 'edit' );
pps=[];
 set( findall( f, '-property', 'Units' ), 'Units', 'Normalized' )
 set( findall( f, 'Style', 'Pushbutton' ),'FontSize',floor(3*pbh/4),'FontName','default', 'Fontunits', 'Normalized') %FixedWidth
 %get(groot,'defaultuicontrolFontName') 
 set( findall( f, 'Style', 'edit' ),'FontSize',floor(2*pbh/3),'FontName','FixedWidth', 'Fontunits', 'Normalized') %togglebutton
 set( findall( f, 'Style', 'text' ),'FontSize',floor(3*pbh/4),'FontName','default', 'Fontunits', 'Normalized') 
 set( findall( f, 'Style', 'togglebutton' ),'FontSize',floor(3*pbh/4),'FontName','default', 'Fontunits', 'Normalized') %'popupmenu'
  set( findall( f, 'Style', 'popupmenu' ),'FontSize',floor(3*pbh/4),'FontName','default', 'Fontunits', 'Normalized') 
  set( findall( f, 'Style', 'checkbox' ),'FontSize',floor(3*pbh/4),'FontName','default', 'Fontunits', 'Normalized') 
    set( findall( f, 'Style', 'listbox' ),'FontSize',floor(3*pbh/4),'FontName','default', 'Fontunits', 'Normalized') 
    for i = 1:numel(aa)
      pps = get(aa(i),'Position'); 
      set(aa(i),'Position',[pps(1) pps(2) pps(3) 5*pps(4)/4]);
    end
end
